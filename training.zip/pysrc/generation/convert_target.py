from label_video.database import LabelDatabase
from label_video import settings
from label_video.capture import capture_uri
from generation.gemini import Gemini
import asyncio 


from fastapi import APIRouter,HTTPException
from fastapi.responses import JSONResponse
router = APIRouter()


@router.get("/api/generate/target")
async def generate_target():
    db = LabelDatabase(settings.project)

    sql = 'SELECT id, prompt FROM capture'

    # capture_uri()

    columns, rows = db.fetchall(sql)
    
    data = db.to_dict(columns, rows)

    for row in data:
        print(capture_uri(row.get('id')))
    db.close()
    # sql = 'SELECT * FROM bbox where capture_id = ?'


    session_path = r"D:\Develop\browser\sessions\session1"

    async with Gemini(session_path) as gemini:
        await gemini.start()

    return {"message": "generate target success."}

if __name__=='__main__':
    asyncio.run(generate_target())