from playwright.async_api import async_playwright
from playwright.async_api import expect
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
import time, asyncio, os, re, datetime, random


def get_time(t):
    today = datetime.datetime.now()
    try:
        dt = datetime.datetime.strptime(t, "%m/%d %p%I:%M")
        dt = dt.replace(year=today.year)
    except ValueError:
        dt = datetime.datetime.strptime(t, "%p%I:%M")
        dt = dt.replace(year=today.year, month=today.month, day=today.day)
    return dt.strftime('%m-%d %H:%M')

class Gemini:
    def __init__(self, session_path):
        self.session_path = session_path
        self.playwright_manager = None
        self.p = None
        self.context = None

    # 🔥 改寫為類別的非同步上下文管理器
    async def __aenter__(self):
        self.playwright_manager = async_playwright()
        self.p = await self.playwright_manager.__aenter__()
        
        self.context = await self.p.chromium.launch_persistent_context(
            self.session_path,
            headless=False,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-infobars',
                '--start-maximized',
            ],
            viewport={'width': 1024, 'height': 720},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
        )
        return self  # 讓 as gemini 拿到的是 Gemini 的物件實例

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.context:
            await self.context.close()
            self.context = None
        if self.playwright_manager:
            await self.playwright_manager.__aexit__(exc_type, exc_val, exc_tb)
            self.playwright_manager = None
            self.p = None

    async def check_login(self, page):
        locator = page.get_by_role("button", name="登入")
        buttons = await locator.all()
        login_button_count = len(buttons)

        locator = page.get_by_label(re.compile("Google .* (.*@gmail.com)"))
        buttons = await locator.all()
        account_button_count = len(buttons)
        
        if login_button_count == 0 and account_button_count >= 1:
            return True
        else:
            return False
        
    async def login(self, page):
        print('login fail')
        print("\n=============================================")
        print("【提示】請在彈出的瀏覽器中手動完成 Google 登入。")
        print("包括輸入帳密、處理圖形驗證碼，以及手機的 2FA 二階段驗證。")
        print("=============================================\n")            

        locator = page.get_by_label(re.compile("Google .* (.*@gmail.com)"))

        for i in range(10):
            try:
                await locator.wait_for(state="visible", timeout=30000)
            except PlaywrightTimeoutError:
                print('wait timeout:', i)
                continue

            buttons = await locator.all()
            account_button_count = len(buttons)            
            print('account_button_count', account_button_count)
            await asyncio.sleep(10)
            if account_button_count > 0:
                print('完成登入')
                break

    async def get_useage(self, page):
        await page.goto('https://gemini.google.com/usage')
        locator = page.get_by_text("目前用量")
        await locator.wait_for(state="visible")

        locator = page.locator("div.usage-metrics-container > div.gxu-items-container")
        divs = await locator.all()
        print('divs', len(divs))

        for div in divs:
            tx = await div.inner_text()
            r = re.findall(r'已使用\s*(\d+)%\s*(?=\n|$)', tx)
            usage = [float(v) for v in r]
            print(usage)

            r = re.findall(r'重設時間：(.+?)\n', tx)
            r = [v.replace('下午', 'PM').replace('上午', 'AM').replace('日', '').replace('月', '/') for v in r]
            reset_time = [get_time(t) for t in r]
            
            k = ['current_usage', 'weekly_usage', 'daily_reset', 'weekly_reset']
            return dict(zip(k, usage + reset_time))
        
    async def disable_workmark(self,page):

        settings_button = page.get_by_label("設定")
        await settings_button.click()

        watermark_button = page.locator('[data-test-id="watermark-button"]')
        await watermark_button.click()

        close_option = page.locator('button[role="menuitemradio"]').filter(has_text="關閉")
        await close_option.click()



    async def upload_file_to_gemini_with_chooser(self, page, file_path):
        add_file_btn_selector = 'input-area-v2 simplified-input-menu gem-icon-button button'
        upload_menu_selector = 'span.gem-menu-item-label:has-text("上傳檔案"), span:has-text("Upload files")'
        agree_btn_selector = '[data-test-id="upload-image-agree-button"]'

        async def handle_file_chooser(file_chooser):
            print("系統檔案視窗已彈出，Playwright 正在攔截並自動關閉它...")
            await file_chooser.set_files(file_path)

        page.on("filechooser", handle_file_chooser)

        isUploaded = False
        for i in range(3):
            try:
                await page.wait_for_selector(add_file_btn_selector, state="visible", timeout=5000)
                await page.click(add_file_btn_selector, force=True)
                
                await page.wait_for_selector(upload_menu_selector, state="visible", timeout=3000)
                await page.click(upload_menu_selector)
            except PlaywrightTimeoutError:
                print('upload timeout')
                await page.wait_for_timeout(8000)
            finally:
                agree_btn = page.locator(agree_btn_selector)
                try:
                    if await agree_btn.is_visible(timeout=2000):
                        await agree_btn.click()
                        print("【提示】已自動按下同意免責事項按鈕。")
                        await page.click(add_file_btn_selector, force=True)
                        await page.click(upload_menu_selector)
                except Exception:
                    pass
                
                isUploaded = True
                break

        print("【成功】檔案已透過 FileChooser 注入，Dialog 已自動關閉。")
        page.remove_listener("filechooser", handle_file_chooser)

        await page.wait_for_timeout(2000)
        return isUploaded

    async def download_first_generated_image(self, page, full_save_path):
        download_buttons_selector = 'button[aria-label="下載原尺寸圖片"]'
        print("正在偵測畫面上的生成圖片下載按鈕...")
        
        try:
            await page.wait_for_selector(download_buttons_selector, state="visible", timeout=60000)
        except Exception:
            print("【錯誤】超時！畫面上沒有出現任何圖片下載按鈕。")
            return

        first_button = page.locator(download_buttons_selector).first
        print("【偵測成功】準備下載第一張生成的圖片。")
        await page.wait_for_timeout(10000)

        try:
            await first_button.scroll_into_view_if_needed()
            await expect(first_button).to_be_enabled(timeout=5000)
            await first_button.hover()
            await page.wait_for_timeout(1000)
                
            async with page.expect_download() as download_info:
                await first_button.click(force=True)
            
            download = await download_info.value
            await download.save_as(full_save_path)
            print(f"→ 第一張圖片儲存成功：{full_save_path}")
            
        except Exception as e:
            print(f"❌ 第一張圖片下載失敗。原因: {e}")

        print(f"【任務完成】圖片下載程序已結束，請至 {full_save_path} 查看。")    

    async def start(self):
        # 這裡直接使用 self.context，因為已經在 __aenter__ 建立好了
        page = self.context.pages[0] if self.context.pages else await self.context.new_page()        

        await page.goto("https://gemini.google.com")

        if await self.check_login(page):
            print('login success')
            await self.disable_workmark(page)

            usage = await self.get_useage(page)
            print('目前用量: {current_usage}%  重設時間: {daily_reset}'.format(**usage))
            print('本周用量: {weekly_usage}%  重設時間: {weekly_reset}'.format(**usage))
                        
            if not usage:
                return False


            if usage['weekly_usage'] > 90:
                return False
            if usage['current_usage'] > 90:
                return False
            
            await page.goto("https://gemini.google.com")
            await page.pause()    
        else:
            await self.login(page)
            
    async def submit_prompt(self, page, text, src_uris, dest_uri):
        input_selector = "div.ql-editor.textarea.new-input-ui p"
        send_btn_selector = 'button:has(mat-icon[fonticon="arrow_upward"])'

        await page.goto("https://gemini.google.com")
        
        locator = page.locator(input_selector)
        await expect(locator).to_be_attached()
        await locator.fill(text)

        allUploaded = True
        for src_uri in src_uris:
            isUploaded = await self.upload_file_to_gemini_with_chooser(page, src_uri)
            allUploaded = allUploaded and isUploaded

        if allUploaded:
            return True
        else:
            return False