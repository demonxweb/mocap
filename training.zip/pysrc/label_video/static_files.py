import os
import sys
from label_video import settings

from fastapi import HTTPException
from fastapi.responses import FileResponse
import mimetypes

from fastapi import APIRouter
router = APIRouter()

@router.get("/train/{file_path:path}")
def get_file(file_path: str):
    # 將 BASE_DIR 與請求的路徑結合
    print(file_path)
    full_path = os.path.join(settings.BASE_DIR, file_path)
    
    # 檢查檔案是否存在
    if not os.path.exists(full_path) or not os.path.isfile(full_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    media_type, _ = mimetypes.guess_type(full_path)
    if media_type is None:
        media_type = "application/octet-stream"
        
    return FileResponse(full_path, media_type=media_type)