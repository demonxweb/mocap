
from fastapi import APIRouter,HTTPException, File, Form,UploadFile
from fastapi.responses import JSONResponse
router = APIRouter()
from label_video.database import LabelDatabase
from label_video import settings
from label_video import utils

import os,shutil


def video_path():
    path = os.path.join(settings.BASE_DIR, "video")
    return path

def video_uri(video_id):
    path = video_path()
    filename = f'v_{video_id:08d}.mp4'
    return os.path.join(path, filename)

def video_url(video_id):
    filename = f'v_{video_id:08d}.mp4'
    return f'/train/video/{filename}'



@router.get("/api/video")
def get_videos():
    db = LabelDatabase(settings.project)
    sql = 'SELECT id, prompt FROM video'
    columns, rows = db.fetchall(sql)
    db.close()
    
    data = db.to_dict(columns, rows)
    
    result = [
        {**item, "url": video_url(item["id"])} 
        for item in data
    ]
    
    return JSONResponse(content=result)

@router.post("/api/video")
async def post_video(
    file: UploadFile = File(...), 
    # filename: str = Form(...),
):

    if not file or not file.filename:
        raise HTTPException(status_code=400, detail="未選擇任何上傳檔案")
   
    db = LabelDatabase(settings.project)

    try:
        video_id = db.insert('video',{'prompt':''})

        try:
            save_path = video_path()
            os.makedirs(save_path, exist_ok=True)
            
            file_path = video_uri(video_id)

            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)        

            db.commit()    
        except Exception as e:
            db.rollback()
            if file_path and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except OSError:
                    pass            
            raise HTTPException(status_code=500, detail=str(e))

        return {"message": "add video success.", "url": video_url(video_id)}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        
        db.close()    
    

@router.put("/api/video")
async def put_video(data: dict):
    checklist = ['id']
    utils.check_columns(checklist,data)
   
    db = LabelDatabase(settings.project)

    try:
        db.update('video',data)
        return {"message": "update video success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@router.delete("/api/video")
def delete_video(video_id: int):
    db = LabelDatabase(settings.project)
    try:

        file_path = video_uri(video_id)
        if os.path.exists(file_path):
            os.remove(file_path)

        db.delete('video',video_id)

        return {"message": "delete tag group success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()    