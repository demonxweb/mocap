import sqlite3
import json,os
from label_video import settings

class LabelDatabase():

    def __init__(self,project):
        self.project = project
        os.makedirs(settings.BASE_DIR, exist_ok=True)
        self.db_path = os.path.join(settings.BASE_DIR,f'{project}.db')
        self.conn = None

        if not os.path.exists(self.db_path):
            self.init_db()
        


    def connect(self):
        if self.conn is None:
            self.conn = sqlite3.connect(self.db_path)
            return self.conn
        else:
            return self.conn
        
    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None


    def rollback(self):
        if self.conn:
            self.conn.rollback()

    def commit(self):
        if self.conn:
            self.conn.commit()

       
    def insert(self,table_name,row,or_ignore=False,commit=True):
        conn = self.connect()
        cursor = conn.cursor() 
        klist = []
        vlist = []
        for k,v in row.items():
            klist.append(k)
            vlist.append(v)


        setklist = ','.join(klist)
        setvlist = ','.join(['?']*len(klist))
        if or_ignore:
            sql = f"INSERT OR IGNORE INTO {table_name} ({setklist}) VALUES ({setvlist});"
        else:
            sql = f"INSERT INTO {table_name} ({setklist}) VALUES ({setvlist});"

        cursor.execute(sql, (*vlist,))

        new_id = cursor.lastrowid

        if commit:
            conn.commit()

        return new_id

    def update(self, table_name, row,commit=True):
        conn = self.connect()
        cursor = conn.cursor()      

        klist = []
        vlist = []
        target_id = None
        
        for k, v in row.items():
            if k in ['id']:
                target_id = v
                continue
            # 這裡只存 "column = ?"
            klist.append('{} = ?'.format(k))
            vlist.append(v)

        if not target_id:
            return

        # 用逗號把多個 "column = ?" 串接起來
        setlist = ', '.join(klist)

        # 在這裡手動補上 SET 關鍵字
        sql = f"UPDATE {table_name} SET {setlist} WHERE id = ?"

        cursor.execute(sql, (*vlist, target_id))        
        if commit:
            conn.commit()

    def delete(self,table_name,target_id):
        conn = self.connect()
        cursor = conn.cursor() 
        sql = f"DELETE FROM {table_name} WHERE id = ?"
        cursor.execute(sql, (target_id,))
        conn.commit()

    def execute(self,sql,args):
        conn = self.connect()
        cursor = conn.cursor() 
        if args:
            cursor.execute(sql,args)
        else:
            cursor.execute(sql)
        conn.commit()


    def fetchall(self, sql, params=None):
        conn = self.connect()
        cursor = conn.cursor()
        
        if params:
            cursor.execute(sql, params)
        else:
            cursor.execute(sql)
            
        rows = cursor.fetchall()
        columns = [description[0] for description in cursor.description] if cursor.description else []
        return columns, rows
    
    def fetch(self,sql, params=None):
        conn = self.connect()
        cursor = conn.cursor() 

        if params:
            cursor.execute(sql, params)
        else:
            cursor.execute(sql)
        columns = [col[0] for col in cursor.description]
        row = cursor.fetch()
        return columns,row
    
    def to_dict(self,columns,rows):
        return [dict(zip(columns, row)) for row in rows]
        
    
    def showtables(self):
        sql = 'SELECT name FROM sqlite_master WHERE type="table" ORDER BY name;'

        columns,rows = self.fetchall(sql)

        return [row[0] for row in rows]
    
    def init_db(self):
        conn = self.connect()
        cursor = conn.cursor()    
        
        # 開啟外鍵支援
        cursor.execute("PRAGMA foreign_keys = ON;")

        # tag_group 資料表 (儲存群組名稱)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tag_group (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_name TEXT UNIQUE,
                tp TEXT
            )
        ''')
        
        # tags 資料表 (儲存標籤名稱與所屬群組)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tag (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tag_group_id INTEGER,
                name TEXT,
                UNIQUE(name, tag_group_id)
            )
        ''')


        # video 資料表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS video (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                prompt TEXT
            )
        ''')        
        
        # captures 資料表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS capture (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id INTEGER,
                video_time REAL,                
                prompt TEXT
            )
        ''')
        # bbox 資料表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bbox (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                capture_id INTEGER,
                x REAL,
                y REAL,
                width REAL,
                height REAL,
                prompt TEXT,
                design_id INTEGER
            )
        ''')             

        # design 資料表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS design (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bbox_id INTEGER,
                name TEXT,
                prompt TEXT,
                rate INTEGER
            )
        ''')


        # generate 資料表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS generate (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                capture_id INTEGER,
                designs TEXT,
                rate INTEGER
            )
        ''')
   

        conn.commit()

        self.default_group()
        
    def default_group(self):
        datalist = [
            {'group_name':"物種"},
            {'group_name':"職業"},
            {'group_name':"頭髮"},
            {'group_name':"服飾"},
            {'group_name':"姿態"},
            {'group_name':"情緒"},

            {'group_name':"場景"},
            {'group_name':"鏡位"},
            {'group_name':"構圖"},
            {'group_name':"光線"},
            {'group_name':"氛圍"},
            {'group_name':"風格"},

        ]
        for row in datalist:
            self.insert('tag_group',row,or_ignore=True)
