from label_video import server
import sys,asyncio

if __name__ == "__main__":
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    import uvicorn
    uvicorn.run("label_video.server:app", host="127.0.0.1", port=8000, reload=True)