
from fastapi import APIRouter,HTTPException
from fastapi.responses import JSONResponse
router = APIRouter()
from label_video.database import LabelDatabase
from label_video import settings
from label_video import utils

@router.get("/api/bbox/{capture_id}")
def get_bbox(capture_id:int):
    db = LabelDatabase(settings.project)
    sql = 'SELECT * FROM bbox where capture_id = ?'
    columns,rows = db.fetchall(sql,(capture_id,))
    db.close()
    return JSONResponse(content=db.to_dict(columns,rows))

@router.post("/api/bbox")
async def post_bbox(data: dict):
    checklist = ['capture_id','x','y','width','height']
    utils.check_columns(checklist,data)
    
    db = LabelDatabase(settings.project)

    try:
        new_id = db.insert('bbox',data)
        return {"message": "add bbox success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@router.put("/api/bbox")
async def put_bbox(data: dict):
    checklist = ['id']
    utils.check_columns(checklist,data)

   
    db = LabelDatabase(settings.project)

    try:
        
        db.update('bbox',data)
        return {"message": "update bbox success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@router.delete("/api/bbox/{bbox_id}")
def delete_bbox(bbox_id: int):
    db = LabelDatabase(settings.project)
    try:
        db.execute("DELETE FROM bbox WHERE id = ?", (bbox_id,))
        return {"message": "delete bbox success",'id':bbox_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()    



