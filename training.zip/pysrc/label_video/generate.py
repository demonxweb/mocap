
from fastapi import APIRouter,HTTPException, File, Form,UploadFile
from typing import Optional
from fastapi.responses import JSONResponse
router = APIRouter()
from label_video.database import LabelDatabase
from label_video import settings
from label_video import utils
import os,shutil


def generate_path():
    path = os.path.join(settings.BASE_DIR, "generate")
    return path

def generate_uri(generate_id):
    path = generate_path()
    filename = f'{generate_id:08d}.png'
    return os.path.join(path, filename)

def generate_url(generate_id):
    filename = f'{generate_id:08d}.png'
    return f'/train/generate/{filename}'

@router.get("/api/generate")
def get_generate():
    try:
        db = LabelDatabase(settings.project)
        sql = 'SELECT * FROM generate'
        columns,rows = db.fetchall(sql)
        db.close()
        return JSONResponse(content=db.to_dict(columns,rows))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
    
@router.post("/api/generate")
async def post_generate(
    file: Optional[UploadFile] = File(None), 
    data: Optional[str] = Form(None)
):

    if not file:
        raise HTTPException(status_code=400, detail="未選擇任何上傳檔案")
    
        
    checklist = ['name']
    utils.check_columns(checklist, data)
    
    db = LabelDatabase(settings.project)
    file_path = None

    try:

        new_id = db.insert('generate', data, commit=False)

        try:
            save_path = generate_path()
            os.makedirs(save_path, exist_ok=True)
            
            file_path = generate_uri(new_id)

            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)        

            db.commit()    
        except Exception as e:
            db.rollback()
            if file_path and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except OSError:
                    pass        
            raise HTTPException(status_code=500, detail=str(e))

        return {"message": "add capture success.", "url": generate_url(new_id), "id": new_id}
    
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@router.put("/api/generate")
async def put_generate(data: dict):
    checklist = ['id']
    utils.check_columns(checklist,data)

   
    db = LabelDatabase(settings.project)

    try:
        
        db.update('generate',data)
        return {"message": "update generate success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@router.delete("/api/generate/{generate_id}")
def delete_generate(generate_id: int):
    db = LabelDatabase(settings.project)

    try:
        
        sql = "SELECT id FROM generate WHERE id = ?"
        columns, rows = db.fetchall(sql, (generate_id,))
        if not rows:
            raise HTTPException(status_code=404, detail="找不到指定的截圖記錄")
            
        
        db.execute("DELETE FROM generate WHERE id = ?", (generate_id,))
        db.commit()
        
        
        file_path = generate_uri(generate_id)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass
                
        return {"message": "delete capture success.", "id": generate_id}
        
    except HTTPException as he:
        db.rollback()
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


