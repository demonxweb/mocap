
from fastapi import APIRouter,HTTPException, File, Form,UploadFile
from fastapi.responses import JSONResponse
router = APIRouter()
from label_video.database import LabelDatabase
from label_video import settings
from label_video import utils

import os,shutil


def capture_path():
    path = os.path.join(settings.BASE_DIR, "capture")
    return path

def capture_uri(capture_id):
    path = capture_path()
    filename = f'cap_{capture_id:08d}.png'
    return os.path.join(path, filename)

def capture_url(capture_id):
    filename = f'cap_{capture_id:08d}.png'
    return f'/train/capture/{filename}'



@router.get("/api/capture")
def get_captures(video_id: int = None):
    db = LabelDatabase(settings.project)
    
    try:
        if video_id is not None:
            sql = 'SELECT id, video_id, video_time, prompt FROM capture WHERE video_id = ?'
            columns, rows = db.fetchall(sql, (video_id,))
        else:
            sql = 'SELECT id, video_id, video_time, prompt FROM capture'
            columns, rows = db.fetchall(sql)
            
        # 在關閉連線前，先轉成 dict
        data = db.to_dict(columns, rows)
        
        result = [
            {**item, "url": capture_url(item["id"])} 
            for item in data
        ]
        
        return JSONResponse(content=result)

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        # 確保無論成功或失敗，連線一定會被關閉
        db.close()

@router.post("/api/capture")
async def post_capture(
    file: UploadFile = File(...), 
    video_id: int = Form(...),          
    video_time: float = Form(...),      
):
    if not file or not file.filename:
        raise HTTPException(status_code=400, detail="未選擇任何上傳檔案")
    
    db = LabelDatabase(settings.project)
    file_path = None

    try:
        # 1. 檢查是否已經存在相同的 video_id 與 video_time
        check_sql = "SELECT id FROM capture WHERE video_id = ? AND video_time = ?"
        columns, rows = db.fetchall(check_sql, (video_id, video_time))
        
        if rows:
            # 如果已經存在，直接回傳已存在的記錄（或回傳 400/200 視需求而定）
            existing_id = rows[0][0]
            raise HTTPException(status_code=400, detail=f"圖片已經存在: {capture_url(existing_id)}")

        # 2. 若不存在，組合資料並執行新增
        row_data = {
            'video_id': video_id,
            'video_time': video_time,
            'prompt': ''
        }
        
        capture_id = db.insert('capture', row_data, commit=False)

        try:
            save_path = capture_path()
            os.makedirs(save_path, exist_ok=True)
            
            file_path = capture_uri(capture_id)

            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)        

            db.commit()    
        except Exception as e:
            db.rollback()
            if file_path and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except OSError:
                    pass        
            raise HTTPException(status_code=500, detail=str(e))

        return {"message": "add capture success.", "url": capture_url(capture_id), "id": capture_id}
    
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()
    

@router.put("/api/capture")
async def put_capture(data: dict):
    checklist = ['id']
    utils.check_columns(checklist,data)
   
    db = LabelDatabase(settings.project)

    try:
        db.update('capture',data)
        return {"message": "update capture success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@router.delete("/api/capture/{capture_id}")
def delete_capture(capture_id: int):
    db = LabelDatabase(settings.project)
    
    try:
        # 1. 檢查該筆截圖是否存在
        sql = "SELECT id FROM capture WHERE id = ?"
        columns, rows = db.fetchall(sql, (capture_id,))
        if not rows:
            raise HTTPException(status_code=404, detail="找不到指定的截圖記錄")
            
        # 2. 刪除資料庫紀錄
        db.execute("DELETE FROM capture WHERE id = ?", (capture_id,))
        db.commit()
        
        # 3. 刪除對應的實體圖片檔案
        file_path = capture_uri(capture_id)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass
                
        return {"message": "delete capture success.", "id": capture_id}
        
    except HTTPException as he:
        db.rollback()
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()