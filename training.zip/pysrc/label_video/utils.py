
from fastapi import HTTPException

def check_columns(checklist,row):
    for c in checklist:
        if not row.get(c):
            raise HTTPException(status_code=400, detail=f"miss data:'{c}'")
    
    return True
    