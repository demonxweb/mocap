
from fastapi import APIRouter,HTTPException, File, Form,UploadFile
from typing import Optional
from fastapi.responses import JSONResponse
router = APIRouter()
from label_video.database import LabelDatabase
from label_video import settings
from label_video import utils
import os,shutil


def design_path():
    path = os.path.join(settings.BASE_DIR, "design")
    return path

def design_uri(design_id):
    path = design_path()
    filename = f'{design_id:08d}.png'
    return os.path.join(path, filename)

def design_url(design_id):
    filename = f'{design_id:08d}.png'
    return f'/train/design/{filename}'

@router.get("/api/design")
def get_design():
    try:
        db = LabelDatabase(settings.project)
        sql = 'SELECT * FROM design'
        columns,rows = db.fetchall(sql)

        data = db.to_dict(columns, rows)
        
        result = [
            {**item, "url": design_url(item["id"])} 
            for item in data
        ]

        db.close()
        return JSONResponse(content=result)

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/api/design")
async def post_design(
    file: Optional[UploadFile] = File(None), 
    data: Optional[str] = Form(None)
):

    if not file:
        raise HTTPException(status_code=400, detail="未選擇任何上傳檔案")
    
        
    # checklist = ['name']
    # utils.check_columns(checklist, data)

    if not data:
        data= {
            'prompt': ''
        }
    
    db = LabelDatabase(settings.project)
    file_path = None

    try:

        new_id = db.insert('design', data, commit=False)

        try:
            save_path = design_path()
            os.makedirs(save_path, exist_ok=True)
            
            file_path = design_uri(new_id)

            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)        

            db.commit()    
        except Exception as e:
            db.rollback()
            if file_path and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except OSError:
                    pass        
            raise HTTPException(status_code=500, detail=str(e))

        return {"message": "add capture success.", "url": design_url(new_id), "id": new_id}
    
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@router.put("/api/design")
async def put_design(data: dict):
    checklist = ['id']
    utils.check_columns(checklist,data)

   
    db = LabelDatabase(settings.project)

    try:
        
        db.update('design',data)
        return {"message": "update design success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@router.delete("/api/design/{design_id}")
def delete_design(design_id: int):
    db = LabelDatabase(settings.project)

    try:
        
        sql = "SELECT id FROM design WHERE id = ?"
        columns, rows = db.fetchall(sql, (design_id,))
        if not rows:
            raise HTTPException(status_code=404, detail="找不到指定的截圖記錄")
            
        
        db.execute("DELETE FROM design WHERE id = ?", (design_id,))
        db.commit()
        
        
        file_path = design_uri(design_id)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass
                
        return {"message": "delete capture success.", "id": design_id}
        
    except HTTPException as he:
        db.rollback()
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


