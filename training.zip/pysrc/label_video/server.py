from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
import shutil
import mimetypes
import os
import sys
import sqlite3
import json
from pathlib import Path

from label_video import settings
from label_video import static_files
from label_video import tags
from label_video import video
from label_video import capture
from label_video import bbox
from label_video import design
from label_video import generate

from generation import convert_target


app = FastAPI()

# 啟用 CORS 讓 Vite 的開發伺服器能存取 API
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allow_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(tags.router)
app.include_router(video.router)
app.include_router(capture.router)
app.include_router(bbox.router)
app.include_router(design.router)
app.include_router(generate.router)
app.include_router(static_files.router)

app.include_router(convert_target.router)





