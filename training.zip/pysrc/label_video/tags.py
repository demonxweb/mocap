
from fastapi import APIRouter,HTTPException
from fastapi.responses import JSONResponse
router = APIRouter()
from label_video.database import LabelDatabase
from label_video import settings
from label_video import utils

@router.get("/api/tag_group")
def get_tag_group():
    db = LabelDatabase(settings.project)
    sql = 'SELECT id,group_name,tp FROM tag_group'
    columns,rows = db.fetchall(sql)
    db.close()
    return JSONResponse(content=db.to_dict(columns,rows))

@router.post("/api/tag_group")
async def post_group(data: dict):
    checklist = ['group_name']
    utils.check_columns(checklist,data)
    
    db = LabelDatabase(settings.project)

    try:
        db.insert('tag_group',data)
        return {"message": "add tag group success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@router.put("/api/tag_group")
async def put_group(data: dict):
    checklist = ['id']
    utils.check_columns(checklist,data)
   
    db = LabelDatabase(settings.project)

    try:
        db.update('tag_group',data)
        return {"message": "update tag group success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@router.delete("/api/tag_group")
def delete_group(tag_group_id: int):
    db = LabelDatabase(settings.project)
    try:
        db.execute("DELETE FROM tag_group WHERE id = ?", (tag_group_id,))
        db.execute("DELETE FROM tag WHERE tag_group_id = ?", (tag_group_id,))

        return {"message": "delete tag group success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()    


@router.get("/api/tag")
def get_tag():
    db = LabelDatabase(settings.project)
    sql = 'SELECT id,tag_group_id ,name FROM tag'
    columns,rows = db.fetchall(sql)
    db.close()
    return JSONResponse(content=db.to_dict(columns,rows))

@router.post("/api/tag")
async def post_tag(data: dict):
    checklist = ['tag_group_id','name']
    utils.check_columns(checklist,data)
    
    db = LabelDatabase(settings.project)

    try:
        db.insert('tag',data)
        return {"message": "add tag success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()

@router.put("/api/tag")
async def put_tag(data: dict):
    checklist = ['id']
    utils.check_columns(checklist,data)
   
    db = LabelDatabase(settings.project)

    try:
        db.update('tag',data)
        return {"message": "update tag success."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@router.delete("/api/tag")
def delete_tag(tag_id: int): # 函式名稱也可以順便改為 delete_tag
    db = LabelDatabase(settings.project)
    try:
        # 修正：刪除單一 tag 應該用 id 而不是 tag_group_id
        db.execute("DELETE FROM tag WHERE id = ?", (tag_id,))
        db.commit() # 記得要 commit 才會寫入資料庫

        return {"message": "delete tag success"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


