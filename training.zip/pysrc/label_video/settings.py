
BASE_DIR = "D:/training"


allow_origins = ["http://localhost:5173"],

project = 'test'