from playwright.sync_api import sync_playwright
from playwright.async_api import async_playwright
from playwright.async_api import expect
import time,asyncio,os



async def drop_file(page, drop_selector: str, file_path: str):
    # 1. 讀取檔案內容
    with open(file_path, "rb") as f:
        file_content = f.read()
    
    # 2. 取得檔名
    file_name = os.path.basename(file_path)
    
    # 3. 傳入打包好的字典，並將 JS 註解修正為 //
    await page.evaluate("""
        async (args) => {
            const { dropSelector, fileName, fileContent } = args;
            
            const dropZone = document.querySelector(dropSelector);
            if (!dropZone) throw new Error('Drop zone not found');
            
            // 修正點：改用 // 註解。將 Python 傳進來的 list 轉回 JS 的 Uint8Array
            const bytes = new Uint8Array(fileContent);
            
            // 修正點：改用 // 註解。建立 File 物件
            const file = new File([bytes], fileName, { type: 'text/html' });
            
            // 修正點：改用 // 註解。建立 DataTransfer
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            
            // 修正點：改用 // 註解。觸發 drop 事件
            const dropEvent = new DragEvent('drop', {
                bubbles: true,
                cancelable: true,
                dataTransfer: dataTransfer
            });
            
            dropZone.dispatchEvent(dropEvent);
        }
    """, {
        "dropSelector": drop_selector,
        "fileName": file_name,
        "fileContent": list(file_content)
    })

    print('drop finish.')


async def open_stream_file(page,file_path):
    file_name = os.path.basename(file_path)
    with open(file_path, 'rb') as f:
        file_bytes = f.read()

    data_transfer_handle = await page.evaluate_handle("""
        async ({ fileBytes, fileName }) => {
            const dt = new DataTransfer();
            const blob = new Blob([new Uint8Array(fileBytes)], { type: 'application/octet-stream' });
            const file = new File([blob], fileName, { type: 'application/octet-stream' });
            dt.items.add(file);
            return dt;
        }
    """, { "fileBytes": list(file_bytes), "fileName": file_name }) 

    return data_transfer_handle

async def dropfile2(page, input_selector, drop_selector, file_path):
    file_name = os.path.basename(file_path)

    with open(file_path, 'r', encoding='utf-8') as f:
        text_content = f.read()

    # data_transfer_handle = await page.evaluate_handle("""
    #     async ({ textContent, fileName }) => {
    #         const dt = new DataTransfer();
    #         const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    #         const file = new File([blob], fileName, { type: 'text/plain;charset=utf-8' });
    #         dt.items.add(file);
    #         return dt;
    #     }
    # """, { "textContent": text_content, "fileName": file_name })

    # 這是能夠破解複雜框架的「高強度偽造 DataTransfer」
    data_transfer_handle = await page.evaluate_handle("""
        async ({ textContent, fileName }) => {
            const dt = new DataTransfer();
            const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
            const file = new File([blob], fileName, { type: 'text/plain;charset=utf-8' });
            
            // 關鍵修正：必須透過 items.add 將其歸類為實體 Files
            dt.items.add(file);
            
            //ifdef CHROMIUM_COMPATIBLE
            // 某些防護極嚴格的平台會檢查 types 陣列是否存在 "Files"
            Object.defineProperty(dt, 'types', {
                get: function() { return ['Files']; }
            });
            //endif
            
            return dt;
        }
    """, { "textContent": text_content, "fileName": file_name })

    # ---- 第一階段：觸發 input 顯示 drop 區域 ----

    await page.mouse.move(0, 0)

    x, y = await get_bounding(page, input_selector)
    print("Input 座標:", x, y)

    await page.mouse.move(x, y)
    
    await page.dispatch_event(
        input_selector,
        'dragenter',
        {
            'dataTransfer': data_transfer_handle,
            'clientX': x,
            'clientY': y
        }
    )

    await page.dispatch_event(
        input_selector, 
        'dragover', 
        {
            'dataTransfer': data_transfer_handle,
            'clientX': x,
            'clientY': y
        }
    )

    await page.wait_for_timeout(1000)

    # ---- 第二階段：移動到 drop 區域並釋放 ----
    x, y = await get_bounding(page, drop_selector)
    print("Drop 區域座標:", x, y)

    # 滑鼠實際移動過去
    await page.mouse.move(x, y)

    # 【關鍵修正 1】必須先告訴 drop_selector 檔案現在在它上方（啟動接收狀態）
    await page.dispatch_event(
        drop_selector, 
        'dragover', 
        {
            'dataTransfer': data_transfer_handle,
            'clientX': x,
            'clientY': y
        }
    )
    
    # 稍微給瀏覽器 100 毫秒反應時間（選填，提高穩定度）
    await page.wait_for_timeout(1000)

    # 【關鍵修正 2】執行 drop 事件
    await page.dispatch_event(
        drop_selector, 
        'drop', 
        {
            'dataTransfer': data_transfer_handle,
            'clientX': x,
            'clientY': y
        }
    )
    
    print('drop done')


async def get_bounding(page,selector):
    target_element = page.locator(selector)
    box = await target_element.bounding_box()

    if box:
        # 3. 計算出元素的中心點座標
        center_x = box['x'] + box['width'] / 2
        center_y = box['y'] + box['height'] / 2

        return center_x,center_y


