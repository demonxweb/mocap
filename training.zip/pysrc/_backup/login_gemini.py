from playwright.sync_api import sync_playwright
from playwright.async_api import async_playwright
from playwright.async_api import expect
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
import time,asyncio,os,re,datetime,random

from contextlib import asynccontextmanager

@asynccontextmanager
async def start(session_path=None):

    async with async_playwright() as p:
        # launch_persistent_context
        context = await p.chromium.launch_persistent_context(
            session_path,
            headless=False,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-infobars',
                '--start-maximized',
            ],
            viewport={'width': 1024, 'height': 720},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
            # devtools=True,
        )
        

        yield context

        await context.close()






async def check_login(page):
    locator = page.get_by_role("button", name="登入")
    buttons = await locator.all()
    login_button_count = len(buttons)

    locator = page.get_by_label(re.compile("Google .* (.*@gmail.com)"))
    buttons = await locator.all()
    account_button_count = len(buttons)
    # print('login_button_count',login_button_count)
    # print('account_button_count',account_button_count)
    if login_button_count==0 and account_button_count>=1:
        return True
    else:
        return False



async def upload_file_to_gemini_with_chooser(page, file_path):
    add_file_btn_selector = 'input-area-v2 simplified-input-menu gem-icon-button button'
    upload_menu_selector = 'span.gem-menu-item-label:has-text("上傳檔案"), span:has-text("Upload files")'
    # 定位同意按鈕的 Selector
    agree_btn_selector = '[data-test-id="upload-image-agree-button"]'

    # 1. 註冊監聽器：一旦彈出 file dialog，立刻接管並處理檔案，然後自動關閉它
    async def handle_file_chooser(file_chooser):
        print("系統檔案視窗已彈出，Playwright 正在攔截並自動關閉它...")
        await file_chooser.set_files(file_path) # 這會填入檔案並自動關閉 dialog

    page.on("filechooser", handle_file_chooser)

    
        # 2. 正常執行點擊流程

    isUploaded = False

    for i in range(3):
        try:
            await page.wait_for_selector(add_file_btn_selector, state="visible", timeout=5000)
            await page.click(add_file_btn_selector, force=True)
            
            # 3. 點擊上傳選單項目
            await page.wait_for_selector(upload_menu_selector, state="visible", timeout=3000)
            await page.click(upload_menu_selector)
        except PlaywrightTimeoutError:
            print('uploadload timeout')
            await page.wait_for_timeout(8000)

        finally:
    
            # ==========================================
            # 4. 檢查是否有跳出「同意」免責聲明對話方塊
            # ==========================================
            agree_btn = page.locator(agree_btn_selector)
            try:
                # 嘗試等待同意按鈕出現（給予 2 秒的短暫判斷時間）
                if await agree_btn.is_visible(timeout=2000):
                    await agree_btn.click()
                    print("【提示】已自動按下同意免責事項按鈕。")
                    
                    # 有時候按下同意後，需要再次點擊上傳按鈕才能真正叫出檔案選擇器
                    # 如果你的網頁按下同意後會直接繼續，可註解掉下面這段
                    await page.click(add_file_btn_selector, force=True)
                    await page.click(upload_menu_selector)
            except Exception:
                # 沒出現同意按鈕就直接略過，不影響後續
                pass
                
            isUploaded = True
            break

    print("【成功】檔案已透過 FileChooser 注入，Dialog 已自動關閉。")
    page.remove_listener("filechooser", handle_file_chooser)

    await page.wait_for_timeout(2000)
    return isUploaded


    


async def download(page):
    download_btn_selector = 'button[aria-label*="下載"], button:has(mat-icon[fonticon="download"])'

    # 2. 開啟 Playwright 的下載監聽事件鏈 (注意：這裡不加 await)
    async with page.expect_download() as download_info:
        # 3. 點擊網頁上的下載按鈕，觸發瀏覽器下載行為
        await page.click(download_btn_selector)

    # 4. 等待下載完成並取得下載物件
    download = await download_info.value

    # 5. 將檔案儲存至本機指定路徑 (如果不指定檔名，可以用 download.suggested_filename)
    save_path = f"D:/{download.suggested_filename}"
    await download.save_as(save_path)    




async def download_all_generated_images(page, save_directory="D:/GeminiDownloads"):
    # 1. 建立本機儲存資料夾（如果不存在的話）
    if not os.path.exists(save_directory):
        os.makedirs(save_directory)

    # 2. 根據你提供的長路徑，提煉出最具唯一性且兼顧多圖定位的精簡 CSS 選擇器
    # 鎖定所有在 generated-image 區塊內的下載按鈕
    download_buttons_selector = 'generated-image download-generated-image-button button'

    print("正在偵測畫面上的生成圖片下載按鈕...")
    
    # 3. 等待至少第一個下載按鈕渲染完成且可見
    try:
        await page.wait_for_selector(download_buttons_selector, state="visible", timeout=60000)
    except Exception:
        print("【錯誤】超時！畫面上沒有出現任何圖片下載按鈕。")
        return

    # 4. 【核心步驟】獲取畫面上所有符合條件的下載按鈕列表
    # locator.all() 會回傳一個包含所有按鈕的實例列表 (List)
    buttons = await page.locator(download_buttons_selector).all()
    total_images = len(buttons)
    print(f"【偵測成功】共發現 {total_images} 張生成的圖片準備下載。")


    await page.wait_for_timeout(10000)


    # 5. 使用迴圈依序為每張圖片執行攔截與點擊
    for index, button in enumerate(buttons, start=1):

        print(f"正在下載第 {index}/{total_images} 張圖片...")
        
        try:
            # 確保按鈕滾動到可視範圍，避免被其他前端元件遮擋
            await button.scroll_into_view_if_needed()

            await expect(button).to_be_enabled(timeout=5000)

            await button.hover()
            await page.wait_for_timeout(1000)
               
            
            # 開啟 Playwright 的下載接管監聽（注意：此處不加 await）
            async with page.expect_download() as download_info:
                # 執行點擊，有些按鈕藏在懸停選單內，加上 force=True 確保穿透觸發
                await button.click(force=True)
            
            # 等待當前圖片下載流程完成
            download = await download_info.value
            
            # 建立具備唯一性的本地檔名（例如：gemini_img_1.png）
            file_extension = os.path.splitext(download.suggested_filename)[1] or ".png"
            final_filename = f"gemini_img_{index}{file_extension}"
            full_save_path = os.path.join(save_directory, final_filename)
            
            # 將檔案儲存至本機
            await download.save_as(full_save_path)
            print(f"→ 第 {index} 張圖片儲存成功：{full_save_path}")
            
            # 每張圖片下載間隔 500 毫秒，避免連續請求造成瀏覽器崩潰或被伺服器阻擋
            await page.wait_for_timeout(500)
            
        except Exception as e:
            print(f"❌ 第 {index} 張圖片下載失敗。原因: {e}")

    print(f"【任務完成】所有圖片下載程序已結束，請至 {save_directory} 查看。")

import os
from playwright.async_api import expect

async def download_first_generated_image(page, full_save_path):


    # 2. 鎖定生成圖片的下載按鈕選擇器
    # download_buttons_selector = 'generated-image download-generated-image-button button'
    # download_buttons_selector = 'button[aria-label*="下載"]'
    download_buttons_selector = 'button[aria-label="下載原尺寸圖片"]'

    print("正在偵測畫面上的生成圖片下載按鈕...")
    
    # 3. 等待至少第一個下載按鈕渲染完成且可見
    try:
        await page.wait_for_selector(download_buttons_selector, state="visible", timeout=60000)
    except Exception:
        print("【錯誤】超時！畫面上沒有出現任何圖片下載按鈕。")
        return

    # 4. 只選取畫面上第一張圖片的下載按鈕 (.first)
    first_button = page.locator(download_buttons_selector).first
    
    print("【偵測成功】準備下載第一張生成的圖片。")
    await page.wait_for_timeout(10000)

    try:
        # 確保按鈕滾動到可視範圍，避免被其他前端元件遮擋
        await first_button.scroll_into_view_if_needed()

        await expect(first_button).to_be_enabled(timeout=5000)

        await first_button.hover()
        await page.wait_for_timeout(1000)
             
        # 開啟 Playwright 的下載接管監聽
        async with page.expect_download() as download_info:
            # 執行點擊，加上 force=True 確保穿透觸發
            await first_button.click(force=True)
        
        # 等待下載流程完成
        download = await download_info.value
        
        # 將檔案儲存至本機
        await download.save_as(full_save_path)
        print(f"→ 第一張圖片儲存成功：{full_save_path}")
        
    except Exception as e:
        print(f"❌ 第一張圖片下載失敗。原因: {e}")

    print(f"【任務完成】圖片下載程序已結束，請至 {full_save_path} 查看。")    


async def submit_prompt(page,text,src_uris,dest_uri):
    input_selector = "div.ql-editor.textarea.new-input-ui p"
    send_btn_selector = 'button:has(mat-icon[fonticon="arrow_upward"])'



    
    # await page.goto("https://gemini.google.com/app/bad51465b69fadbe")
    await page.goto("https://gemini.google.com")
    
    # 等待頁面載入完成
    # await page.wait_for_load_state("networkidle")
    # print("已使用保存狀態登入 Gemini！")

    
    # 這裡可以繼續你的操作，例如發送 prompt
    locator = page.locator(input_selector)
    # locator = page.locator("div.input-area")
    r = await expect(locator).to_be_attached()
    # 使用 evaluate 傳入 lambda/function 設定 innerHTML

    await locator.fill(text)

    # await expect(locator).to_have_text(text)
    # content = await page.locator("div.ql-editor.textarea.new-input-ui").inner_text()
    # print(content)
    # assert text in content

    # print(f'inputed text: {text}')


    # 上傳圖片
    allUploaded = True
    for src_uri in src_uris:
        isUploaded = await upload_file_to_gemini_with_chooser(page,src_uri)
        allUploaded = allUploaded and isUploaded

    if allUploaded:

        await page.wait_for_selector(send_btn_selector, state="visible", timeout=120000)
        await page.click(send_btn_selector)
        await download_first_generated_image(page, dest_uri)

        await page.wait_for_url("**/app/*", timeout=10000)

        # current_url = page.url
        # print(f"跳轉後的最新網址: {current_url}")
        return True
    else:
        return False


def get_time(t):
    today = datetime.datetime.now()
    try:
        dt = datetime.datetime.strptime(t, "%m/%d %p%I:%M")
        dt = dt.replace(year=today.year)
    except ValueError:
        dt = datetime.datetime.strptime(t, "%p%I:%M")
        dt = dt.replace(year=today.year, month=today.month, day=today.day)
    return dt.strftime('%m-%d %H:%M')    
        
async def get_useage(page):

    await page.goto('https://gemini.google.com/usage')

    # await asyncio.sleep(2)
    

    locator = page.get_by_text("目前用量")
    await locator.wait_for(state="visible")


    # locator = page.get_by_text(re.compile('每週上限')).locator("xpath=../../..")
    locator = page.locator("div.usage-metrics-container > div.gxu-items-container")

    # print(parent)
    divs = await locator.all()
    print('divs',len(divs))

    for div in divs:
        tx = await div.inner_text()
        r = re.findall(r'已使用\s*(\d+)%\s*(?=\n|$)',tx)

        usage = [float(v) for v in r]
        print(usage)

        r = re.findall(r'重設時間：(.+?)\n',tx)
        r = [v.replace('下午','PM').replace('上午','AM').replace('日','').replace('月','/') for v in r]
        reset_time = [get_time(t) for t in r]
        
        k = ['current_usage','weekly_usage','daily_reset','weekly_reset']

        return dict(zip(k,usage+reset_time))

        


async def login_and_save_state(session_path,images):
    
    async with start(session_path) as context:

        page = context.pages[0] if context.pages else await context.new_page()
        
        # 前往 Gemini 登入頁
        await page.goto("https://gemini.google.com")

        

        if await check_login(page):
            print('login success')

            usage = await get_useage(page)
            print(usage)
            if not usage:
                return False
            print('目前用量: {current_usage}%  重設時間: {daily_reset}'.format(**usage))
            print('本周用量: {weekly_usage}%  重設時間: {weekly_reset}'.format(**usage))

            if usage['weekly_usage'] > 90:
                return False
            
            if usage['current_usage'] > 90:
                return False
            
            await page.goto("https://gemini.google.com")

            for src_uris,dest_uri,prompt in images:
                
                await submit_prompt(page,prompt,src_uris,dest_uri)
                await asyncio.sleep(random.randrange(5,15))
                # break
                

            await page.pause()    

        else:
            print('login fail')
            print("\n=============================================")
            print("【提示】請在彈出的瀏覽器中手動完成 Google 登入。")
            print("包括輸入帳密、處理圖形驗證碼，以及手機的 2FA 二階段驗證。")
            print("=============================================\n")            

            locator = page.get_by_label(re.compile("Google .* (.*@gmail.com)"))

            for i in range(10):
                try:
                    await locator.wait_for(state="visible",timeout=30000)
                except PlaywrightTimeoutError:
                    print('wait timeout:',i)
                    continue

                buttons = await locator.all()
                account_button_count = len(buttons)            
                print('account_button_count',account_button_count)
                await asyncio.sleep(10)
                if account_button_count>0:
                    print('完成登入')
                    break
        
            # await page.pause()
        # input("👉 請在『完全登入成功並看到 Gemini 對話畫面』後，回到這裡按下 [Enter] 鍵以儲存狀態...")



VIDEO_DIR = "D:/training"

       

def list_images(src='capture',dest='layout',prompt=''):
    src_output_dir = os.path.join(VIDEO_DIR, src)
    dest_output_dir = os.path.join(VIDEO_DIR, dest)

    ls = []
    for fn in os.listdir(src_output_dir):
        
        dest_uri = os.path.join(dest_output_dir,fn)
        if os.path.exists(dest_uri):
            continue

        src_uri = os.path.join(src_output_dir,fn)

        ls.append(([src_uri],dest_uri,prompt))

    return ls


async def main(session_path):

    # prompt = f'參考圖片中，生成一個 640x480 設計圖，圖中分別有前、後、左、右四個角度的全身圖，照片寫實風格，去除畫面中的文字'
    # images = list_images('character','design',prompt)

    # prompt = f'將圖片改成 手繪 story borad 分鏡圖的樣式，尺寸為1280x720， 只用粗略的線條描繪整個構圖，**不要有外框及標題、字幕等文字**'
    # prompt = f'將圖片改成 3D 灰模的樣式，**不要有顏色**，生成圖片尺寸為1280x720，圖中的人物都使用沒有明確五官、沒有衣服折皺，造型簡化的LOW POLY模型替代，保持動作與圖片一致，**不要有外框及標題、字幕等文字**'
    # images = list_images('capture','layout')

    images = get_layout_prompt()
    

    
    await login_and_save_state(session_path,images)

    
def get_layout_prompt():
    import sqlite3

    VIDEO_DIR = "D:/training"
    DB_PATH = os.path.join(VIDEO_DIR, "annotations.db")    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()    

    # 取得所有 captures
    cursor.execute("SELECT id, filename, source_video, prompt,replace_prompt FROM captures")
    
    design_output_dir = os.path.join(VIDEO_DIR, "design")
    layout_output_dir = os.path.join(VIDEO_DIR, r'layout\paint')
    target_output_dir = os.path.join(VIDEO_DIR, "target")

    

    capture_rows = cursor.fetchall()

    result = []

    for cap in capture_rows:
        capture_id = cap['id']
        if not cap['prompt']:
            continue

        prompt = '參考image_1中的構圖\n{}\n{}'.format(cap['replace_prompt'],cap['prompt'])

        layout_uri = os.path.abspath(os.path.join(layout_output_dir,cap['filename']))

        dest_uri = os.path.abspath(os.path.join(target_output_dir,cap['filename']))
        

        cursor.execute("SELECT id, rect, tags FROM character WHERE capture_id = ?", (capture_id,))
        char_rows = cursor.fetchall()    

        src_uris=[layout_uri]

        for ch in char_rows:
            char_id = ch['id']  # 取得 character 資料表的 id 作為檔名       
            char_uri = os.path.abspath(os.path.join(design_output_dir, f"{char_id}.png"))

            src_uris.append(char_uri)
            

        result.append([src_uris,dest_uri,prompt])
    cursor.close()

    return result

if __name__ == "__main__":
    session_path = r"D:\Develop\browser\sessions\session1"
   
    asyncio.run(main(session_path))