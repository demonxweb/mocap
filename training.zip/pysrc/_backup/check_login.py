from playwright.async_api import async_playwright
from playwright.async_api import expect
import time,asyncio,os,re


async def check_login(page):
    locator = page.get_by_role("button", name="登入")
    buttons = await locator.all()
    login_button_count = len(buttons)

    locator = page.get_by_label(re.compile("Google .* (.*@gmail.com)"))
    buttons = await locator.all()
    account_button_count = len(buttons)

    if login_button_count==0 and account_button_count>=1:
        return True
    else:
        return False


async def main():
    async with async_playwright() as p:

        browser = await p.chromium.launch(
            headless=False,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-infobars',
                '--start-maximized',
            ]
        )
        
        context = await browser.new_context(
            viewport={'width': 1024, 'height': 720},
            storage_state="gemini_auth.json",   # 載入之前保存的狀態
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
        )

        
        page = await context.new_page()
        await page.goto("https://gemini.google.com")         

        if await check_login(page):
            print('login success')
        else:
            print('login fail')
        # for index, button in enumerate(buttons, start=1):
        #     # box = await button.bounding_box()
        #     # is_visible = await button.is_visible()
        #     await button.highlight()

        input("[Enter] to exit")     

        browser.close()


import datetime

if __name__ == "__main__":
    # asyncio.run(main())        



    r = dict(zip(['current_usage','week_usage'],[0.0,1.0]))
    print(r)