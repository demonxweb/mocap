from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
import shutil
import mimetypes
import os
import sys
import sqlite3
import json
from pathlib import Path

current_dir = Path(__file__).resolve().parent
sys.path.append(str(current_dir))

app = FastAPI()

# 啟用 CORS 讓 Vite 的開發伺服器能存取 API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

VIDEO_DIR = "D:/training"
DB_PATH = os.path.join(VIDEO_DIR, "annotations.db")

def init_db():
    os.makedirs(VIDEO_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # 開啟外鍵支援
    cursor.execute("PRAGMA foreign_keys = ON;")
    
    # captures 資料表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS captures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT UNIQUE,
            source_video TEXT,
            prompt TEXT
        )
    ''')
    
    # groups 資料表 (儲存群組名稱)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE
        )
    ''')
    
    # tags 資料表 (儲存標籤名稱與所屬群組)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tags (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            group_name TEXT,
            UNIQUE(name, group_name)
        )
    ''')

    # character 資料表：tags 改為儲存關聯 tags 表的 id 列表 (例如 JSON 格式的 id 陣列)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS character (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            capture_id INTEGER,
            rect TEXT,
            tags TEXT,
            FOREIGN KEY (capture_id) REFERENCES captures(id) ON DELETE CASCADE
        )
    ''')

    conn.commit()
    conn.close()

init_db()

@app.get("/api/group")
def get_groups():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM groups")
    rows = cursor.fetchall()
    conn.close()
    return JSONResponse(content=[row[0] for row in rows])

@app.post("/api/group")
async def add_group(data: dict):
    name = data.get("name")
    if not name:
        raise HTTPException(status_code=400, detail="缺少群組名稱")
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT OR IGNORE INTO groups (name) VALUES (?)", (name,))
        conn.commit()
        conn.close()
        return {"message": "群組新增成功"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/group")
def delete_group(name: str):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM groups WHERE name = ?", (name,))
        cursor.execute("DELETE FROM tags WHERE group_name = ?", (name,))
        conn.commit()
        conn.close()
        return {"message": "群組刪除成功"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ----------------- Tags API -----------------

@app.get("/api/tags")
def get_tags():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, group_name FROM tags")
    rows = cursor.fetchall()
    conn.close()
    
    tags_list = []
    for row in rows:
        tags_list.append({
            "id": row["id"],
            "name": row["name"],
            "group": row["group_name"],
            "isSelected": False
        })
    return JSONResponse(content=tags_list)

@app.post("/api/tags")
async def add_tag(data: dict):
    name = data.get("name")
    group_name = data.get("group")
    if not name or not group_name:
        raise HTTPException(status_code=400, detail="缺少標籤名稱或群組")
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO tags (name, group_name) VALUES (?, ?)", (name, group_name))
        conn.commit()
        new_id = cursor.lastrowid
        conn.close()
        return {"message": "標籤新增成功", "id": new_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/api/tags/{tag_id}")
async def update_tag(tag_id: int, data: dict):
    name = data.get("name")
    group_name = data.get("group")
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("UPDATE tags SET name = ?, group_name = ? WHERE id = ?", (name, group_name, tag_id))
        conn.commit()
        conn.close()
        return {"message": "標籤更新成功"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/tags/{tag_id}")
def delete_tag(tag_id: int):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM tags WHERE id = ?", (tag_id,))
        conn.commit()
        conn.close()
        return {"message": "標籤刪除成功"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/videos")
def get_files():
    file_path = os.path.join(VIDEO_DIR, "video")
    if not os.path.exists(file_path):
        return JSONResponse(content=[])
    files = [f for f in os.listdir(file_path) if f.endswith('.mp4')]
    return JSONResponse(content=files)

@app.get("/api/captures")
def get_captures():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # 取得所有 captures
    cursor.execute("SELECT id, filename, source_video, prompt, replace_prompt FROM captures")
    capture_rows = cursor.fetchall()

    files = []
    for cap in capture_rows:
        capture_id = cap['id']
        f = cap['filename']
        
        # 取得該 capture 對應的所有 character 記錄
        cursor.execute("SELECT rect, tags FROM character WHERE capture_id = ?", (capture_id,))
        char_rows = cursor.fetchall()
        
        boxes_data = []
        for ch in char_rows:
            try:
                rect_obj = json.loads(ch['rect']) if ch['rect'] else {}
                tag_ids = json.loads(ch['tags']) if ch['tags'] else []
                
                # 根據 tag_ids 從 tags 資料表中查詢真實的標籤內容 (id, name, group_name)
                tags_obj = []
                if tag_ids:
                    placeholders = ','.join(['?'] * len(tag_ids))
                    cursor.execute(f"SELECT id, name, group_name FROM tags WHERE id IN ({placeholders})", tag_ids)
                    tag_rows = cursor.fetchall()
                    for t_row in tag_rows:
                        tags_obj.append({
                            "id": t_row['id'],
                            "name": t_row['name'],
                            "group": t_row['group_name']
                        })
                
                boxes_data.append({**rect_obj, "tags": tags_obj})
            except Exception as e:
                print(f"解析 box 資料失敗: {e}")

        files.append({
            'id': capture_id,
            'img': f'train/capture/{f}',
            'fn': f,
            'source_video': cap['source_video'] or '',
            'boxes': boxes_data,
            'prompt': cap['prompt'] or '',
            'replace_prompt': cap['replace_prompt'] or ''
        })
            
    conn.close()
    return JSONResponse(content=files)

@app.post("/api/capture/save")
async def save_image(
    file: UploadFile = File(...), 
    filename: str = Form(...),
    source_video: str = Form(default="")
):
    save_path = os.path.join(VIDEO_DIR, "capture")
    os.makedirs(save_path, exist_ok=True)

    file_path = os.path.join(save_path, filename)
    
    if ".." in filename or filename.startswith("/"):
        raise HTTPException(status_code=400, detail="無效的檔名")
    
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO captures (filename, source_video, prompt,replace_prompt)
            VALUES (?, ?, '','')
            ON CONFLICT(filename) DO UPDATE SET
                source_video = excluded.source_video
        ''', (filename, source_video))
        conn.commit()
        conn.close()
        
        return {"message": "檔案已成功儲存", "path": file_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@app.get("/api/capture/tag")
def get_capture_tag(filename: str):
    if ".." in filename or filename.startswith("/"):
        raise HTTPException(status_code=400, detail="無效的檔名")

    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, filename, source_video, prompt, replace_prompt FROM captures WHERE filename = ?", (filename,))
        row = cursor.fetchone()

        if not row:
            conn.close()
            raise HTTPException(status_code=404, detail="找不到該標記資料")

        capture_id = row['id']
        
        cursor.execute("SELECT rect, tags FROM character WHERE capture_id = ?", (capture_id,))
        box_rows = cursor.fetchall()

        boxes_data = []
        for b_row in box_rows:
            try:
                rect_obj = json.loads(b_row['rect']) if b_row['rect'] else {}
                tag_ids = json.loads(b_row['tags']) if b_row['tags'] else []
                
                tags_obj = []
                if tag_ids:
                    placeholders = ','.join(['?'] * len(tag_ids))
                    cursor.execute(f"SELECT id, name, group_name FROM tags WHERE id IN ({placeholders})", tag_ids)
                    tag_rows = cursor.fetchall()
                    for t_row in tag_rows:
                        tags_obj.append({
                            "id": t_row['id'],
                            "name": t_row['name'],
                            "group": t_row['group_name']
                        })

                boxes_data.append({**rect_obj, "tags": tags_obj})
            except:
                pass

        conn.close()
        return JSONResponse(content={
            'id': row['id'],
            'img': f'train/capture/{row["filename"]}',
            'fn': row['filename'],
            'source_video': row['source_video'] or '',
            'boxes': boxes_data,
            'prompt': row['prompt'] or '',
            'replace_prompt': row['replace_prompt'] or ''
            
        })
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))    

@app.post("/api/capture/tag/save")
async def save_image_tags(data: dict):
    filename = data.get("filename")
    boxes_input = data.get("boxes", [])
    prompt = data.get("prompt", "")
    replace_prompt = data.get("replace_prompt", "")
    

    if not filename:
        raise HTTPException(status_code=400, detail="缺少檔名")

    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA foreign_keys = ON;")
        
        # 1. 確保 captures 記錄存在並更新 prompt
        cursor.execute('''
            INSERT INTO captures (filename, prompt, replace_prompt) 
            VALUES (?, ?, ?) 
            ON CONFLICT(filename) 
            DO UPDATE SET 
                prompt = excluded.prompt,
                replace_prompt = excluded.replace_prompt
        ''', (filename, prompt, replace_prompt))
        
        # 取得 capture_id
        cursor.execute("SELECT id FROM captures WHERE filename = ?", (filename,))
        cap_row = cursor.fetchone()
        capture_id = cap_row[0]

        # 2. 重新寫入 character 表
        cursor.execute("DELETE FROM character WHERE capture_id = ?", (capture_id,))
        
        for box in boxes_input:
            box_copy = box.copy()
            tags_input = box_copy.pop("tags", [])
            
            # 提取每個 tag 的 id（如果前端傳進來的是物件就抓取 id，若本身就是 id 則直接使用）
            tag_ids = []
            for t in tags_input:
                if isinstance(t, dict) and "id" in t:
                    tag_ids.append(t["id"])
                else:
                    # 如果只有名稱或直接就是 id，嘗試尋找對應的 id
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (str(t),))
                    t_res = cursor.fetchone()
                    if t_res:
                        tag_ids.append(t_res[0])
            
            rect_str = json.dumps(box_copy)
            tags_str = json.dumps(tag_ids)  # 儲存 id 列表
            
            cursor.execute('''
                INSERT INTO character (capture_id, rect, tags)
                VALUES (?, ?, ?)
            ''', (capture_id, rect_str, tags_str))
            
        conn.commit()
        conn.close()
        return {"message": "標記與提示詞已成功更新"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/capture/delete")
def delete_capture(filename: str):
    file_path = filename.replace('train', VIDEO_DIR)
    
    if ".." in filename or filename.startswith("/"):
        raise HTTPException(status_code=400, detail="無效的檔名")
    
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            
        pure_fn = os.path.basename(file_path)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA foreign_keys = ON;")
        cursor.execute("DELETE FROM captures WHERE filename = ?", (pure_fn,))
        conn.commit()
        conn.close()
        
        return {"message": "檔案與資料庫紀錄已成功刪除"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/train/{folder}/{filename}")
def get_file(folder: str, filename: str):
    file_path = os.path.join(VIDEO_DIR, folder, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    media_type, _ = mimetypes.guess_type(file_path)
    if media_type is None:
        media_type = "application/octet-stream"
        
    return FileResponse(file_path, media_type=media_type)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="127.0.0.1", port=8000, reload=True)