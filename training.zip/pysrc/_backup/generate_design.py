import mimetypes
import os
import sys
import sqlite3
import json
from PIL import Image

VIDEO_DIR = "D:/training"
DB_PATH = os.path.join(VIDEO_DIR, "annotations.db")

def get_character():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # 確保儲存裁切圖片的 character 資料夾存在
    char_output_dir = os.path.join(VIDEO_DIR, "character")
    os.makedirs(char_output_dir, exist_ok=True)
    
    # 取得所有 captures
    cursor.execute("SELECT id, filename, source_video, prompt FROM captures")
    capture_rows = cursor.fetchall()

    for cap in capture_rows:
        capture_id = cap['id']
        f = cap['filename']

        # 組合原始截圖的路徑
        img_path = os.path.join(VIDEO_DIR, "capture", f)
        print(f"處理圖片: {img_path}")
        
        source_image = None
        if os.path.exists(img_path):
            try:
                source_image = Image.open(img_path)
            except Exception as e:
                print(f"無法開啟圖片 {img_path}: {e}")

        # 取得該 capture 對應的所有 character 記錄（包含 id、rect、tags）
        cursor.execute("SELECT id, rect, tags FROM character WHERE capture_id = ?", (capture_id,))
        char_rows = cursor.fetchall()    

        box_results = []

        for ch in char_rows:
            char_id = ch['id']  # 取得 character 資料表的 id 作為檔名
            rect_obj = json.loads(ch['rect']) if ch['rect'] else {}
            tag_ids = json.loads(ch['tags']) if ch['tags'] else []        

            print('=========')
            # 取得該 box 的 tags 物件列表
            tags_obj = gettags(cursor, tag_ids)
            # print(tags_obj)

            # 針對當前 box 產生獨立的 Prompt
            single_prompt = tags_to_prompt(tags_obj)

            # 呼叫獨立的裁切函式
            cropped_image = crop_box_image(source_image, rect_obj)

            # 如果成功裁切出圖片，則以 character 的 id 存檔
            if cropped_image:
                save_path = os.path.join(char_output_dir, f"{char_id}.png")
                print(char_id)
                cropped_image.save(save_path, "PNG")
                print(f"已儲存裁切圖片: {save_path}")

            # 將結果記錄下來
            box_results.append({
                "character_id": char_id,
                "rect": rect_obj,
                "prompt": single_prompt,
                "cropped_image": cropped_image
            })

        # 關閉原圖釋放資源
        if source_image:
            source_image.close()


def crop_box_image(source_image, rect_obj):
    """
    根據傳入的原圖與比例型 rect（0~1），換算成真實像素並裁切 Box 圖片
    """
    if not source_image or not rect_obj:
        return None

    print(f"DEBUG - 正在解析比例 rect: {rect_obj}")

    try:
        img_width, img_height = source_image.size

        # 取得 0~1 的比例數值
        x_ratio = float(rect_obj.get('x', rect_obj.get('xmin', 0)))
        y_ratio = float(rect_obj.get('y', rect_obj.get('ymin', 0)))
        
        if 'width' in rect_obj and 'height' in rect_obj:
            w_ratio = float(rect_obj.get('width', 0))
            h_ratio = float(rect_obj.get('height', 0))
            x2_ratio = x_ratio + w_ratio
            y2_ratio = y_ratio + h_ratio
        else:
            x2_ratio = float(rect_obj.get('xmax', x_ratio))
            y2_ratio = float(rect_obj.get('ymax', y_ratio))

        # 將比例轉換為真實的像素座標
        left = int(x_ratio * img_width)
        upper = int(y_ratio * img_height)
        right = int(x2_ratio * img_width)
        lower = int(y2_ratio * img_height)

        # 確保座標在圖片範圍之內
        left = max(0, min(left, img_width))
        upper = max(0, min(upper, img_height))
        right = max(0, min(right, img_width))
        lower = max(0, min(lower, img_height))

        # 檢查換算後的像素寬高是否有效
        if right - left > 0 and lower - upper > 0:
            box_coords = (left, upper, right, lower)
            return source_image.crop(box_coords)
        else:
            print(f"警告：轉換後的像素範圍無效 (left={left}, upper={upper}, right={right}, lower={lower})")
            return None

    except Exception as e:
        print(f"解析 rect 發生錯誤: {e}")
        return None

def gettags(cursor, tag_ids):
    tags_obj = []
    if tag_ids:
        placeholders = ','.join(['?'] * len(tag_ids))
        cursor.execute(f"SELECT id, name, group_name FROM tags WHERE id IN ({placeholders})", tag_ids)
        tag_rows = cursor.fetchall()
        for t_row in tag_rows:
            tags_obj.append({
                "id": t_row['id'],
                "name": t_row['name'],
                "group": t_row['group_name']
            })    
    return tags_obj  

def tags_to_prompt(tags_obj):
    """
    將單一 box 的 tags 依照 group 分類並組合成獨立的 Prompt 字串
    """
    if not tags_obj:
        return ""
    
    group_priority = {"人物": 1, "頭髮": 2, "配件": 3, "顏色": 4}
    
    grouped_tags = {}
    for tag in tags_obj:
        g = tag.get("group", "未分類")
        name = tag.get("name", "")
        if name:
            if g not in grouped_tags:
                grouped_tags[g] = []
            if name not in grouped_tags[g]:  
                grouped_tags[g].append(name)
                
    sorted_groups = sorted(grouped_tags.keys(), key=lambda x: group_priority.get(x, 99))
    
    prompt_parts = []
    for g in sorted_groups:
        tags_str = ", ".join(grouped_tags[g])
        prompt_parts.append(tags_str)
        
    return ", ".join(prompt_parts)

if __name__=='__main__':
    get_character()