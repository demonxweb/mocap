import sqlite3
import json,os




def get_layout_prompt():
    VIDEO_DIR = "D:/training"
    DB_PATH = os.path.join(VIDEO_DIR, "annotations.db")    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()    

    # 取得所有 captures
    cursor.execute("SELECT id, filename, source_video, prompt,replace_prompt FROM captures")
    
    char_output_dir = os.path.join(VIDEO_DIR, "character")
    layout_output_dir = os.path.join(VIDEO_DIR, 'layout\paint')
    target_output_dir = os.path.join(VIDEO_DIR, "target")

    

    capture_rows = cursor.fetchall()

    result = []

    for cap in capture_rows:
        capture_id = cap['id']
        if not cap['prompt']:
            continue

        prompt = '{}\{}'.format(cap['replace_prompt'],cap['prompt'])

        layout_uri = os.path.join(layout_output_dir,cap['filename'])

        dest_uri = os.path.join(target_output_dir,cap['filename'])
        

        cursor.execute("SELECT id, rect, tags FROM character WHERE capture_id = ?", (capture_id,))
        char_rows = cursor.fetchall()    

        src_uris=[layout_uri]

        for ch in char_rows:
            char_id = ch['id']  # 取得 character 資料表的 id 作為檔名       
            char_uri = os.path.join(char_output_dir, f"{char_id}.png")

            src_uris.append(char_uri)
            

        result.append([src_uris,dest_uri,prompt])
    cursor.close()

    return result
        

if __name__=='__main__':
    get_layout_prompt()
        