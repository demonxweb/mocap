import os
from yt_dlp import YoutubeDL

url = "https://www.youtube.com/watch?v=rXViS2k4MUo"
download_path = r"D:\training\video"
custom_filename = "video2.mp4"

# 組合完整的儲存路徑與檔名
outtmpl_path = os.path.join(download_path, custom_filename)

# 設定下載參數：篩選 720p 且內含聲影的 mp4 格式 (或是最佳整合)
ydl_opts = {
    'format': 'bestvideo[ext=mp4][height<=720]+bestaudio[ext=m4a]/best[ext=mp4][height<=720]',
    'outtmpl': outtmpl_path,
    'merge_output_format': 'mp4'
}

try:
    print("正在透過 yt-dlp 下載影片...")
    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])
    print("下載完成！")
except Exception as e:
    print(f"發生錯誤：{e}")
