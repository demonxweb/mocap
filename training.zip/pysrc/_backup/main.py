import re,threading
import webview
import os,time
import base64


class Api:
    def download_youtube(self, url):
        print(url)

    def save_image(self, base64_data, filename):
            # 移除 Base64 前綴 (例如 "data:image/png;base64,")
            if "," in base64_data:
                base64_data = base64_data.split(",")[1]
                
            # 將 Base64 解碼並儲存
            image_data = base64.b64decode(base64_data)
            
            # 設定儲存路徑 (例如存到 D:\images\captures)
            save_path = os.path.join(r'D:\images\captures', filename)
            
            # 確保資料夾存在
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            
            with open(save_path, "wb") as f:
                f.write(image_data)
                
            return f"已成功儲存至: {save_path}"

# 建立 API 實例
api = Api()


def main():
    port = '5173'
    # start_file_server()
    # threading.Thread(target=start_file_server, daemon=True).start()

    webview.create_window('Dev Environment', 
                          f'http://localhost:{port}',
                          js_api=api,
                          
                          )
    webview.start(http_server=True,debug=True)


if __name__=='__main__':

    main()    

