def drop_file(page, drop_selector: str, file_path: str):
    # 讀取檔案內容並轉成 JS File 物件
    with open(file_path, "rb") as f:
        file_content = f.read()
    
    file_name = file_path.split("/")[-1]
    
    # 在瀏覽器中建立 DataTransfer 並 dispatch drop 事件
    page.evaluate("""
        async (dropSelector, fileName, fileContent) => {
            const dropZone = document.querySelector(dropSelector);
            if (!dropZone) throw new Error('Drop zone not found');
            
            // 建立 File 物件
            const file = new File([fileContent], fileName, { type: 'application/pdf' });  // 改成對應 MIME type
            
            // 建立 DataTransfer
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            
            // 觸發 dragenter, dragover, drop 事件
            const dropEvent = new DragEvent('drop', {
                bubbles: true,
                cancelable: true,
                dataTransfer: dataTransfer
            });
            
            dropZone.dispatchEvent(dropEvent);
        }
    """, drop_selector, file_name, list(file_content))  # 注意要轉 list 才能傳給 JS

# 使用範例
drop_file(page, "#dropzone", "./test.pdf")   # 或使用 class / data-testid


from pathlib import Path

def drag_and_drop_file(page, drop_target, file_paths):
    """拖放一個或多個檔案"""
    js_files = []
    
    for fp in file_paths:
        path = Path(fp)
        content = path.read_bytes()
        js_files.append({
            "name": path.name,
            "mime": "application/octet-stream",  # 可依副檔名調整
            "buffer": list(content)
        })
    
    page.evaluate("""
        (targetSelector, files) => {
            const target = document.querySelector(targetSelector);
            if (!target) throw new Error('Target not found: ' + targetSelector);
            
            const dt = new DataTransfer();
            
            files.forEach(file => {
                const blob = new Blob([new Uint8Array(file.buffer)]);
                const f = new File([blob], file.name, {type: file.mime});
                dt.items.add(f);
            });
            
            const event = new DragEvent('drop', {
                bubbles: true,
                cancelable: true,
                dataTransfer: dt
            });
            
            target.dispatchEvent(event);
        }
    """, drop_target, js_files)