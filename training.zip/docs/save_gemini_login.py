pip install playwright
playwright install chromium  # 安裝瀏覽器


from playwright.sync_api import sync_playwright
import time

def login_and_save_state():
    with sync_playwright() as p:
        # 重要參數：避開 Google 偵測
        browser = p.chromium.launch(
            headless=False,  # 先用有頭模式手動操作
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-infobars',
                '--start-maximized',
            ]
        )
        
        context = browser.new_context(
            viewport={'width': 1280, 'height': 720},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
        )
        
        page = context.new_page()
        
        # 前往 Gemini 或 Google 登入頁
        page.goto("https://gemini.google.com")
        print("請在瀏覽器中手動完成 Google 登入（包含 2FA）...")
        
        # 給你充足時間手動登入
        time.sleep(90)  # 90 秒，可自行調整
        
        # 保存登入狀態
        context.storage_state(path="gemini_auth.json")
        print("登入狀態已保存到 gemini_auth.json")
        
        browser.close()

if __name__ == "__main__":
    login_and_save_state()
	
	
	
from playwright.sync_api import sync_playwright

def use_saved_login():
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=False,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox',
            ]
        )
        
        context = browser.new_context(
            storage_state="gemini_auth.json",   # 載入之前保存的狀態
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
        )
        
        page = context.new_page()
        page.goto("https://gemini.google.com")
        
        # 等待頁面載入完成
        page.wait_for_load_state("networkidle")
        print("已使用保存狀態登入 Gemini！")
        
        # 這裡可以繼續你的操作，例如發送 prompt
        # page.get_by_role("textbox").fill("Hello Gemini!")
        # page.keyboard.press("Enter")
        
        input("按 Enter 關閉瀏覽器...")
        browser.close()

if __name__ == "__main__":
    use_saved_login()	