Playwright launch_persistent_context 使用教學（操作資料夾）
launch_persistent_context 是 Playwright 最推薦的持久化登入方式，它會把瀏覽器資料（cookies、localStorage、sessionStorage、擴充功能、登入狀態等）直接保存在你指定的資料夾中。

1. 基本用法
Pythonfrom playwright.sync_api import sync_playwright
from pathlib import Path

def main():
    user_data_dir = Path("./my_browser_data")   # ← 自訂資料夾
    
    with sync_playwright() as p:
        # 啟動持久化 Context
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(user_data_dir),   # 必須傳入資料夾路徑
            headless=False,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--no-sandbox',
                '--start-maximized',
            ],
            viewport={'width': 1280, 'height': 720},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ...'
        )
        
        page = context.pages[0] if context.pages else context.new_page()
        
        page.goto("https://gemini.google.com")
        print("已開啟持久化瀏覽器，登入後資料會自動保存")
        
        input("按 Enter 結束...")   # 讓你手動操作
        context.close()   # 關閉時會自動保存所有資料到資料夾

2. 重要參數說明（操作資料夾相關）

參數,說明,推薦設定
user_data_dir,核心：指定要使用的使用者資料資料夾,必填
headless,是否無頭模式,False（第一次建議）
args,Chrome 啟動參數,加上防偵測
ignore_https_errors,忽略 HTTPS 錯誤,True（測試用）
permissions,"授予權限（如 notifications, clipboard）",可選
locale,語言,'zh-TW'



參數說明推薦設定user_data_dir核心：指定要使用的使用者資料資料夾必填headless是否無頭模式False（第一次建議）argsChrome 啟動參數加上防偵測ignore_https_errors忽略 HTTPS 錯誤True（測試用）permissions授予權限（如 notifications, clipboard）可選locale語言'zh-TW'

3. 進階操作技巧
建立多個不同使用者資料夾
Pythondef create_profile(profile_name: str):
    user_dir = f"./browser_profiles/{profile_name}"
    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(user_dir, headless=False)
        # ... 操作 ...
        context.close()
載入已存在的資料夾繼續使用
只要 user_data_dir 指向同一個資料夾，下次執行就會自動載入之前的登入狀態、cookies 等，完全不需要重新登入。
清除資料夾（重置）
Pythonimport shutil

def reset_profile(profile_dir: str):
    if Path(profile_dir).exists():
        shutil.rmtree(profile_dir)
    print("資料夾已重置")

4. 完整 Gemini 登入推薦寫法
Pythonfrom playwright.sync_api import sync_playwright
from pathlib import Path

user_data_dir = "./gemini_profile"

with sync_playwright() as p:
    context = p.chromium.launch_persistent_context(
        user_data_dir=user_data_dir,
        headless=False,
        args=['--disable-blink-features=AutomationControlled'],
        viewport={'width': 1440, 'height': 900}
    )
    
    page = context.pages[0] or context.new_page()
    page.goto("https://gemini.google.com")
    
    # 第一次執行請手動登入 Google 帳號
    if "Sign in" in page.content():
        print("請手動完成 Google 登入...")
    
    # 之後就可以直接使用
    page.wait_for_load_state("networkidle")
    print("已使用持久化資料夾登入")
    
    input("按 Enter 關閉...")
    context.close()

優點總結

自動保存：不用手動 storage_state
真實瀏覽器行為：最接近真人使用
適合長期自動化：登入狀態持久保存
可多開：不同資料夾 = 不同使用者