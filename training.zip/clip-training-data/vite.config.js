import { defineConfig } from 'vite'
import { resolve } from 'path';
import fs from 'fs';
import path from 'path';
import react, { reactCompilerPreset } from '@vitejs/plugin-react'
import babel from '@rolldown/plugin-babel'



function serveVideos() {
  
  const folderPath = "D:/training";
  const urlPattern = /^\/(video|image)\/(.*)/; // Regex 修正：需要抓取後面路徑

  return {
    name: 'serve-external-videos',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        

        if (req.url === '/api/files') {
          const videoDir = path.join(folderPath, 'video');
          const files = fs.readdirSync(videoDir); // 讀取資料夾檔案
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify(files)); // 回傳陣列 ["a.mp4", "b.mp4"]
        }

        const match = req.url.match(urlPattern);

        if (match) {
          const filePath = path.join(folderPath, req.url);

          if (fs.existsSync(filePath)) {
            if (req.url.match(/\.(mp4)$/)) {
              const stat = fs.statSync(filePath);
              res.setHeader('Content-Type', 'video/mp4');
              res.setHeader("Content-Length", stat.size);
              res.setHeader("Accept-Ranges", "bytes");
              
              fs.createReadStream(filePath).pipe(res);
              return;
            } 
            
            if (req.url.match(/\.(png|jpg|jpeg|gif)$/)) {
              res.setHeader('Content-Type', 'image/png');
              res.end(fs.readFileSync(filePath));
              return;
            }
          }
        }
        // 如果沒有匹配到，或者是找不到檔案，執行 next() 讓 Vite 繼續處理
        next();
      });
    }
  };
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    babel({ presets: [reactCompilerPreset()] }),
    // serveVideos()  

  ],
  server: {
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
        secure: false,
      },
      '/train': 'http://localhost:8000',
    }
  },  
  build: {
      rollupOptions: {
        input: {
          main: resolve(__dirname, 'index.html'),
          // about: resolve(__dirname, 'about.html'),
        },
      },
    },  
})
