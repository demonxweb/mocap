import { useState, useRef, useEffect } from 'react'

import './App.css'
import NavigationBar from './NavigationBar';

import CaptureVideo from './page/CaptureVideo';
import ConvertDesign from './page/ConvertDesign';
import Design from './page/Design';

import Generate from './page/Generate';

function App() {

  const [currentView, setCurrentView] = useState(() => {
    const path = window.location.pathname.replace('/', '');
    return path || 'video';
  });

  useEffect(() => {

    const handlePopState = () => {
      const path = window.location.pathname.replace('/', '');
      setCurrentView(path || 'video');
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const renderView = () => {

    switch (currentView) {

      case 'capture_video':
        return <CaptureVideo />;
      case 'convert_design':
        return <ConvertDesign />;
      case 'generate':
        return <Generate />;

      case 'design':
      default:
        return <Design />;
    }
  };

  return (
    <>
      <NavigationBar />
      <div className="main">
        {renderView()}
      </div>
    </>
  )
}

export default App;