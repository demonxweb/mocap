import React, { createContext, useContext, useState, useEffect } from 'react';

const PyWebViewContext = createContext({ isReady: false });

export const PyWebViewProvider = ({ children }) => {
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const handleReady = () => setIsReady(true);

    if (window.pywebview) {
      setIsReady(true);
    } else {
      window.addEventListener('pywebviewready', handleReady);
    }

    return () => window.removeEventListener('pywebviewready', handleReady);
  }, []);

  return (
    <PyWebViewContext.Provider value={{ isReady }}>
      {children}
    </PyWebViewContext.Provider>
  );
};

// 方便其他元件使用的 Hook
export const usePyWebView = () => useContext(PyWebViewContext);