import { useState, useRef } from 'react'
import { AiFillAlert } from "react-icons/ai";

import { FaVideo } from "react-icons/fa6";
import { FaImage } from "react-icons/fa6";
import { FaCamera } from "react-icons/fa";
import { FaTag } from "react-icons/fa";
import { FaClapperboard } from "react-icons/fa6";
import { BiSolidUserAccount } from "react-icons/bi";
import { RiAiGenerate2 } from "react-icons/ri";
import { VscGear } from "react-icons/vsc";



function NavigationBar() {
    const [isClosed, setIsClosed] = useState(false);

    const handleNavigate = (view) => {
        const path = `/${view}`;

        window.history.pushState({}, '', path);

        window.dispatchEvent(new PopStateEvent('popstate'));
        setIsClosed(true);
    };

    return (

        <nav
            className={`navigation-bar ${isClosed ? 'force-close' : ''}`}
            onMouseLeave={() => setIsClosed(false)}
        >
            <div className='nav-top'>
                <a onClick={() => handleNavigate('capture_video')}><FaVideo className='nav-icon' />Capture Video</a>
                <a onClick={() => handleNavigate('convert_design')}><FaCamera className='nav-icon' />Convert Design</a>
                <a onClick={() => handleNavigate('design')}><BiSolidUserAccount className='nav-icon' />Design</a>
                <a onClick={() => handleNavigate('generate')}><RiAiGenerate2 className='nav-icon' />Generate</a>
            </div>
            <div className='nav-bottom'>
                <a><VscGear className='nav-icon' />Settings</a>
            </div>
        </nav >
    )
}

export default NavigationBar