import { useState,useEffect,useRef } from 'react'

import { TextField ,Stack ,Button,Box ,Slider} from '@mui/material';

import { Dialog ,DialogTitle ,DialogContent} from '@mui/material';
import { usePyWebView } from './utils/PyWebviewContext';


function DownloadYoutube() {
    const { isReady } = usePyWebView();

    const [url, setUrl] = useState("https://www.youtube.com/watch?v=12n6GzBgXY0");


    async function clickDownload() {
        if (!isReady) return null;
        // const response = await window.pywebview.api.download_youtube(url);
        setVideo_Url("http://localhost:8000/video/test.mp4")
    }

    return (
        <>
        <Box sx={{p:3, 
                display: 'flex',
                justifyContent: 'center',  
                }}>
            <Stack direction="row" 
                    spacing={1} 
                    >
                <TextField id="youtube-url" 
                    label="Youtube" 
                    variant="outlined" 
                    sx = {{minWidth:400}}
                    value={url} onChange={(e) => setUrl(e.target.value)} 
                    size="small"/>
                <Button variant="outlined" 
                        size="small"
                        sx={{ borderRadius: 1 }}
                        onClick={clickDownload} 
                        disabled={!isReady}
                        >
                    {isReady ? 'Download' : 'Disabled Download'}
                </Button>
            </Stack>
        </Box>
        </>

    )


}

export default DownloadYoutube