import { useState, useRef, useEffect } from 'react';
import { Box, ButtonGroup, Button, Chip } from '@mui/material';
import { Rnd } from 'react-rnd';

// 將 replaceRole 邏輯定義在組件外部
function replaceRole(idx, tagRows) {
    const arg = {};
    for (const tagRow of tagRows) {
        if (!arg[tagRow.group]) {
            arg[tagRow.group] = [];
        }
        arg[tagRow.group].push(tagRow.name);
    }
    const position = [...(arg['位置'] || [])];
    const outlook = [
        ...(arg['配件'] || []),
        ...(arg['頭髮'] || [])
    ];
    const people = [
        ...(arg['顏色'] || []),
        ...(arg['人物'] || [])
    ];

    const outlookStr = outlook.join('');
    const peopleStr = people.join('');
    const positionStr = position.join('');

    return `image_${idx + 2}${outlookStr}${peopleStr}置換成${positionStr}位置`;
}

// 接收從外部傳入的 imgUrl、boxes、setBoxes，以及處理 replaceRole 的回呼函式 onReplaceRole
function TagImage({ imgUrl, boxes, setBoxes, onReplaceRole }) {
    const containerRef = useRef(null);
    const imgRef = useRef(null);

    // 儲存圖片目前的實際像素尺寸，用於比例換算
    const [imgDimensions, setImgDimensions] = useState({ width: 0, height: 0 });

    // 繪製中的暫存狀態
    const [isDrawing, setIsDrawing] = useState(false);
    const [startPos, setStartPos] = useState({ x: 0, y: 0 });
    const [tempRect, setTempRect] = useState(null);
    const [selectedBoxId, setSelectedBoxId] = useState(null);

    // 僅在 boxes 的內容（ID、位置、大小或 Tag）真正改變時才呼叫 onReplaceRole
    useEffect(() => {
        if (!onReplaceRole) return;

        if (boxes.length === 0) {
            onReplaceRole('', null);
            return;
        }

        const allResultsStr = boxes.map((box, index) => {
            return replaceRole(index, box.tags);
        }).join(',\n');

        const currentSelectedBox = boxes.find(b => b.id === selectedBoxId) || boxes[0];

        onReplaceRole(allResultsStr, currentSelectedBox);
    }, [JSON.stringify(boxes)]); // 透過 JSON.stringify 深度追蹤 boxes 的變動，避免選取狀態改變或不相干動作觸發

    // 監聽視窗大小改變與圖片初始化尺寸
    useEffect(() => {
        const updateDimensions = () => {
            if (imgRef.current) {
                setImgDimensions({
                    width: imgRef.current.clientWidth,
                    height: imgRef.current.clientHeight
                });
            }
        };

        updateDimensions();
        window.addEventListener('resize', updateDimensions);

        const imgElement = imgRef.current;
        if (imgElement) {
            imgElement.addEventListener('load', updateDimensions);
        }

        return () => {
            window.removeEventListener('resize', updateDimensions);
            if (imgElement) {
                imgElement.removeEventListener('load', updateDimensions);
            }
        };
    }, [imgUrl]);

    // 鍵盤刪除事件 (Delete / Backspace)
    useEffect(() => {
        const handleKeyDown = (e) => {
            if ((e.key === 'Delete' || e.key === 'Backspace') && selectedBoxId) {
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

                setBoxes(prev => prev.filter(b => b.id !== selectedBoxId));
                setSelectedBoxId(null);
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [selectedBoxId, setBoxes]);

    const handleMouseDown = (e) => {
        if (e.target.closest('.rnd-box')) return;
        if (!imgRef.current) return;

        const imgRect = imgRef.current.getBoundingClientRect();
        setIsDrawing(true);
        const startX = e.clientX - imgRect.left;
        const startY = e.clientY - imgRect.top;
        setStartPos({ x: startX, y: startY });
        setTempRect({ x: startX, y: startY, width: 0, height: 0 });
    };

    const handleMouseMove = (e) => {
        if (!isDrawing || !imgRef.current) return;
        const imgRect = imgRef.current.getBoundingClientRect();
        const currentX = e.clientX - imgRect.left;
        const currentY = e.clientY - imgRect.top;

        setTempRect({
            x: Math.min(startPos.x, currentX),
            y: Math.min(startPos.y, currentY),
            width: Math.abs(currentX - startPos.x),
            height: Math.abs(currentY - startPos.y),
        });
    };

    const handleMouseUp = () => {
        if (isDrawing && tempRect && tempRect.width > 5 && tempRect.height > 5 && imgRef.current) {
            const imgWidth = imgRef.current.clientWidth;
            const imgHeight = imgRef.current.clientHeight;

            const newid = Date.now();
            const newBox = {
                id: newid,
                tags: [],
                x: tempRect.x / imgWidth,
                y: tempRect.y / imgHeight,
                width: tempRect.width / imgWidth,
                height: tempRect.height / imgHeight,
            };

            setBoxes([...boxes, newBox]);
            setSelectedBoxId(newid);
        }
        setIsDrawing(false);
        setTempRect(null);
    };

    const deleteBoxTag = (box, tagId) => {
        setBoxes(boxes.map(b => {
            if (b.id === box.id) {
                return { ...b, tags: b.tags.filter(t => t.id !== tagId) };
            }
            return b;
        }));
    };

    const handleDrop = (box, e) => {
        const tagData = JSON.parse(e.dataTransfer.getData("application/json"));
        if (box.tags.find(t => t.id === tagData.id)) return;

        setBoxes(boxes.map(b =>
            b.id === box.id
                ? { ...b, tags: [...b.tags, tagData] }
                : b
        ));
    };

    const handleDragOrResizeStop = (box, ref, position) => {
        if (!imgRef.current) return;
        const imgWidth = imgRef.current.clientWidth;
        const imgHeight = imgRef.current.clientHeight;

        setBoxes(boxes.map(b =>
            b.id === box.id
                ? {
                    ...b,
                    x: position.x / imgWidth,
                    y: position.y / imgHeight,
                    width: parseInt(ref.style.width) / imgWidth,
                    height: parseInt(ref.style.height) / imgHeight,
                }
                : b
        ));
    };

    const { width: imgWidth, height: imgHeight } = imgDimensions;

    return (
        <Box sx={{ gap: 0, p: 0 }}>
            <ButtonGroup sx={{ gap: 0, p: 1 }} size="small">
                <Button
                    variant="outlined"
                    color="error"
                    onClick={() => setBoxes([])}
                >
                    清除全部
                </Button>
                <Button
                    variant="contained"
                    color="error"
                    disabled={!selectedBoxId}
                    onClick={() => {
                        setBoxes(boxes.filter(box => box.id !== selectedBoxId));
                        setSelectedBoxId(null);
                    }}
                >
                    清除
                </Button>
            </ButtonGroup>
            <Box
                ref={containerRef}
                sx={{ position: 'relative', maxWidth: '1240px', cursor: 'crosshair', userSelect: 'none', display: 'inline-block' }}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
            >
                {imgUrl && (
                    <img
                        ref={imgRef}
                        src={imgUrl}
                        style={{ maxWidth: '100%', display: 'block', pointerEvents: 'none' }}
                        alt="target"
                    />
                )}

                {/* 繪製中的預覽框 */}
                {isDrawing && tempRect && (
                    <div style={{
                        position: 'absolute', left: tempRect.x, top: tempRect.y,
                        width: tempRect.width, height: tempRect.height,
                        border: '2px dashed blue', backgroundColor: 'rgba(0, 0, 255, 0.1)', pointerEvents: 'none'
                    }} />
                )}

                {/* 已產生的 Rnd 方框 */}
                {boxes.map((box, index) => {
                    const pixelX = box.x * imgWidth;
                    const pixelY = box.y * imgHeight;
                    const pixelWidth = box.width * imgWidth;
                    const pixelHeight = box.height * imgHeight;

                    return (
                        <Rnd
                            key={`${box.id}-${imgWidth}`}
                            className="rnd-box"
                            size={{ width: pixelWidth, height: pixelHeight }}
                            position={{ x: pixelX, y: pixelY }}
                            bounds="parent"
                            style={{
                                border: selectedBoxId === box.id ? '2px solid rgba(255, 255, 0, 0.8)' : '2px solid rgba(200, 0, 0, 0.8)',
                                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                                cursor: 'move'
                            }}
                            onDragStop={(e, d) => handleDragOrResizeStop(box, { style: { width: `${pixelWidth}px`, height: `${pixelHeight}px` } }, d)}
                            onResizeStop={(e, dir, ref, delta, position) => handleDragOrResizeStop(box, ref, position)}
                            onDragOver={(e) => e.preventDefault()}
                            onDrop={(e) => handleDrop(box, e)}
                            onMouseDown={() => setSelectedBoxId(box.id)}
                        >
                            <div style={{ color: '#FFFFFF', backgroundColor: 'rgba(200, 0, 0, 0.3)', fontSize: '10px', textAlign: 'center' }}>
                                image_{index + 2}
                            </div>
                            {box.tags.map((tag) => (
                                <Chip
                                    key={tag.id}
                                    label={tag.name}
                                    color="default"
                                    variant="outlined"
                                    size="small"
                                    onDelete={() => deleteBoxTag(box, tag.id)}
                                />
                            ))}
                        </Rnd>
                    );
                })}
            </Box>
        </Box>
    );
}

export default TagImage;