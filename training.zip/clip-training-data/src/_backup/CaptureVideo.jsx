import { useState, useEffect, useRef } from 'react';
import { TextField, Button, ButtonGroup, Slider } from '@mui/material';
import { Stack, Box, Grid } from '@mui/material';
import { Dialog, DialogTitle, DialogContent } from '@mui/material';
import { usePyWebView } from '../utils/PyWebviewContext';

function CaptureVideo(props) {
    const { isReady } = usePyWebView();

    // 只有當 props.selectedVideo 存在時才組合網址，否則為 null
    const url = props.selectedVideo ? `/train/video/${props.selectedVideo}` : null;

    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0.0);
    const [duration, setDuration] = useState(0.0);
    const [progress, setProgress] = useState(0); 
    const [screenshot, setScreenshot] = useState("null");

    const [rangeMax, setRangeMax] = useState(0.0);

    const [openAlert, setOpenAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState("");

    const videoRef = useRef(null);

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    const clickPlay = () => videoRef.current && videoRef.current.play();
    const clickPause = () => videoRef.current && videoRef.current.pause();

    useEffect(() => {
        if (videoRef.current && url) {
            videoRef.current.load();
        }
    }, [url]);

    useEffect(() => {
        let timer;
        if (openAlert) {
            timer = setTimeout(() => {
                setOpenAlert(false);
            }, 3000);
        }
        return () => clearTimeout(timer);
    }, [openAlert]);

    const handleMetadata = (e) => {
        const duration = isFinite(e.target.duration) ? e.target.duration : 0;
        setCurrentTime(0.0);
        setDuration(duration);
        setRangeMax(duration);
    };

    const handleSeek = (newTime) => {
        if (videoRef.current) {
            videoRef.current.currentTime = newTime;
        }
    };
    const handleTimeUpdate = () => {
        if (videoRef.current) {
            const current = videoRef.current.currentTime;
            setProgress(current);
        }
    };

    const handleCapture = async () => {
        if (videoRef.current) {
            const canvas = document.createElement('canvas');
            canvas.width = videoRef.current.videoWidth;
            canvas.height = videoRef.current.videoHeight;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);

            const imageSrc = canvas.toDataURL('image/png');
            const filename = `frame_${videoRef.current.currentTime.toFixed(2)}.png`;
            setScreenshot(imageSrc);
            await uploadCanvas(imageSrc, filename);
        }
    };

    async function uploadCanvas(dataURL, filename) {
        const response = await fetch(dataURL);
        const blob = await response.blob();

        const formData = new FormData();
        formData.append('file', blob, filename);
        formData.append('filename', filename);
        formData.append('source_video', props.selectedVideo);

        const res = await fetch('/api/capture/save', {
            method: 'POST',
            body: formData
        });

        const msg = await res.json();
        if (res.status == 200) {
            setAlertMessage(`${msg.message}:${filename}`);
            reloadImages();
        } else {
            setAlertMessage(`${res.statusText}:${filename}`);
        }
        setOpenAlert(true);
    }

    function reloadImages() {
        if (props.imagesRef && props.imagesRef.current) {
            props.imagesRef.current.refresh();
        } else {
            console.warn("CaptureImages 的 ref 未正確傳入或尚未準備好");
        }
    }

    return (
        <>
            <Box sx={{ display: 'flex', justifyContent: 'center', }}>
                <Stack spacing={1}>
                    {/* 只有當 url 存在時才渲染 video 元素，避免傳入空字串引發警告 */}
                    {url ? (
                        <video ref={videoRef}
                            style={{ maxWidth: '640px' }}
                            crossOrigin="anonymous"
                            onLoadedMetadata={handleMetadata}
                            onPlay={handlePlay}
                            onPause={handlePause}
                            onTimeUpdate={handleTimeUpdate}
                        >
                            <source src={url} type="video/mp4" />
                        </video>
                    ) : (
                        <Box sx={{ width: 640, height: 360, bgcolor: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}>
                            請先選擇影片
                        </Box>
                    )}

                    <Grid container spacing={1}>
                        <Grid size={10} sx={{ display: 'flex', justifyContent: 'center', }}>
                            <input
                                type="range"
                                style={{ width: "100%" }}
                                max={rangeMax}
                                step="0.01"
                                value={progress}
                                disabled={!url}
                                onChange={(e) => handleSeek(e.target.value)}
                            />
                        </Grid>
                        <Grid size={2} sx={{ display: 'flex', justifyContent: 'center', }}>
                            <ButtonGroup size="small">
                                {!isPlaying && <Button variant="contained" disabled={!url} onClick={clickPlay}>▶</Button>}
                                {isPlaying && <Button variant="contained" disabled={!url} onClick={clickPause}>⏸</Button>}
                                <Button variant="contained" disabled={!url} onClick={handleCapture}>📷</Button>
                            </ButtonGroup>
                        </Grid>
                    </Grid>
                </Stack>
                <Dialog open={openAlert} onClose={() => setOpenAlert(false)}>
                    <DialogTitle>Warning</DialogTitle>
                    <DialogContent>{alertMessage}</DialogContent>
                    {screenshot && <img src={screenshot} alt="Screenshot" style={{ width: 300 }} />}
                </Dialog>
            </Box>
        </>
    );
}

export default CaptureVideo;