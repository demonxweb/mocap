import { useState, useEffect, useRef } from 'react';
import { ImageList, ImageListItem, ImageListItemBar } from '@mui/material';
import { Box } from '@mui/material';

function ListVideo({ selectedVideo, onSelectVideo }) {
    const [videos, setVideos] = useState([]);

    useEffect(() => {
        const fetchVideos = async () => {
            try {
                const res = await fetch('/api/videos');
                if (res.ok) {
                    const data = await res.json();
                    setVideos(data);
                    if (!selectedVideo && data.length > 0) {
                        onSelectVideo(data[0]);
                    }
                }
            } catch (error) {
                console.error("載入影片清單失敗:", error);
            }
        };
        fetchVideos();
    }, []);

    const containerRef = useRef(null);

    return (
        <div 
            ref={containerRef} 
            style={{ 
                width: '100%', 
                overflowX: 'auto', 
                overflowY: 'hidden', 
                whiteSpace: 'nowrap',
                paddingBottom: '8px' 
            }}
        >
            <ImageList 
                sx={{ 
                    display: 'flex', 
                    flexWrap: 'nowrap', 
                    gap: 2, 
                    margin: 0,
                    transform: 'translateZ(0)' 
                }}
            >
                {videos.map((vid) => {
                    const isSelected = selectedVideo === vid;
                    return (
                        <ImageListItem 
                            key={vid}
                            sx={{
                                minWidth: '180px',
                                width: '180px',
                                flexShrink: 0,
                                cursor: 'pointer',
                                border: isSelected ? '2px solid #1976d2' : '2px solid transparent',
                                borderRadius: '4px',
                                transition: 'all 0.2s ease',
                                '&:hover': {
                                    opacity: 0.8,
                                },
                            }}
                            onClick={() => onSelectVideo(vid)}
                        >
                            <Box 
                                sx={{ 
                                    height: '120px', 
                                    backgroundColor: '#000', 
                                    borderRadius: '4px',
                                    overflow: 'hidden',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItem: 'center'
                                }}
                            >
                                <video
                                    src={`/train/video/${vid}`}
                                    preload="metadata"
                                    style={{ 
                                        width: '100%', 
                                        height: '100%', 
                                        objectFit: 'cover' 
                                    }}
                                />
                            </Box>
                            <ImageListItemBar
                                title={vid}
                                sx={{
                                    borderBottomLeftRadius: '4px',
                                    borderBottomRightRadius: '4px',
                                    '& .MuiImageListItemBar-title': {
                                        fontSize: '0.85rem',
                                        textAlign: 'center'
                                    }
                                }}
                            />
                        </ImageListItem>
                    );
                })}
            </ImageList>
        </div>
    );
}

export default ListVideo;