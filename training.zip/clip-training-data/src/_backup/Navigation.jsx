import { useState } from 'react';
import { Box, List, ListItemButton, ListItemText, Typography, Divider } from '@mui/material';

function Navigation({ currentView, onNavigationChange }) {
    // 使用 useState 管理導覽列的選單清單，支援動態增加
    const [navigationList, setNavigationList] = useState([
        { id: 'capture', label: '螢幕截圖 (Capture)' },
        { id: 'tag', label: '標籤管理 (Tags)' },
        { id: 'listCharacter', label: '角色清單 (List Character)' }
    ]);

    // 範例：如果你未來需要動態新增項目，可以呼叫類似這樣的函式
    // const addNavItem = (newId, newLabel) => {
    //     setNavigationList(prev => [...prev, { id: newId, label: newLabel }]);
    // };

    return (
        <Box
            sx={{
                width: 240,
                bgcolor: '#222222', // 配合專案的深色風格
                color: '#ffffff',
                borderRight: '1px solid #333333',
                display: 'flex',
                flexDirection: 'column',
                flexShrink: 0
            }}
        >
            {/* 導覽列標題區 */}
            <Box sx={{ p: 2, textAlign: 'center' }}>
                <Typography variant="h6" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                    Tag Manager
                </Typography>
            </Box>
            <Divider sx={{ bgcolor: '#333333' }} />

            {/* 動態渲染選單列表 */}
            <List component="nav" sx={{ p: 1 }}>
                {navigationList.map((item, index) => (
                    <ListItemButton
                        key={item.id}
                        selected={currentView === item.id}
                        onClick={() => onNavigationChange && onNavigationChange(item.id)}
                        sx={{
                            borderRadius: 1,
                            mb: index < navigationList.length - 1 ? 0.5 : 0,
                            '&.Mui-selected': {
                                bgcolor: 'primary.main',
                                color: '#ffffff',
                                '&:hover': {
                                    bgcolor: 'primary.dark',
                                },
                            },
                        }}
                    >
                        <ListItemText primary={item.label} />
                    </ListItemButton>
                ))}
            </List>
        </Box>
    );
}

export default Navigation;