import { useState, useRef } from 'react';
import { Typography, Stack } from '@mui/material';

import ListVideo from './ListVideo';
import CaptureVideo from './CaptureVideo';
import CaptureImages from './CaptureImages';

function CaptureWrapper({ onSelectImage }) {
  const imagesRef = useRef();
  const [selectedVideo, setSelectedVideo] = useState("");

  return (
    <Stack spacing={2}>
      {/* 放置影片清單選擇器[cite: 1] */}
      <ListVideo selectedVideo={selectedVideo} onSelectVideo={setSelectedVideo} />

      {/* 傳遞選中的影片讓 CaptureVideo 切換編輯[cite: 1] */}
      <CaptureVideo selectedVideo={selectedVideo} imagesRef={imagesRef} />

      <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 1 }}>
        截圖
      </Typography>

      {/* 傳遞選中的影片讓 CaptureImages 只顯示該影片相關的 Captures[cite: 1] */}
      <CaptureImages ref={imagesRef} selectedVideo={selectedVideo} onSelectImage={onSelectImage} />
    </Stack>
  );
}

export default CaptureWrapper;