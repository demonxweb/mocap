import React, { useState, useEffect, forwardRef, useImperativeHandle, useRef } from 'react';
import { ImageList, ImageListItem, ImageListItemBar, IconButton } from '@mui/material';
import { Dialog, DialogTitle, DialogContent } from '@mui/material';
import { useTheme } from '@mui/material';

import DeleteIcon from '@mui/icons-material/Delete';

const CaptureImages = forwardRef(({ onSelectImage, selectedVideo }, ref) => {
    const theme = useTheme();
    const [itemData, setItemData] = useState([]);
    const [openAlert, setOpenAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState("");

    const fetchImages = async () => {
        try {
            const res = await fetch('/api/captures', { method: 'GET' });
            const data = await res.json();
            setItemData(data);
        } catch (error) {
            console.error("載入失敗:", error);
        }
    };

    useEffect(() => {
        fetchImages();
    }, []);

    useImperativeHandle(ref, () => ({
        refresh: fetchImages
    }));

    // 根據當前選擇的影片過濾截圖資料
    const filteredItems = itemData.filter(item => {
        if (!selectedVideo) return false;
        // 如果資料庫中沒有 source_video，可以視需求決定是否顯示，這裡先做安全處理
        const itemVideo = (item.source_video || "").trim().toLowerCase();
        const currentVideo = selectedVideo.trim().toLowerCase();
        return itemVideo === currentVideo;
    });

    const handleImageClick = async (item) => {
        if (!onSelectImage) return;
        try {
            const params = new URLSearchParams({ filename: item.fn });
            const res = await fetch(`/api/capture/tag?${params.toString()}`, { method: 'GET' });
            if (res.ok) {
                const detailData = await res.json();
                onSelectImage({ ...item, ...detailData });
            } else {
                console.error("取得圖片標記資料失敗");
                onSelectImage(item);
            }
        } catch (error) {
            console.error("取得圖片標記資料發生錯誤:", error);
            onSelectImage(item);
        }
    };

    async function clickDelete(filename) {
        try {
            const params = new URLSearchParams({ filename: filename });
            const res = await fetch(`/api/capture/delete?${params.toString()}`, { method: 'DELETE' });
            if (res.status == 200) {
                const msg = await res.json();
                setAlertMessage(`${msg.message}:${filename}`);
                await fetchImages();
            } else {
                setAlertMessage(`${res.statusText}:${filename}`);
            }
            setOpenAlert(true);
        } catch (error) {
            console.error("刪除失敗:", error);
        }
    }

    const containerRef = useRef(null);

    return (
        <>
            <div
                ref={containerRef}
                style={{
                    width: '100%',
                    overflowX: 'auto',
                    overflowY: 'hidden',
                    whiteSpace: 'nowrap',
                    paddingBottom: '8px'
                }}
            >
                <ImageList
                    sx={{
                        display: 'flex',
                        flexWrap: 'nowrap',
                        gap: 2,
                        margin: 0,
                        transform: 'translateZ(0)'
                    }}
                >
                    {filteredItems.map((item) => (
                        <ImageListItem
                            key={item.img}
                            sx={{
                                minWidth: '180px',
                                width: '180px',
                                flexShrink: 0,
                                cursor: onSelectImage ? 'pointer' : 'default',
                                '& .MuiImageListItemBar-root': {
                                    opacity: 0,
                                    transition: 'opacity 0.3s ease',
                                },
                                '&:hover .MuiImageListItemBar-root': {
                                    opacity: 1,
                                },
                            }}
                            onClick={() => handleImageClick(item)}
                        >
                            <img
                                src={item.img}
                                alt={item.tags}
                                loading="lazy"
                                style={{ height: '120px', objectFit: 'cover', borderRadius: '4px' }}
                            />
                            <ImageListItemBar
                                title={item.fn}
                                subtitle={<span>{item.prompt}</span>}
                                actionIcon={
                                    <IconButton onClick={(e) => {
                                        e.stopPropagation();
                                        clickDelete(item.img);
                                    }}>
                                        <DeleteIcon />
                                    </IconButton>
                                }
                            />
                        </ImageListItem>
                    ))}
                </ImageList>
            </div>
            <Dialog open={openAlert} onClose={() => setOpenAlert(false)}>
                <DialogTitle>Warning</DialogTitle>
                <DialogContent>{alertMessage}</DialogContent>
            </Dialog>
        </>
    );
});

export default CaptureImages;