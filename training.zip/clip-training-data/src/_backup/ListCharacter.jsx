import { useState, useEffect, useRef } from 'react';
import { Box, Typography, Paper, Grid, Chip,Stack } from '@mui/material';

// 負責用 Canvas 裁切圖片的小元件
function CanvasCropImage({ src, box }) {
    const canvasRef = useRef(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        const image = new Image();
        image.crossOrigin = "anonymous";
        image.src = src;
        image.onload = () => {
            const imgWidth = image.naturalWidth;
            const imgHeight = image.naturalHeight;

            let x = box.x || box.xmin || 0;
            let y = box.y || box.ymin || 0;
            let w = box.width || (box.xmax - x) || 0;
            let h = box.height || (box.ymax - y) || 0;

            if (x <= 1.0 && w <= 1.0) {
                x = x * imgWidth;
                y = y * imgHeight;
                w = w * imgWidth;
                h = h * imgHeight;
            }

            canvas.width = w > 0 ? w : 1;
            canvas.height = h > 0 ? h : 1;

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(
                image,
                x, y, w, h,
                0, 0, canvas.width, canvas.height
            );
        };
    }, [src, box]);

    return (
        <canvas
            ref={canvasRef}
            style={{
                width: '140px',
                height: '140px',
                objectFit: 'contain',
                backgroundColor: '#000',
                borderRadius: '4px',
                border: '1px solid #444'
            }}
        />
    );
}

function ListCharacter() {
    const [flatBoxList, setFlatBoxList] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchCharacterList = async () => {
        try {
            setLoading(true);
            const response = await fetch('/api/captures');
            if (response.ok) {
                const data = await response.json();

                const flattened = data.flatMap(item => {
                    let parsedBoxes = [];
                    try {
                        parsedBoxes = typeof item.boxes === 'string' ? JSON.parse(item.boxes) : (item.boxes || []);
                    } catch (e) {
                        console.error("解析 boxes 失敗：", e);
                        parsedBoxes = [];
                    }
                    
                    return parsedBoxes.map(boxItem => ({
                        filename: item.fn || item.filename,
                        imgUrl: item.img,
                        prompt: item.prompt,
                        box: boxItem,
                        id:boxItem.id
                    }));
                });

                setFlatBoxList(flattened);
            } else {
                console.error("取得 captures 清單失敗");
            }
        } catch (error) {
            console.error("發生錯誤：", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchCharacterList();
    }, []);

    if (loading) {
        return (
            <Box sx={{ p: 3, textAlign: 'center', color: '#ffffff' }}>
                <Typography>載入中...</Typography>
            </Box>
        );
    }

    return (
        <Stack
            spacing={2}
            direction="column"
        >

            {flatBoxList.map((item, index) => (


                <Box key={item.id} sx={{ width: '100%', maxWidth: '1400px', alignItems: 'flex-start' }} >
                    <Typography
                        variant="caption"
                        sx={{ color: 'primary.main', mb: 1, display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
                        title={item.filename}
                    >
                        檔案：{item.filename}
                    </Typography>

                    <CanvasCropImage src={item.imgUrl} box={item.box}/>

                    <Box sx={{ mt: 1.5, flexGrow: 1 }}>
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                            {item.box.tags && item.box.tags.length > 0 ? (
                                item.box.tags.map((tag, tIndex) => (
                                    <Chip
                                        key={tIndex}
                                        label={typeof tag === 'string' ? tag : tag.name}
                                        color="primary"
                                        variant="outlined"
                                        size="small"
                                    />
                                ))
                            ) : (
                                <Typography variant="body2" sx={{ color: '#666' }}>無標籤</Typography>
                            )}
                        </Box>
                    </Box>

                    {item.prompt && (
                        <Typography
                            variant="caption"
                            sx={{
                                mt: 1.5,
                                color: '#aaa',
                                display: '-webkit-box',
                                WebkitLineClamp: 2,
                                WebkitBoxOrient: 'vertical',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis'
                            }}
                            title={item.prompt}
                        >
                            Prompt: {item.prompt}
                        </Typography>
                    )}
                </Box>


            ))}
        </Stack>

    );
}

export default ListCharacter;