import { useState } from 'react';
import { Box, TextField, Chip, Typography, IconButton, Collapse } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

function TagGroup({ groupList, tags, onDeleteTag, onUpdateTag, onDeleteGroup, onToggleSelectTag }) {
    const [editingId, setEditingId] = useState(null);
    const [tempLabel, setTempLabel] = useState("");
    const [dragOverGroup, setDragOverGroup] = useState(null);

    // 追蹤每個群組的收合狀態 (key: groupName, value: boolean 是否收合)
    const [collapsedGroups, setCollapsedGroups] = useState({});

    const toggleCollapse = (groupName) => {
        setCollapsedGroups(prev => ({
            ...prev,
            [groupName]: !prev[groupName]
        }));
    };

    const startEdit = (tag) => {
        setEditingId(tag.id);
        setTempLabel(tag.name);
    };

    const saveEdit = (tag) => {
        if (!tempLabel.trim() || tempLabel === tag.name) {
            setEditingId(null);
            return;
        }
        if (onUpdateTag) {
            onUpdateTag(tag.id, { name: tempLabel, group: tag.group });
        }
        setEditingId(null);
    };

    const handleMoveTagToGroup = (tag, targetGroupName) => {
        if (tag.group === targetGroupName) return;
        if (onUpdateTag) {
            onUpdateTag(tag.id, { name: tag.name, group: targetGroupName });
        }
    };

    return (
        <Box sx={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: 1,
            mt: 2,
            p: 1,
            border: '1px solid #ccc',
            borderRadius: 1
        }}>
            {groupList.map(groupName => {
                // 計算當前群組底下的 tag 數量
                const groupTags = tags.filter(t => t.group === groupName);
                const tagCount = groupTags.length;
                const isCollapsed = !!collapsedGroups[groupName];

                return (
                    <Box key={groupName}
                        sx={{
                            mb: 2, width: '100%',
                            backgroundColor: dragOverGroup === groupName ? 'action.hover' : 'transparent',
                            borderRadius: 1,
                            p: 0.5
                        }}
                        onDragOver={(e) => {
                            e.preventDefault();
                            setDragOverGroup(groupName);
                        }}
                        onDragLeave={() => setDragOverGroup(null)}
                        onDrop={(e) => {
                            e.preventDefault();
                            const tagDataJson = e.dataTransfer.getData("application/json");
                            if (tagDataJson) {
                                const tag = JSON.parse(tagDataJson);
                                handleMoveTagToGroup(tag, groupName);
                            }
                            setDragOverGroup(null);
                        }}
                    >
                        {/* 群組標題列 */}
                        <Box sx={{ 
                            display: 'flex', 
                            alignItems: 'center', 
                            justifyContent: 'space-between',
                            backgroundColor: '#333333',
                            mb: 1,
                            p: 1,
                            borderRadius: 1
                        }}>
                            <Box 
                                sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer', flexGrow: 1 }}
                                onClick={() => toggleCollapse(groupName)}
                            >
                                <IconButton size="small" sx={{ color: 'primary.main', mr: 0.5, p: 0 }}>
                                    {isCollapsed ? <ChevronRightIcon /> : <ExpandMoreIcon />}
                                </IconButton>
                                <Typography
                                    variant="subtitle1"
                                    sx={{ color: 'primary.main', fontWeight: 'bold' }}
                                >
                                    {groupName} ({tagCount})
                                </Typography>
                            </Box>
                            
                            <IconButton 
                                size="small" 
                                color="error" 
                                onClick={() => onDeleteGroup && onDeleteGroup(groupName)}
                                title={`刪除群組 ${groupName}`}
                            >
                                <DeleteIcon fontSize="small" />
                            </IconButton>
                        </Box>

                        {/* 收合區塊 */}
                        <Collapse in={!isCollapsed}>
                            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1, pl: 1 }}>
                                {groupTags
                                    .sort((a, b) => a.name.localeCompare(b.name, 'zh-Hant'))
                                    .map(tag => (
                                        <Box key={tag.id}>
                                            {editingId === tag.id ? (
                                                <TextField
                                                    size="small"
                                                    value={tempLabel}
                                                    onChange={(e) => setTempLabel(e.target.value)}
                                                    onBlur={() => saveEdit(tag)}
                                                    onKeyDown={(e) => e.key === 'Enter' && saveEdit(tag)}
                                                    autoFocus
                                                />
                                            ) : (
                                                <Chip
                                                    draggable
                                                    label={tag.name}
                                                    onClick={() => onToggleSelectTag && onToggleSelectTag(tag.id)}
                                                    onDoubleClick={() => startEdit(tag)}
                                                    onDelete={() => onDeleteTag && onDeleteTag(tag.id)}
                                                    color={tag.isSelected ? "secondary" : "primary"}
                                                    variant={tag.isSelected ? "filled" : "outlined"}
                                                    onDragStart={(e) => {
                                                        const tagJson = JSON.stringify(tag);
                                                        e.dataTransfer.setData("application/json", tagJson);
                                                    }}
                                                />
                                            )}
                                        </Box>
                                    ))}
                            </Box>
                        </Collapse>
                    </Box>
                );
            })}
        </Box>
    );
}

export default TagGroup;