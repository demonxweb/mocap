import { useState } from 'react';
import { Stack, TextField, Autocomplete, Button } from '@mui/material';

function TagEditor({ groupList, onAddTag }) {
    const [selectedGroup, setSelectedGroup] = useState("");
    const [newTagName, setNewTagName] = useState("");

    const handleAdd = () => {
        const targetGroup = selectedGroup.trim() || "未分類";
        const tagName = newTagName.trim();

        if (!tagName) {
            alert("請輸入標籤名稱！");
            return;
        }

        if (onAddTag) {
            onAddTag(targetGroup, tagName);
            setNewTagName("");
        }
    };

    return (
        <Stack direction="row" spacing={1} sx={{ width: '100%' }}>
            <Autocomplete
                sx={{ flexGrow: 2 }}
                freeSolo
                options={groupList}
                value={selectedGroup}
                onChange={(event, newValue) => setSelectedGroup(newValue || "")}
                onInputChange={(event, newInputValue) => setSelectedGroup(newInputValue)}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        label="選擇或建立群組"
                        variant="outlined"
                        size="small"
                    />
                )}
            />

            <TextField
                size="small"
                placeholder="輸入新標籤名稱"
                value={newTagName}
                onChange={(e) => setNewTagName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
                sx={{ flexGrow: 2 }}
            />

            <Button
                variant="contained"
                color="secondary"
                onClick={handleAdd}
                sx={{ minWidth: '100px' }}
            >
                新增 Tag
            </Button>
        </Stack>
    );
}

export default TagEditor;