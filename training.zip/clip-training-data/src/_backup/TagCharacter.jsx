import { useState, useEffect, useRef } from 'react';
import { Box, Stack, TextField, Typography, Button } from '@mui/material';
import TagImage from './TagImage';
import TagEditor from './TagEditor';
import TagGroup from './TagGroup';
import CaptureImages from './CaptureImages';
import ListVideo from './ListVideo';

function TagCharacter() {
    const [tags, setTags] = useState([]);
    const [groupList, setGroupList] = useState([]);
    const [selectedVideo, setSelectedVideo] = useState("");
    const [currentCapture, setCurrentCapture] = useState(null);
    const [boxes, setBoxes] = useState([]);
    const [promptText, setPromptText] = useState("");
    const [replacePromptText, setReplacePromptText] = useState("");

    const captureImagesRef = useRef(null);

    const fetchMetaData = async () => {
        try {
            const groupRes = await fetch('/api/group');
            if (groupRes.ok) {
                const groupData = await groupRes.json();
                setGroupList(groupData);
            }

            const tagRes = await fetch('/api/tags');
            if (tagRes.ok) {
                const tagData = await tagRes.json();
                setTags(tagData);
            }
        } catch (error) {
            console.error("載入標籤與群組失敗：", error);
        }
    };

    useEffect(() => {
        fetchMetaData();
    }, []);

    // 當變更影片時，順便清空 currentCapture 與相關編輯狀態
    const handleVideoSelect = (videoName) => {
        setSelectedVideo(videoName);
        setCurrentCapture(null);
        setBoxes([]);
        setPromptText("");
        setReplacePromptText("");
    };

    const handleSelectCapture = (cap) => {
        setCurrentCapture(cap);
        setPromptText(cap.prompt || "");
        setReplacePromptText(cap.replace_prompt || "");
        try {
            const parsedBoxes = typeof cap.boxes === 'string' ? JSON.parse(cap.boxes) : (cap.boxes || []);
            setBoxes(parsedBoxes);
        } catch (e) {
            console.error("解析 boxes 失敗：", e);
            setBoxes([]);
        }
    };

    // ================= 統一管理的 API 動作 =================

    const handleAddTag = async (targetGroup, tagName) => {
        try {
            if (targetGroup && !groupList.includes(targetGroup)) {
                const groupRes = await fetch('/api/group', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: targetGroup })
                });
                if (groupRes.ok) {
                    setGroupList(prev => [...prev, targetGroup]);
                }
            }

            const tagRes = await fetch('/api/tags', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: tagName, group: targetGroup })
            });

            if (tagRes.ok) {
                const data = await tagRes.json();
                const newTag = {
                    id: data.id,
                    name: tagName,
                    group: targetGroup,
                    isSelected: false
                };
                setTags(prev => [...prev, newTag]);
            } else {
                console.error("新增標籤失敗");
            }
        } catch (error) {
            console.error("新增標籤發生錯誤：", error);
        }
    };

    const handleDeleteTag = async (id) => {
        try {
            const res = await fetch(`/api/tags/${id}`, { method: 'DELETE' });
            if (res.ok) {
                setTags(prev => prev.filter(t => t.id !== id));
            } else {
                console.error("刪除標籤失敗");
            }
        } catch (error) {
            console.error("刪除標籤發生錯誤：", error);
        }
    };

    const handleUpdateTag = async (tagId, updatedData) => {
        try {
            const res = await fetch(`/api/tags/${tagId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedData)
            });

            if (res.ok) {
                setTags(prev => prev.map(t => t.id === tagId ? { ...t, ...updatedData } : t));
            } else {
                console.error("更新標籤失敗");
            }
        } catch (error) {
            console.error("更新標籤發生錯誤：", error);
        }
    };

    const handleDeleteGroup = async (groupName) => {
        if (!window.confirm(`確定要刪除群組「${groupName}」嗎？這會同時清除該群組底下的所有標籤。`)) {
            return;
        }

        try {
            const res = await fetch(`/api/group?name=${encodeURIComponent(groupName)}`, {
                method: 'DELETE'
            });

            if (res.ok) {
                setGroupList(prev => prev.filter(g => g !== groupName));
                setTags(prev => prev.filter(t => t.group !== groupName));
            } else {
                console.error("刪除群組失敗");
            }
        } catch (error) {
            console.error("刪除群組發生錯誤：", error);
        }
    };

    const handleToggleSelectTag = (id) => {
        setTags(prev => prev.map(tag =>
            tag.id === id ? { ...tag, isSelected: !tag.isSelected } : tag
        ));
    };

    const handleSave = async () => {
        if (!currentCapture) {
            alert("請先選擇一張截圖！");
            return;
        }

        const payload = {
            filename: currentCapture.fn,
            boxes: boxes,
            prompt: promptText,
            replace_prompt: replacePromptText,
        };

        try {
            const response = await fetch("/api/capture/tag/save", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            });

            if (!response.ok) throw new Error("儲存標記失敗");

            alert("標記與提示詞已成功儲存至 SQLite！");
            if (captureImagesRef.current) {
                captureImagesRef.current.refresh();
            }
        } catch (error) {
            console.error("儲存發生錯誤：", error);
            alert("儲存失敗，請檢查主控台。");
        }
    };


    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mt: 2, px: 2, pb: 4 }}>
            <Box sx={{ width: '100%', maxWidth: '1400px', mb: 3 }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 1 }}>
                    選擇影片
                </Typography>
                {/* 帶入自訂的 handleVideoSelect 函式，切換影片時順便清空 currentCapture */}
                <ListVideo selectedVideo={selectedVideo} onSelectVideo={handleVideoSelect} />

                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mt: 2, mb: 1 }}>
                    選擇截圖
                </Typography>
                <Box>
                    <CaptureImages
                        ref={captureImagesRef}
                        selectedVideo={selectedVideo}
                        onSelectImage={handleSelectCapture}
                    />
                </Box>
            </Box>

            <Stack
                spacing={2}
                direction="row"
                sx={{ width: '100%', maxWidth: '1400px', alignItems: 'flex-start' }}
            >
                <Stack spacing={1} sx={{ flex: 3 }}>
                    <TagEditor
                        groupList={groupList}
                        onAddTag={handleAddTag}
                    />
                    <TagGroup
                        groupList={groupList}
                        tags={tags}
                        onDeleteTag={handleDeleteTag}
                        onUpdateTag={handleUpdateTag}
                        onDeleteGroup={handleDeleteGroup}
                        onToggleSelectTag={handleToggleSelectTag}
                    />
                </Stack>

                <Stack spacing={1.5} sx={{ flex: 7, p: 1 }}>
                    <TagImage
                        imgUrl={currentCapture ? currentCapture.img : ""}
                        boxes={boxes}
                        setBoxes={setBoxes}
                        onReplaceRole={(resultString) => {
                            // console.log("從子元件傳上來的結果：", resultString);

                            setReplacePromptText(resultString)
                            // 這裡可以把 resultString 存入上層的 state 或是作其他處理
                        }}
                    />

                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mt: 1 }}>
                        置換規格
                    </Typography>

                    <div>{replacePromptText}</div>

                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mt: 1 }}>
                        場景描述
                    </Typography>

                    <TextField
                        multiline
                        rows={16}
                        placeholder="請輸入內容..."
                        value={promptText}
                        onChange={(e) => setPromptText(e.target.value)}
                        variant="outlined"
                        fullWidth
                    />

                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 1 }}>
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={handleSave}
                            sx={{ minWidth: '120px' }}
                        >
                            Save
                        </Button>
                    </Box>
                </Stack>
            </Stack>
        </Box>
    );
}

export default TagCharacter;