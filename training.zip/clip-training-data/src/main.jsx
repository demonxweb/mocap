import * as React from 'react';
import * as ReactDOM from 'react-dom/client';

import process from 'process';
window.process = process;

import './index.css'

import { PyWebViewProvider } from './utils/PyWebviewContext.jsx';
import App from './App.jsx'

const rootElement = document.getElementById('root');
const root = ReactDOM.createRoot(rootElement);
if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
  document.documentElement.style.colorScheme = 'dark';
//   或者幫根元素加上 dark 的class
  document.documentElement.classList.add('dark');
}

root.render(
    <>
    <React.StrictMode>
        <PyWebViewProvider>
            <App/>
        </PyWebViewProvider>
    </React.StrictMode>    
    </>
)
