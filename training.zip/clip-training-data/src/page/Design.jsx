import { useState, useRef, useEffect } from 'react'
import Layout from '../components/Layout';
import Spliter from '../components/Spliter';

import TagEditor from '../components/TagEditor'
import PromptEditor from '../components/PromptEditor'
import { stripTagContent } from '../components/PromptEditor'
import CardViewer from '../components/CardViewer';


function Design() {
    const dialogRef = useRef(null);
    const [alertMessage, setAlertMessage] = useState("");

    const tagEditorRef = useRef(null);
    const [tagList, setTagList] = useState([]);

    const [designs, setDesigns] = useState([]);
    const updateTimersRef = useRef({});

    const promptRef = useRef(null);
    const [card, setCard] = useState({});

    useEffect(() => {
        fetchDesigns();

        return () => {
            Object.values(updateTimersRef.current).forEach(timer => clearTimeout(timer));
        };
    }, []);


    const fetchDesigns = async (videoId) => {
        try {
            const url = '/api/design';
            const res = await fetch(url);
            if (res.ok) {
                const data = await res.json();
                setDesigns(data);
            } else {
                console.error("無法載入Design列表");
            }
        } catch (error) {
            console.error("Fetch design error:", error);
        }
    };

    const clickCard = (card, idx) => {
        setCard(card)
    }

    const dropFiles = async (files) => {
        if (!files || files.length === 0) return;

        // 轉換成一般陣列以便使用迴圈
        const fileArray = Array.from(files);
        let successCount = 0;

        // 使用 for...of 依序上傳每個檔案
        for (const file of fileArray) {
            // 檢查是否為 PNG 圖片（可選，依你的需求調整）
            if (file.type !== 'image/png') {
                console.warn(`跳過非 PNG 檔案: ${file.name}`);
                continue;
            }

            const designData = {
                name: file.name,
            };

            const formData = new FormData();
            formData.append('file', file);

            try {
                const res = await fetch('/api/design', {
                    method: 'POST',
                    body: formData
                });

                const msg = await res.json();
                if (res.ok) {
                    successCount++;
                    console.log(`上傳成功: ${file.name}`);
                } else {
                    console.error(`上傳失敗: ${file.name} - ${res.statusText}`);
                }
            } catch (error) {
                console.error(`上傳發生錯誤: ${file.name}`, error);
            }
        }

        // 全部上傳完畢後，統一更新列表與提示訊息
        if (successCount > 0) {
            setAlertMessage(`成功上傳 ${successCount} 個檔案`);
            setOpenAlert(true);
            fetchDesigns(); // 重新整理列表
        }
    };


    const deleteDesgin = async (id) => {
        try {
            const res = await fetch(`/api/design/${id}`, {
                method: 'DELETE',
            });

            const result = await res.json();

            if (res.ok) {
                // 刪除成功後，更新前端 state 移除該筆截圖
                setDesigns(prev => prev.filter(row => row.id !== id));
            } else {
                setAlertMessage(`刪除失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Delete design error:", error);
            setAlertMessage("刪除過程發生網路或程式錯誤");
            setOpenAlert(true);
        }
    }


    const dataChanged = (e, design_id,data) => {

        if (updateTimersRef.current[design_id]) {
            clearTimeout(updateTimersRef.current[design_id]);
        }
        updateTimersRef.current[design_id] = setTimeout(() => {
            updateDesign(data, true);
            delete updateTimersRef.current[design_id];
        }, 500);
    };


    const updateDesign = async (design, setBefore = true) => {
        const previousDesigns = designs;
        if (setBefore) {
            const updated = designs.map(b => b.id === design.id ? { ...b, ...design } : b);
            setDesigns(updated);
        }

        try {
            const res = await fetch('/api/design', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(design)
            });

            const result = await res.json();

            if (!res.ok) {
                setDesigns(previousDesigns);
                setAlertMessage(`更新Design失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            setDesigns(previousDesigns);
            console.error("Update Design error:", error);
            setAlertMessage("更新Design過程發生錯誤");
            setOpenAlert(true);
        }
    };

    const setOpenAlert = (isOpen) => {
        const dialog = dialogRef.current;
        if (!dialog) return;

        if (isOpen) {
            dialog.showModal(); // 顯示為 Modal 互動對話框（會鎖定背景）
        } else {
            dialog.close();     // 關閉對話框
        }
    };

    const customStyle = {
        '--video-width': '640px',
        'textAlign': 'center'
    }


    return (
        <Layout direction="v" sizes="60px" style={customStyle}>
            <h1>Design</h1>
            <Spliter direction="h" minSize={10} sizes="240px,,360px">
                <CardViewer data={designs}
                    direction="v"
                    cardWidth='98cqw'
                    cardHeight='60cqw'
                    scroll='y'
                    onCardClick={clickCard}
                    onCardDelete={deleteDesgin}
                    onDropFile={dropFiles}
                ></CardViewer>

                <div style={{ textAlign: "center" }}>
                    {card.url ? (<img
                        src={card.url}
                        className='view-img'
                    />) : (
                        <span>Select Image</span>
                    )}
                    <div style={{ display: 'grid', gridTemplateColumns: '100px 1fr', alignItems: 'center', gap: '6px', margin: '3px' }}>
                        <span style={{ textAlign: 'right' }}>Name: </span>
                        <input type="text" placeholder='Please input name.' value={card.name} onInput={(e) => dataChanged(e, card.id,{ name: e.target.value, id: card.id })}></input>
                        <span style={{ textAlign: 'right' }}>Prompt: </span>
                        <PromptEditor ref={promptRef}
                            tagList={tagList} prompt={card.prompt}
                            style={{ background: 'var(--c-input-bg)', padding: '8px', border: '1px solid #999', outline: 'none', minHeight: '100px' }}
                            onInput={(e, content) => dataChanged(e, card.id,{ prompt: content, id: card.id })}
                        />

                    </div>

                </div>

                <TagEditor ref={tagEditorRef}
                    onTagChange={(newList) => setTagList(newList)}
                />
            </Spliter>
            <dialog ref={dialogRef} onClick={() => { setOpenAlert(false) }}>
                <h1>Warning</h1>
                <div>{alertMessage}</div>
            </dialog>
        </Layout>
    )
}

export default Design;
