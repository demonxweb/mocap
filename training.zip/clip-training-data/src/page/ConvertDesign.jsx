import { useState, useRef, useEffect } from 'react'
import Layout from '../components/Layout';
import Spliter from '../components/Spliter';

import TagEditor from '../components/TagEditor'
import PromptEditor from '../components/PromptEditor'
import { stripTagContent } from '../components/PromptEditor'
import CardViewer from '../components/CardViewer';
import BBox from '../components/BBox';


function ConvertDesign() {
    const dialogRef = useRef(null);
    const [tagList, setTagList] = useState([]);
    const [captures, setCaptures] = useState([]);
    const [prompt, setPrompt] = useState('');
    const tagEditorRef = useRef(null);
    const [url, setUrl] = useState(null);
    const [boxes, setBoxes] = useState([]);
    const [alertMessage, setAlertMessage] = useState("");
    const promptEditorRefs = useRef({});
    const updateTimersRef = useRef({});

    const [captureId, setCaptureId] = useState(null);


    useEffect(() => {
        fetchCaptures();

        return () => {
            Object.values(updateTimersRef.current).forEach(timer => clearTimeout(timer));
        };
    }, []);


    const fetchCaptures = async (videoId) => {
        try {
            const url = videoId ? `/api/capture?video_id=${videoId}` : '/api/capture';
            const res = await fetch(url);
            if (res.ok) {
                const data = await res.json();
                setCaptures(data);
            } else {
                console.error("無法載入截圖列表");
            }
        } catch (error) {
            console.error("Fetch captures error:", error);
        }
    };

    const fetchBBox = async (captureId) => {
        try {
            const url = `/api/bbox/${captureId}`;
            const res = await fetch(url);
            if (res.ok) {
                const data = await res.json();
                setBoxes(data);
            } else {
                console.error("無法載入BBox列表");
            }
        } catch (error) {
            console.error("Fetch BBox error:", error);
        }
    };


    const clickCard = async (card, idx) => {

        if (card) {
            setCaptureId(card.id)
            setUrl(card.url);
            await fetchBBox(card.id);
        }
    };


    const addBox = async (box) => {
        const newBox = { ...box, capture_id: captureId }

        try {

            const res = await fetch('/api/bbox', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newBox)
            });

            const result = await res.json();

            if (res.ok) {
                await fetchBBox(captureId);
            } else {
                setAlertMessage(`新增BBox失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Add group error:", error);
            setAlertMessage("新增BBox過程發生錯誤");
            setOpenAlert(true);
        }

    }

    const deleteBox = async (boxId) => {
        try {
            const res = await fetch(`/api/bbox/${boxId}`, {
                method: 'DELETE',
            });

            const result = await res.json();

            if (res.ok) {
                // 後端會連同該 group 下的 tag 一起刪除，前端也同步濾除
                const updated = boxes.filter(b => b.id !== boxId);
                setBoxes(updated);
            } else {
                setAlertMessage(`刪除群組失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Delete group error:", error);
            setAlertMessage("刪除群組過程發生錯誤");
            setOpenAlert(true);
        }
    }

    const updateBox = async (box, setBefore = true) => {
        const previousBoxes = boxes;

        if (setBefore) {
            const updated = boxes.map(b => b.id === box.id ? { ...b, ...box } : b);
            setBoxes(updated);
        }

        try {
            const res = await fetch('/api/bbox', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(box)
            });

            const result = await res.json();

            if (!res.ok) {
                setBoxes(previousBoxes);
                setAlertMessage(`更新BBox失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            setBoxes(previousBoxes);
            console.error("Update BBox error:", error);
            setAlertMessage("更新BBox過程發生錯誤");
            setOpenAlert(true);
        }
    };

    const setOpenAlert = (isOpen) => {
        const dialog = dialogRef.current;
        if (!dialog) return;

        if (isOpen) {
            dialog.showModal(); // 顯示為 Modal 互動對話框（會鎖定背景）
        } else {
            dialog.close();     // 關閉對話框
        }
    };
    const customStyle = {
        '--video-width': '640px',
        'textAlign': 'center'
    }

    const inputPrompt = (e, content, boxId) => {

        if (updateTimersRef.current[boxId]) {
            clearTimeout(updateTimersRef.current[boxId]);
        }

        updateTimersRef.current[boxId] = setTimeout(() => {
            updateBox({
                id: boxId,
                prompt: content,
            }, false);
            delete updateTimersRef.current[boxId];
        }, 500);
    };

    const viewContent=(e,boxId)=>{
        const el = promptEditorRefs.current[boxId]
        console.log(el.getPureContent())
    }

    return (
        <Layout direction="v" sizes="60px" style={customStyle}>
            <h1>Convert Design</h1>
            <Spliter direction="h" minSize={10} sizes="240px,,360px">
                <CardViewer data={captures} direction="v" cardWidth='98cqw' cardHeight='60cqw' scroll='y' onCardClick={clickCard}></CardViewer>
                <Spliter direction="v" flexIndex={1} minSize={10} sizes='360px'>
                    <BBox url={url} boxes={boxes} onAddBox={addBox} onUpdateBox={updateBox} onDeleteBox={deleteBox}></BBox>
                    <Layout direction='v' sizes="36px" gap='3px' padding='5px' style={{ textAlign: 'left',overflowY:'auto' }}>
                        
                        <div>
                            {boxes.map((box, index) => {

                                return (
                                    <div key={box.id} style={{ display: 'flex', alignItems: 'center', margin: '3px' }}>
                                        <button onClick={(e)=>{viewContent(e,box.id)}}>S{index + 1}:</button>
                                        <PromptEditor
                                            ref={(el) => {
                                                if (el) promptEditorRefs.current[box.id] = el;
                                                else delete promptEditorRefs.current[box.id];
                                            }}
                                            tagList={tagList}
                                            prompt={box.prompt || ''}
                                            style={{
                                                background: 'var(--c-input-bg)',
                                                margin: '3px 8px',
                                                padding: '8px',
                                                border: '1px solid #999',
                                                outline: 'none', 
                                                flex: '1',
                                                height:'200px',
                                            }}
                                            onInput={(e, content) => inputPrompt(e, content, box.id)}
                                        />
                                    </div>
                                )
                            })}
                        </div>
                    </Layout>
                </Spliter>
                <TagEditor ref={tagEditorRef}
                    onTagChange={(newList) => setTagList(newList)}
                />
            </Spliter>
            <dialog ref={dialogRef} onClick={() => { setOpenAlert(false) }}>
                <h1>Warning</h1>
                <div>{alertMessage}</div>
            </dialog>
        </Layout>
    )
}

export default ConvertDesign;
