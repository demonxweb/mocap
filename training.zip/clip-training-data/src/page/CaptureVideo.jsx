import { useState, useRef, useEffect } from 'react';

import Layout from '../components/Layout';
import CardViewer from '../components/CardViewer';
import CaptureViewer from '../components/CaptureViewer';


function CaptureVideo() {
    const videoRef = useRef(null);
    const captureRef = useRef(null);
    const dialogRef = useRef(null);


    const [url, setUrl] = useState(null);
    const [videoId, setVideoId] = useState(null);

    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0.0);
    const [duration, setDuration] = useState(0.0);
    const [progress, setProgress] = useState(0);
    const [screenshot, setScreenshot] = useState("null");

    const [rangeMax, setRangeMax] = useState(0.0);

    const [alertMessage, setAlertMessage] = useState("");

    const [data, setData] = useState([]);

    useEffect(() => {
        fetchVideos();
    }, []);

    useEffect(() => {
        if (!videoId) return;
        const currentVideo = data.find(v => v.id === videoId);
        if (currentVideo) {
            setUrl(currentVideo.url);
        }

        fetchCaptures(videoId);
    }, [videoId]);


    useEffect(() => {
        if (videoRef.current && url) {
            videoRef.current.load();
        }
    }, [url])

    const fetchVideos = async () => {
        try {
            const res = await fetch('/api/video');
            if (res.ok) {
                const videos = await res.json();
                setData(videos);
                if (videos.length > 0) {
                    setVideoId(videos[0].id);
                }
            } else {
                setAlertMessage("無法載入影片清單");
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Fetch videos error:", error);
        }
    };

    const uploadVideo = () => {
        // 1. 動態建立隱藏的 input 元素
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'video/mp4';

        // 2. 監聽當使用者選擇檔案後的動作
        fileInput.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // 檢查副檔名或類型
            if (!file.type.includes('video/mp4') && !file.name.endsWith('.mp4')) {
                setAlertMessage("只能上傳 MP4 格式的影片！");
                setOpenAlert(true);
                return;
            }

            // 3. 準備 FormData
            const formData = new FormData();
            formData.append('file', file);

            try {
                setAlertMessage(`正在上傳 ${file.name} ...`);
                setOpenAlert(true);

                // 4. Post 到 /api/video
                const res = await fetch('/api/video', {
                    method: 'POST',
                    body: formData,
                });

                const result = await res.json();

                if (res.ok) {
                    setAlertMessage(`上傳成功！檔名: ${result.filename}`);
                    setOpenAlert(true);
                    fetchVideos();
                } else {
                    setAlertMessage(`上傳失敗: ${result.detail || res.statusText}`);
                    setOpenAlert(true);
                }
            } catch (error) {
                console.error("Upload video error:", error);
                setAlertMessage("上傳過程發生錯誤");
                setOpenAlert(true);
            }
        };

        // 5. 觸發點擊，開啟檔案選擇對話框
        fileInput.click();
    };

    const [captures, setCaptures] = useState([]);

    // 1. 支援帶入 videoId 的 fetchCaptures 函式
    const fetchCaptures = async (videoId) => {
        try {
            const url = videoId ? `/api/capture?video_id=${videoId}` : '/api/capture';
            const res = await fetch(url);
            if (res.ok) {
                const data = await res.json();
                setCaptures(data);
            } else {
                console.error("無法載入截圖列表");
            }
        } catch (error) {
            console.error("Fetch captures error:", error);
        }
    };


    const handleCardClick = (card, idx) => {
        if (card) {
            setVideoId(card.id)
        }
    };



    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    const clickPlay = () => videoRef.current && videoRef.current.play();
    const clickPause = () => videoRef.current && videoRef.current.pause();

    const handleMetadata = (e) => {
        const duration = isFinite(e.target.duration) ? e.target.duration : 0;
        setCurrentTime(0.0);
        setDuration(duration);
        setRangeMax(duration);
    };

    const timeoutRef = useRef(null);

    const handleSeek = (e) => {
        const newTime = Number(e.target.value);

        // 1. 立即更新拉霸進度與畫面，保持極致流暢
        setProgress(newTime);

        // 2. 透過節流（Throttle），避免在拖曳時發送過多 video request
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }

        timeoutRef.current = setTimeout(() => {
            if (videoRef.current) {
                videoRef.current.currentTime = newTime;
            }
        }, 50);
    };

    const handleTimeUpdate = () => {
        if (videoRef.current) {
            const current = videoRef.current.currentTime;
            setProgress(current);
        }
    };

    const handleCapture = async () => {

        if (videoRef.current) {
            const canvas = document.createElement('canvas');
            canvas.width = videoRef.current.videoWidth;
            canvas.height = videoRef.current.videoHeight;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);

            const imageSrc = canvas.toDataURL('image/png');
            const video_time = videoRef.current.currentTime.toFixed(2)
            setScreenshot(imageSrc);
            // await uploadCanvas(imageSrc, filename);
            await appendImage(imageSrc, videoId, video_time)

        }
    };

    const appendImage = async (imageSrc, videoId, videoTime) => {
        const filename = `v_${videoId}_${videoTime}.png`;

        // 1. 檢查目前畫面的 captures 狀態是否已存在相同檔名（或相同時間）
        // 如果後端有擋重複，前端這裡也可以提早阻擋避免無謂的 API 請求
        if (captures.some(cap => cap.video_time === videoTime)) {
            setAlertMessage(`時間點 ${videoTime.toFixed(2)} 的截圖已經存在，略過新增`);
            setOpenAlert(true);
            return;
        }

        try {
            // 2. 將 base64 的 imageSrc 轉為 Blob
            const response = await fetch(imageSrc);
            const blob = await response.blob();

            // 3. 建立 FormData 並填入後端需要的欄位
            const formData = new FormData();
            formData.append('file', blob, filename);
            formData.append('video_id', videoId);
            formData.append('video_time', videoTime);

            // 4. 發送 POST 請求至 /api/capture
            const res = await fetch('/api/capture', {
                method: 'POST',
                body: formData
            });

            const result = await res.json();

            if (res.ok) {


                // 5. 上傳成功後，重新向後端 fetch 該影片的最新截圖清單
                await fetchCaptures(videoId);

                // 6. 等畫面更新後，自動捲動到底部
                setTimeout(() => {
                    if (captureRef.current) {
                        captureRef.current.scrollTo({
                            top: captureRef.current.scrollHeight,
                            behavior: 'smooth'
                        });
                    }
                }, 100); // 稍微拉長一點時間確保 DOM 已經渲染完成
            } else {
                setAlertMessage(`截圖上傳失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Upload capture error:", error);
            setAlertMessage("上傳過程發生網路或程式錯誤");
            setOpenAlert(true);
        }
    };

    const deleteCapture = async (id) => {
        try {
            const res = await fetch(`/api/capture/${id}`, {
                method: 'DELETE',
            });

            const result = await res.json();

            if (res.ok) {
                // 刪除成功後，更新前端 state 移除該筆截圖
                setCaptures(prev => prev.filter(cap => cap.id !== id));
            } else {
                setAlertMessage(`刪除失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Delete capture error:", error);
            setAlertMessage("刪除過程發生網路或程式錯誤");
            setOpenAlert(true);
        }
    };


    async function uploadCanvas(dataURL, filename) {
        setAlertMessage(filename)

        const response = await fetch(dataURL);
        const blob = await response.blob();

        const formData = new FormData();
        formData.append('file', blob, filename);
        formData.append('filename', filename);
        formData.append('source_video', props.selectedVideo);

        const res = await fetch('/api/capture', {
            method: 'POST',
            body: formData
        });

        const msg = await res.json();
        if (res.status == 200) {
            setAlertMessage(`${msg.message}:${filename}`);
            reloadImages();
        } else {
            setAlertMessage(`${res.statusText}:${filename}`);
        }
        setOpenAlert(true);
    }

    const setOpenAlert = (isOpen) => {
        const dialog = dialogRef.current;
        if (!dialog) return;

        if (isOpen) {
            dialog.showModal(); // 顯示為 Modal 互動對話框（會鎖定背景）
        } else {
            dialog.close();     // 關閉對話框
        }
    };

    const customStyle = {
        '--video-width': '640px',
        'textAlign': 'center'
    }

    return (
        <Layout sizes="30px" direction='v' style={customStyle}>
            <h1>Capture Video</h1>
            <Layout direction='h' sizes="320px">
                <Layout direction='v' sizes='36px' style={{ borderRight: "1px solid #999" }}>
                    <div style={{ padding: '3px 6px', textAlign: 'left' }}><button onClick={uploadVideo}>Upload Video</button></div>
                    <CardViewer data={data} direction="v" cardWidth='98cqw' scroll='y' onCardClick={handleCardClick}></CardViewer>
                </Layout>
                <Layout direction='v' sizes='420px'>
                    <Layout justifyContent='center' alignItems='center' padding="5px" style={{ borderBottom: '1px solid #999' }}>
                        <video ref={videoRef}
                            style={{ maxWidth: "var(--video-width)", border: '1px solid var(--c-border)' }}
                            crossOrigin="anonymous"
                            onLoadedMetadata={handleMetadata}
                            onPlay={handlePlay}
                            onPause={handlePause}
                            onTimeUpdate={handleTimeUpdate}
                        >
                            <source src={url} type="video/mp4" />
                        </video>
                        <Layout direction='h' sizes=",32px,32px,32px" gap="3px" justifyContent='center' alignItems='center' style={{ maxWidth: "var(--video-width)" }}>
                            <input
                                type="range"
                                max={rangeMax}
                                step="0.01"
                                value={progress}
                                disabled={!url}
                                onInput={(e) => handleSeek(e)}
                            />
                            {!isPlaying && <button disabled={!url} onClick={clickPlay}>▶</button>}
                            {isPlaying && <button disabled={!url} onClick={clickPause}>⏸</button>}
                            <button disabled={!url} onClick={handleCapture}>📷</button>
                        </Layout>
                    </Layout>
                    <CaptureViewer ref={captureRef} data={captures} onDelete={deleteCapture} scroll='y'></CaptureViewer>
                </Layout>
            </Layout>
            <dialog ref={dialogRef} onClick={() => { setOpenAlert(false) }}>
                <h1>Warning</h1>
                <div>{alertMessage}</div>
            </dialog>
        </Layout>
    )
}

export default CaptureVideo;
