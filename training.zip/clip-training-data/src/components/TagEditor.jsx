import { useState, useRef, useEffect, useImperativeHandle } from 'react'
import Layout from './Layout'


function TagEditor({
    style: userStyle = {},
    className,
    onTagChange,
    ref,
    ...restProps
}) {
    const dialogRef = useRef(null);
    const [alertMessage, setAlertMessage] = useState("");

    const [groupList, setGroupList] = useState([])
    const [tagList, setTagList] = useState([]);

    const [groupedTags, setGroupedTags] = useState({})
    const [groupCollapse, setGroupCollapse] = useState({})

    useEffect(() => {
        fetchTagGroup();
        fetchTag();

    }, []);

    useEffect(() => {
        if (onTagChange) {
            onTagChange(tagList);
        }
    }, [tagList, onTagChange]);

    useImperativeHandle(ref, () => ({
        getTagList: () => {
            return tagList;
        },
        getGroupList: () => {
            return groupList;
        },
    }));

    const fetchTagGroup = async () => {
        try {
            const url = '/api/tag_group';
            const res = await fetch(url);
            if (res.ok) {
                const data = await res.json();
                setGroupList(data);
            } else {
                console.error("無法載入Group");
            }
        } catch (error) {
            console.error("Fetch gruop error:", error);
        }
    };

    const fetchTag = async () => {
        try {
            const url = '/api/tag';
            const res = await fetch(url);
            if (res.ok) {
                const data = await res.json();
                setTagList(data);
            } else {
                console.error("無法載入Group");
            }
        } catch (error) {
            console.error("Fetch gruop error:", error);
        }
    };

    useEffect(() => {
        const gp = tagList.reduce((acc, tag) => {
            if (!acc[tag.tag_group_id]) {
                acc[tag.tag_group_id] = [];
            }
            acc[tag.tag_group_id].push(tag);
            return acc;
        }, {});

        setGroupedTags(gp);
    }, [tagList]);

    const collapseGroup = (tag_group_id) => {
        const collapse = {
            ...groupCollapse,
            [tag_group_id]: !groupCollapse[tag_group_id]
        }
        setGroupCollapse(collapse)
    }


    const [editingGroupId, setEditingGroupId] = useState(null);
    const [tempGroupName, setTempGroupName] = useState('');
    const gpInputRef = useRef(null);


    const editGroup = (gp) => {
        setEditingGroupId(gp.id);
        setTempGroupName(gp.group_name);

        setTimeout(() => {
            if (gpInputRef.current) {
                gpInputRef.current.select();
            }
        }, 50);
    };

    // 新增群組 (對應 POST /api/tag_group)
    const addGroup = async () => {
        try {
            const newGroupData = { group_name: 'new group' };

            const res = await fetch('/api/tag_group', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newGroupData)
            });

            const result = await res.json();

            if (res.ok) {
                await fetchTagGroup();
            } else {
                setAlertMessage(`新增群組失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Add group error:", error);
            setAlertMessage("新增群組過程發生錯誤");
            setOpenAlert(true);
        }
    };

    // 儲存編輯群組 (對應 PUT /api/tag_group)
    const saveGroup = async (gpId) => {
        try {
            const updateData = {
                id: gpId,
                group_name: tempGroupName
            };

            const res = await fetch('/api/tag_group', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(updateData)
            });

            const result = await res.json();

            if (res.ok) {
                // 更新前端畫面的 groupList 狀態
                const updated = groupList.map(g => g.id === gpId ? { ...g, group_name: tempGroupName } : g);
                setGroupList(updated)
                setEditingGroupId(null); // 關閉編輯狀態
            } else {
                setAlertMessage(`更新群組失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Save group error:", error);
            setAlertMessage("更新群組過程發生錯誤");
            setOpenAlert(true);
        }
    };

    // 刪除群組 (對應 DELETE /api/tag_group?tag_group_id=xxx)
    const deleteGroup = async (groupId) => {
        try {
            const res = await fetch(`/api/tag_group?tag_group_id=${groupId}`, {
                method: 'DELETE',
            });

            const result = await res.json();

            if (res.ok) {
                // 後端會連同該 group 下的 tag 一起刪除，前端也同步濾除
                const updatedTags = tagList.filter(tag => tag.tag_group_id !== groupId);
                const updatedGroups = groupList.filter(gp => gp.id !== groupId);
                setGroupList(updatedGroups)
                setTagList(updatedTags);
            } else {
                setAlertMessage(`刪除群組失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Delete group error:", error);
            setAlertMessage("刪除群組過程發生錯誤");
            setOpenAlert(true);
        }
    };

    const handleDragStart = (e, tag) => {
        const data = {...tag,type:'tag'}
        e.dataTransfer.setData('text/plain', JSON.stringify(data));
        let tagSpan = e.target;
        e.dataTransfer.setDragImage(tagSpan, -10, 0);
    };

    const handleDragOver = (e) => {
        e.preventDefault(); // 必須阻止預設行為才能觸發 onDrop
    };

    const handleDrop = (e, groupId) => {
        e.preventDefault();
        const tagData = JSON.parse(e.dataTransfer.getData('text/plain'));

        if (tagData.tag_group_id === groupId) {
            return;
        }

        const updateData = {
            id: tagData.id,
            tag_group_id: groupId
        };

        updateTag(updateData);

    };

    const [editingTagId, setEditingTagId] = useState(null);
    const [tempTagName, setTempTagName] = useState('');
    const tagInputRef = useRef(null);

    const editTag = (tag) => {
        setTempTagName(tag.name);
        setEditingTagId(tag.id);
        setTimeout(() => {
            if (tagInputRef.current) {
                tagInputRef.current.select();
            }
        }, 50);
    };

    const addTag = async (groupId) => {
        try {
            const newTagData = {
                tag_group_id: groupId,
                name: 'new tag'
            };

            const res = await fetch('/api/tag', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newTagData)
            });

            const result = await res.json();

            if (res.ok) {
                // 新增成功後重新抓取標籤列表，以取得後端產生的真實 id
                await fetchTag(); // 假設你有一個 fetchTags 函式用來向 GET /api/tag 取得資料
            } else {
                setAlertMessage(`新增標籤失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Add tag error:", error);
            setAlertMessage("新增標籤過程發生錯誤");
            setOpenAlert(true);
        }
    };

    const updateTag = async (updateData) => {
        try {

            const res = await fetch('/api/tag', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(updateData)
            });

            const result = await res.json();

            if (res.ok) {
                // 更新前端畫面的 tagList 狀態
                const updated = tagList.map(t => t.id === updateData.id ? { ...t, ...updateData } : t);
                setTagList(updated);
                setEditingTagId(null);
            } else {
                setAlertMessage(`更新標籤失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Save tag error:", error);
            setAlertMessage("更新標籤過程發生錯誤");
            setOpenAlert(true);
        }
    }


    const saveTag = async (tagId) => {
        const updateData = {
            id: tagId,
            name: tempTagName
        };
        updateTag(updateData);
    };




    const deleteTag = async (tagId) => {
        try {
            const res = await fetch(`/api/tag?tag_id=${tagId}`, {
                method: 'DELETE',
            });

            const result = await res.json();

            if (res.ok) {
                // 刪除成功後，從前端 state 濾除該筆標籤
                const updated = tagList.filter(tag => tag.id !== tagId);
                setTagList(updated);
            } else {
                setAlertMessage(`刪除標籤失敗: ${result.detail || res.statusText}`);
                setOpenAlert(true);
            }
        } catch (error) {
            console.error("Delete tag error:", error);
            setAlertMessage("刪除標籤過程發生錯誤");
            setOpenAlert(true);
        }
    };


    const setOpenAlert = (isOpen) => {
        const dialog = dialogRef.current;
        if (!dialog) return;

        if (isOpen) {
            dialog.showModal(); // 顯示為 Modal 互動對話框（會鎖定背景）
        } else {
            dialog.close();     // 關閉對話框
        }
    };

    const combinedStyle = {
        ...userStyle,
        // ...(height && { height }),
        // ...(width && { width }),
        'textAlign': 'left'
    };


    return (

        <div className={`tageditor ${className}`}
            style={combinedStyle}
            {...restProps}
        >
            <button className='btn-text' onClick={(e) => { addGroup() }}>✚ Add Group</button>
            {groupList.map((gp) => (
                <div key={gp.id}
                    onDragOver={handleDragOver}
                    onDrop={(e) => handleDrop(e, gp.id)}
                >
                    <Layout direction='h' sizes='1em,,24px,24px' gap='2px' height="40px" alignItems='center' className='tageditor_title'>
                        <span onClick={() => { collapseGroup(gp.id) }}>{!groupCollapse[gp.id] ? '▼' : '▶'}</span>
                        <div onDoubleClick={(e) => { e.stopPropagation(); editGroup(gp) }}>
                            {editingGroupId === gp.id ? (
                                <input
                                    ref={gpInputRef}
                                    type="text"
                                    value={tempGroupName}
                                    autoFocus
                                    onChange={(e) => setTempGroupName(e.target.value)}
                                    onBlur={() => saveGroup(gp.id)} // 失去焦點時自動儲存
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') saveGroup(gp.id); // 按 Enter 儲存
                                        if (e.key === 'Escape') setEditingGroupId(null); // 按 Esc 取消
                                    }}
                                    onClick={(e) => e.stopPropagation()} // 避免點擊 input 觸發其他事件
                                />
                            ) : (
                                /* 一般顯示狀態 */
                                <span>{gp.group_name} ({groupedTags[gp.id] ? groupedTags[gp.id].length : 0})</span>
                            )}
                        </div>
                        <button onClick={(e) => { e.stopPropagation(); addTag(gp.id) }}>✚</button>
                        <button onClick={(e) => { e.stopPropagation(); deleteGroup(gp.id) }}>✖</button>
                    </Layout>
                    {!groupCollapse[gp.id] &&
                        <div className='tageditor_box'>
                            {(groupedTags[gp.id] || []).map(tag => (
                                <div key={tag.id}
                                    className='tageditor_item'
                                    draggable
                                    onDragStart={(e) => handleDragStart(e, tag)}
                                    onDoubleClick={(e) => { e.stopPropagation(); editTag(tag) }}
                                >
                                    {editingTagId === tag.id ? (
                                        <input
                                            ref={tagInputRef}
                                            type="text"
                                            value={tempTagName}
                                            autoFocus
                                            onChange={(e) => setTempTagName(e.target.value)}
                                            onBlur={() => saveTag(tag.id)} // 失去焦點時自動儲存
                                            onKeyDown={(e) => {
                                                if (e.key === 'Enter') saveTag(tag.id); // 按 Enter 儲存
                                                if (e.key === 'Escape') setEditingTagId(null); // 按 Esc 取消
                                            }}
                                            onClick={(e) => e.stopPropagation()} // 避免點擊 input 觸發其他事件
                                        />
                                    ) : (
                                        <span>{tag.name}</span>
                                    )}
                                    <button onClick={(e) => { deleteTag(tag.id) }}>✖</button>
                                </div>
                            ))}
                        </div>
                    }
                </div>
            ))}
            <dialog ref={dialogRef} onClick={() => { setOpenAlert(false) }}>
                <h1>Warning</h1>
                <div>{alertMessage}</div>
            </dialog>
        </div>

    )
}





export default TagEditor;
