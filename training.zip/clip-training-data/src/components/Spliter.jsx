import React, { useState, useRef } from 'react';
import './component.css';

/**
 * 可拖曳調整大小的分割容器元件 (Spliter)
 * 
 * @component
 * @param {Object} props - 元件屬性
 * @param {'vertical'|'horizontal'|'v'|'h'} [props.direction='vertical'] - 分割排列方向
 * @param {string|number} [props.height] - 容器高度（例如："100px" 或 "100%"）
 * @param {string|number} [props.width] - 容器寬度（例如："100%" 或 "500px"）
 * @param {string} [props.sizes=""] - 各子元件的初始尺寸，以逗號分隔（例如："200px,,300px"）
 * @param {number} [props.minSize=2] - 子元件被壓縮時的最小像素限制
 * @param {number|string} [props.flexIndex] - 指定哪一個子元件自動填滿剩餘空間（flex: 1）
 * @param {import('react').CSSProperties} [props.style] - 自定義樣式物件
 * @param {import('react').ReactNode} [props.children] - 要分割的子元件們
 * @returns {JSX.Element}
 */
function Spliter({
    direction = "vertical",
    height,
    width,
    sizes = "",
    minSize = 2,
    flexIndex,
    gap,
    padding,
    alignContent,
    alignItems,
    alignSelf,
    justifyContent,
    justifyItems,
    justifySelf,
    className,    
    style: userStyle = {},
    children,
    ...restProps
}) {
    const directionMap = {
        vertical: 'vertical',
        horizontal: 'horizontal',
        v: 'vertical',
        h: 'horizontal',
    };

    const currentDirection = directionMap[direction] || 'vertical';
    const isVertical = currentDirection === 'vertical';

    const inputSizes = sizes !== undefined && sizes !== "" ? sizes.split(",") : [];

    const _sizes = Array.from({ length: React.Children.count(children) }, (_, idx) => {
        if (inputSizes[idx] !== undefined && inputSizes[idx].trim() != "") {
            return inputSizes[idx]
        }
        return undefined;
    });
    const _flexInex = flexIndex !== undefined ? parseInt(flexIndex) : _sizes.findLastIndex(item => item === undefined)
    const [sizeList, setSizeList] = useState(_sizes);


    const containerRef = useRef(null);

    // 處理滑鼠拖曳邏輯
    const handleMouseDown = (index, e) => {

        e.preventDefault();
        const container = containerRef.current;
        if (!container) return;

        const containerRect = container.getBoundingClientRect();
        const totalSize = isVertical ? containerRect.height : containerRect.width;

        const childrenNodes = Array.from(container.children).filter(el => !el.classList.contains('spliter-bar'));
        const currentPixels = childrenNodes.map(el =>
            isVertical ? el.getBoundingClientRect().height : el.getBoundingClientRect().width
        );

        const startX = e.clientX;
        const startY = e.clientY;

        const onMouseMove = (moveEvent) => {
            const delta = isVertical
                ? moveEvent.clientY - startY
                : moveEvent.clientX - startX;

            const offset = Math.min(Math.max(-currentPixels[index] + minSize, delta), currentPixels[index + 1] - minSize)

            const cloneList = sizeList.map((s, idx) => {
                if (idx === index) {
                    return (currentPixels[index] + offset) + "px"
                } else if (idx === index + 1) {
                    return (currentPixels[index + 1] - offset) + "px"
                } else {
                    return s
                }
            })

            const hasFlex = cloneList.filter((v) => v === undefined)
            if (hasFlex.length == 0) {
                cloneList[_flexInex] = undefined
            }
            setSizeList(cloneList);

        };

        const onMouseUp = () => {
            window.removeEventListener('mousemove', onMouseMove);
            window.removeEventListener('mouseup', onMouseUp);
        };

        window.addEventListener('mousemove', onMouseMove);
        window.addEventListener('mouseup', onMouseUp);
    };

    const combinedStyle = {
        ...userStyle,
        ...(height && { height }),
        ...(width && { width }),
        ...(gap && { gap }),
        ...(padding && { padding }),
        ...(alignContent && { alignContent }),
        ...(alignItems && { alignItems }),
        ...(alignSelf && { alignSelf }),
        ...(justifyContent && { justifyContent }),
        ...(justifyItems && { justifyItems }),
        ...(justifySelf && { justifySelf }),         
    };

    const validChildren = React.Children.toArray(children).filter(React.isValidElement);

    const renderedContent = [];

    validChildren.forEach((child, index) => {
        const sizeValue = sizeList[index];

        const sizeStyle = (sizeValue !== undefined && sizeValue !== "")
            ? { flex: `0 0 ${sizeValue}`, [isVertical ? 'minHeight' : 'minWidth']: 0 }
            : { flex: 1, [isVertical ? 'minHeight' : 'minWidth']: 0 };

        // 渲染子元素
        renderedContent.push(
            React.cloneElement(child, {
                key: `child-${index}`,
                style: {
                    ...child.props.style,
                    ...sizeStyle,
                },
            })
        );

        // 如果不是最後一個子元素，就在中間插入一個可拖曳的 bar
        if (index < validChildren.length - 1) {
            renderedContent.push(
                <div
                    key={`bar-${index}`}
                    className={`spliter-bar ${currentDirection}`}
                    onMouseDown={(e) => handleMouseDown(index, e)}
                />
            );
        }
    });

    return (
        <div
            ref={containerRef}
            className={`spliter ${currentDirection} ${className}`}
            style={combinedStyle}
            {...restProps}
        >
            {renderedContent}
        </div>
    );
}

export default Spliter;