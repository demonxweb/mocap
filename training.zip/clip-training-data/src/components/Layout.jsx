import React from 'react';
import './component.css';

/**
 * 彈性排版容器元件 (Layout)
 * 
 * @component
 * @param {Object} props - 元件屬性
 * @param {'vertical'|'horizontal'|'v'|'h'} [props.direction='vertical'] - 排版方向
 * @param {string|number} [props.height] - 容器高度（例如："100px" 或 "100%"）
 * @param {string|number} [props.width] - 容器寬度（例如："100%" 或 "500px"）
 * @param {string|number} [props.gap] - Item間距（例如："100%" 或 "5px"）
 * @param {string|number} [props.padding] - 容器padding（例如："100%" 或 "5px"）
 * @param {string|number} [props.alignItems] - Item對齊（同align-items）
 * @param {string} [props.sizes=""] - 子元素的尺寸對應清單，以逗號分隔（例如："10%,100px,50cqh"）
 * @param {import('react').CSSProperties} [props.style] - 自定義樣式物件
 * @param {import('react').ReactNode} [props.children] - 子元件
 * @returns {JSX.Element}
 */
function Layout({
    direction = "vertical",
    height,
    width,
    sizes = "", // 10%,100px,50cqh
    gap,
    padding,
    alignContent,
    alignItems,
    alignSelf,
    justifyContent,
    justifyItems,
    justifySelf,
    className='',
    style: userStyle = {},
    children,
    ...restProps
}) {

    const directionMap = {
        vertical: 'vertical',
        horizontal: 'horizontal',
        v: 'vertical',
        h: 'horizontal',
    };

    // 如果傳入的值在 map 裡面就用對應的值，否則預設為 'vertical'
    const currentDirection = directionMap[direction] || 'vertical';

    const combinedStyle = {
        ...userStyle,
        ...(height && { height }),
        ...(width && { width }),
        ...(gap && { gap }),
        ...(padding && { padding }),
        ...(alignContent && { alignContent }),
        ...(alignItems && { alignItems }),
        ...(alignSelf && { alignSelf }),
        ...(justifyContent && { justifyContent }),
        ...(justifyItems && { justifyItems }),
        ...(justifySelf && { justifySelf }),        
    };

    const sizels = sizes !== undefined ? sizes.split(",") : [];

    const renderedChildren = React.Children.map(children, (child, index) => {
        if (!React.isValidElement(child)) return child;

        const sizeValue = sizels[index];

        const sizeStyle = (sizeValue !== undefined && sizeValue !== "")
            ? { flex: `0 1 ${sizeValue}` }
            : { flex: 1 };

        return React.cloneElement(child, {
            style: {
                ...child.props.style,
                ...sizeStyle,
            },
        });
    });

    return (
        <div
            className={`layout ${currentDirection} ${className}`}
            style={combinedStyle}
            {...restProps}
        >
            {renderedChildren}
        </div>
    );
}

export default Layout;