import React, { useRef, useEffect, useImperativeHandle, useState } from 'react';
import PromptAutocomplete from './PromptAutocomplete';

import { capitalizeFirstLetter } from './PromptAutocomplete';

import pattern from '../data/pattern.json'



export const stripTagContent = (patternSettings, parsedContent) => {

    if (!parsedContent) return '';

    const regex = /(\[([a-z_]+):([\S ]*?)\]|<!([\S ]+?)>)/g;
    // /\[tag:(\d+)\]/g

    const isAlphaNumeric = (char) => /[a-zA-Z0-9\[\]<>]/.test(char);

    let lastIndex = -1;
    let lastResult = '';
    return parsedContent.replace(regex, (match, content, type, idStr, tmpStr, offset) => {
        const Id = Number(idStr);
        let result = '';
        if (type) {
            if (!isNaN(Id) && patternSettings.types.includes(type)) {
                const tagList = patternSettings[type]
                const targetTag = tagList.find(t => t.id === Id);
                if (targetTag) {
                    switch (type) {
                        case 'tag':
                            result = targetTag.name;
                            break;

                        case 'shot':
                            result = `[${capitalizeFirstLetter(type)} ${Id}]`
                            break;

                        default:
                            result = `<${capitalizeFirstLetter(type)} ${Id}>`
                            break;
                    }
                }
            } else if (type == 'section') {
                result = `${idStr}:`
            } else if (type == 'speaker') {
                result = `(S${idStr})`

            } else if (idStr == '#') {
                result = `<${capitalizeFirstLetter(type)} ?>`
            } else {
                result = idStr

            }
        }

        if (result) {


            const nextIndex = offset + match.length;

            let charBefore
            if (lastIndex == offset) {
                charBefore = lastResult.slice(-1);
            } else {
                charBefore = offset > 0 ? parsedContent[offset - 1] : '';
            }

            const charAfter = nextIndex < parsedContent.length ? parsedContent[nextIndex] : '';

            if (isAlphaNumeric(charBefore) && !/^\s/.test(result)) {
                result = ' ' + result;
            }

            if (isAlphaNumeric(charAfter) && !/\s$/.test(result)) {
                result = result + ' ';
            }
            lastIndex = nextIndex;
            lastResult = result;
        }


        return result;
    });
};


const createTagElement = (dataId, content, type = 'tag', className = 'tag_text') => {

    const tagSpan = document.createElement('span');
    tagSpan.textContent = content ? content : `未知標籤(${dataId})`;
    tagSpan.setAttribute('contentEditable', 'false');
    tagSpan.setAttribute('data-id', dataId);
    tagSpan.setAttribute('data-type', type);
    tagSpan.setAttribute('class', `tag_element ${className}`);

    tagSpan.setAttribute('draggable', 'true');


    return tagSpan;
};


const convertElement2TagContent = (container) => {
    let parsedContent = '';

    container.childNodes.forEach((node, index) => {
        if (node.nodeType === Node.TEXT_NODE) {
            parsedContent += node.textContent;
        } else if (node.nodeName === 'SPAN' && node.getAttribute('contenteditable') === 'false') {
            const dataId = node.getAttribute('data-id');
            const dataType = node.getAttribute('data-type');
            parsedContent += `[${dataType}:${dataId}]`;
        } else if (node.nodeName === 'BR') {
            parsedContent += '\n';
        } else if (node.nodeType === Node.ELEMENT_NODE) {
            parsedContent += convertElement2TagContent(node);

            const displayStyle = window.getComputedStyle(node).display;
            if (displayStyle === 'block' || node.nodeName === 'DIV' || node.nodeName === 'P') {
                if (index < container.childNodes.length - 1 && !parsedContent.endsWith('\n')) {
                    parsedContent += '\n';
                }
            }
        }
    });

    return parsedContent;
};

const insertElement = (range, item, elm) => {
    try {

        if (elm) {
            const dataId = elm.getAttribute('data-id');
            const dataType = elm.getAttribute('data-type');
            elm.textContent = item.name
            elm.setAttribute('data-id', item.id);
            // elm.setAttribute('data-type', item.type);
            // elm.setAttribute('class', `tag_element ${className}`);


        } else {
            const selection = window.getSelection();
            let targetRange
            if (item.slice) {
                targetRange = range.cloneRange();
                const startContainer = range.startContainer;
                const startOffset = range.startOffset;
                const endContainer = range.endContainer;
                const endOffset = range.endOffset;

                targetRange.setStart(endContainer, endOffset - item.slice);
                targetRange.deleteContents();

            } else {
                range.deleteContents();
                targetRange = range
            }

            let node;
            if (item.type === 'br') {
                node = document.createElement('br');

            } else if (item.type === 'pattern') {
                node = document.createElement('span');
                drawContent(node, item.name, [])
            } else {
                node = createTagElement(item.id, item.name, item.type, `tag_${item.type}`)
            }

            targetRange.insertNode(node);
            targetRange.setStartAfter(node);
            targetRange.collapse(true);
            selection.removeAllRanges();
            selection.addRange(targetRange);
        }

        return true;
    } catch (err) {
        console.error('插入失敗', err);
        return false;
    }
}

const drawContent = (container, parsedContent, tagList = []) => {
    if (!container) return;
    container.innerHTML = '';

    if (!parsedContent) return;

    const regex = /(\[([a-z_]+):([\S ]*?)\]|<!([\S ]+?)>|\n)/g;
    let lastIndex = 0;
    let match;
    while ((match = regex.exec(parsedContent)) !== null) {
        if (match.index > lastIndex) {
            container.appendChild(
                document.createTextNode(parsedContent.substring(lastIndex, match.index))
            );
        }

        const token = match[0];
        const type = match[2];
        const dataId = match[3];



        if (token === '\n') {
            container.appendChild(document.createElement('br'));

        } else if (token.startsWith('<!')) {
            const temp = match[4];
            const Span = createTagElement(temp, temp, 'temp', `tag_temp`);
            container.appendChild(Span);

        } else if (type == 'tag') {
            const tagId = Number(dataId) || 0;
            const targetTag = tagList.find(t => t.id === tagId);
            const tagName = targetTag ? targetTag.name : null;
            const tagSpan = createTagElement(tagId, tagName, type, `tag_${type}`);
            container.appendChild(tagSpan);

        } else if (type == 'section') {
            const Span = createTagElement(dataId, dataId, type, `tag_${type}`);
            container.appendChild(Span);
        } else if (type) {
            let name = `${dataId}`;
            if (!isNaN(Number(dataId)) || dataId === '#') {
                name = `${capitalizeFirstLetter(type)} ${dataId}`
            }
            const Span = createTagElement(dataId, name, type, `tag_${type}`);
            container.appendChild(Span);
        }

        lastIndex = regex.lastIndex;
    }

    if (lastIndex < parsedContent.length) {
        container.appendChild(
            document.createTextNode(parsedContent.substring(lastIndex))
        );
    }
};




function PromptEditor({
    tagList = [],
    prompt = '',
    style: userStyle = {},
    className = '',
    onInput,
    ref,
    ...restProps
}) {

    const [patternSettings, setPatternSettings] = useState({});
    const autoRef = useRef(null);
    const promptRef = useRef(null);
    const indicatorRef = useRef(null);

    useEffect(() => {
        const container = promptRef.current
        if (prompt) {
            drawContent(container, prompt, tagList);
        } else {
            if (container) {
                container.innerHTML = '';
            }
        }
    }, [prompt]);

    useEffect(() => {

        const p = { ...pattern, tag: tagList }
        setPatternSettings(p)

    }, [tagList]);

    useEffect(() => {
        const handleSelectionChange = () => {
            const selection = window.getSelection();
            if (!selection.rangeCount) return;

            const range = selection.getRangeAt(0);

            // 檢查編輯器裡所有的 tag_element
            const tags = promptRef.current?.querySelectorAll('.tag_element');
            tags?.forEach(tag => {
                // 判斷這個 tag 是否被包含在目前的 selection 範圍內
                if (range.intersectsNode(tag)) {
                    tag.classList.add('is-selected');
                } else {
                    tag.classList.remove('is-selected');
                }
            });
        };

        document.addEventListener('selectionchange', handleSelectionChange);
        return () => {
            document.removeEventListener('selectionchange', handleSelectionChange);
        };
    }, []);

    useImperativeHandle(ref, () => ({
        getContent: () => {
            if (!promptRef.current) return '';
            return convertElement2TagContent(promptRef.current);
        },
        getPureContent: () => {
            if (!promptRef.current) return '';
            const structuralContent = convertElement2TagContent(promptRef.current);
            return stripTagContent(patternSettings, structuralContent);
        },
        focus: () => {
            if (promptRef.current) promptRef.current.focus();
        }
    }));

    const handleDragStart = (e) => {

        const tagSpan = e.target.closest('.tag_element');
        if (!tagSpan) return;

        const dataId = tagSpan.getAttribute('data-id');
        const type = tagSpan.getAttribute('data-type');
        const content = tagSpan.textContent;

        e.dataTransfer.setData('text/plain', JSON.stringify({ type, id: dataId, name: content }));
        window.__draggingTagElement = tagSpan;

        if (e.dataTransfer.setDragImage) {
            e.dataTransfer.setDragImage(tagSpan, -10, 0);
        }
    };


    const handleDragEnd = (e) => {
        const tagSpan = e.target.closest('.tag_element');
        if (!tagSpan) return;
        window.__draggingTagElement = null;
    };

    const handleDragOver = (e) => {
        e.preventDefault();

        let range = null;

        if (document.caretRangeFromPoint) {
            range = document.caretRangeFromPoint(event.clientX, event.clientY);
        } else if (document.caretPositionFromPoint) {
            let pos = document.caretPositionFromPoint(event.clientX, event.clientY);
            if (pos) {
                range = document.createRange();
                range.setStart(pos.offsetNode, pos.offset);
                range.collapse(true);
            }
        }


        if (range) {
            const selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(range);
        }

    };


    const handleDrop = (e) => {
        e.preventDefault();
        try {
            let targetNode = e.target;

            if (document.elementFromPoint) {
                const elementUnderMouse = document.elementFromPoint(e.clientX, e.clientY);
                if (elementUnderMouse) {
                    targetNode = elementUnderMouse;
                }
            }


            const tagElement = targetNode && targetNode.closest ? targetNode.closest('.tag_element') : null;

            const selection = window.getSelection();
            let range = document.createRange();

            const draggingElem = window.__draggingTagElement;
            const isInternalMove = draggingElem && promptRef.current.contains(draggingElem);

            if (isInternalMove) {
                draggingElem.remove();
            }

            if (tagElement) {
                range.setStartBefore(tagElement);
                range.collapse(true);
            } else {
                let caretRange = null;
                if (document.caretRangeFromPoint) {
                    caretRange = document.caretRangeFromPoint(e.clientX, e.clientY);
                }

                if (!caretRange && selection.rangeCount > 0) {
                    caretRange = selection.getRangeAt(0);
                }

                if (caretRange) {
                    range = caretRange;
                } else {
                    range.selectNodeContents(promptRef.current);
                    range.collapse(false);
                }
            }


            const rawData = e.dataTransfer.getData('text/plain');
            if (!rawData) return;
            const tagData = JSON.parse(rawData);
            if (!tagData || !tagData.name) return;

            const item = { ...tagData };
            insertItem(e, range, item);


        } catch (err) {
            console.log('拖曳解析失敗', err);
        } finally {
            window.__draggingTagElement = null;
            if (indicatorRef.current) {
                indicatorRef.current.remove();
                indicatorRef.current = null;
            }
        }
    };

    const handleKeyDown = (e) => {


        if (e.key === 'Enter') {
            const isMenuOpen = autoRef.current && promptRef.current?.parentElement?.querySelector('ul');
            if (isMenuOpen) {
                return
            }
            e.preventDefault();
            const selection = window.getSelection();
            if (!selection.rangeCount) return;
            const range = selection.getRangeAt(0);
            const item = { type: 'br' }
            insertItem(e, range, item);

        } else if (e.key === 'Backspace') {
            const selection = window.getSelection();
            if (!selection.rangeCount) return;

            const range = selection.getRangeAt(0);


            if (!range.collapsed) return;

            const container = range.startContainer;
            const offset = range.startOffset;

            if (container.nodeType === Node.ELEMENT_NODE && offset > 0) {
                const currentNode = container.childNodes[offset];

                if (currentNode === undefined || currentNode.nodeName === 'BR') {
                    for (let i = 1; i < offset; i++) {
                        const node = container.childNodes[offset - i]
                        if (node.nodeType === Node.TEXT_NODE) {
                            if (node.textContent) {
                                break
                            } else {
                                e.preventDefault();
                                node.remove();
                            }
                        } else if (node.nodeType === Node.ELEMENT_NODE) {
                            e.preventDefault();
                            node.remove();
                            break
                        }
                    }
                }

            }

        }
    };

    const handleDoubleClick = (e) => {
        const tagSpan = e.target.closest('.tag_element');
        if (!tagSpan) return;

        const dataId = tagSpan.getAttribute('data-id');
        const type = tagSpan.getAttribute('data-type');
        const content = tagSpan.textContent;

        autoRef.current.changeItem(e, tagSpan, { id: dataId, type: type, name: content })

    };

    const insertItem = (e, range, item, elm = null) => {

        insertElement(range, item, elm);

        if (onInput) {
            const content = convertElement2TagContent(promptRef.current);
            onInput(e, content);
        }

    }

    const handleCopy = (e) => {
        const selection = window.getSelection();
        if (!selection.rangeCount || selection.isCollapsed) return;

        e.preventDefault();

        const container = document.createElement('div');
        container.appendChild(selection.getRangeAt(0).cloneContents());
        const convertedText = convertElement2TagContent(container);

        e.clipboardData.setData('text/plain', convertedText);
    };
    const handleCut = (e) => {
        const selection = window.getSelection();
        if (!selection.rangeCount || selection.isCollapsed) return;

        e.preventDefault(); // 阻止預設剪下行為

        const range = selection.getRangeAt(0);

        const container = document.createElement('div');
        container.appendChild(range.cloneContents());
        const convertedText = convertElement2TagContent(container);

        e.clipboardData.setData('text/plain', convertedText);

        range.deleteContents();

        range.collapse(true);
        selection.removeAllRanges();
        selection.addRange(range);

        const content = convertElement2TagContent(promptRef.current);
        onInput(e, content);

    };
    const handlePaste = (e) => {
        e.preventDefault(); // 阻止預設貼上行為


        const text = e.clipboardData.getData('text/plain');
        if (!text) return;

        const selection = window.getSelection();
        if (!selection.rangeCount) return;

        const range = selection.getRangeAt(0);
        range.deleteContents();

        const fragment = document.createDocumentFragment();

        const tempDiv = document.createElement('div');

        drawContent(tempDiv, text, tagList);

        while (tempDiv.firstChild) {
            fragment.appendChild(tempDiv.firstChild);
        }

        range.insertNode(fragment);

        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);

        const content = convertElement2TagContent(promptRef.current);
        onInput(e, content);

    };
    const combinedStyle = {
        ...userStyle,
        textAlign:'left',
        overflow: 'auto',
    };

    return (
        <PromptAutocomplete
            ref={autoRef}
            PatternSettings={patternSettings}
            onInsertItem={insertItem}
        >
            <div
                ref={promptRef}
                style={combinedStyle}
                className={`${className}`}
                contentEditable='true'
                onDragStart={handleDragStart}
                onDragEnd={handleDragEnd}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e)}
                onDoubleClick={handleDoubleClick}
                onCopy={handleCopy}
                onCut={handleCut}
                onPaste={handlePaste}
                onInput={(e) => {
                    if (onInput) {
                        const content = convertElement2TagContent(promptRef.current);
                        onInput(e, content);
                    }
                }}
                onKeyDown={handleKeyDown}
                {...restProps}
            />
        </PromptAutocomplete>
    );
}

export default PromptEditor;