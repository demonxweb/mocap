import React from 'react';
import { useState, useRef, useEffect, useImperativeHandle } from 'react';
import './component.css';


function CaptureViewer({
    imgWidth = "240px",
    imgHeight = "180px",
    scroll = 'none',
    data = [],
    onDelete,
    className = '',
    style: userStyle = {},
    ...restProps
}) {

    const scrollMap = {
        xy: 'auto',
        x: 'auto hidden',
        y: 'hidden auto',
        none: 'hidden',
    };

    const currentScroll = scrollMap[scroll] || 'hidden';



    const deleteImg = (e, captureId) => {

        if (onDelete) onDelete(captureId);

    }

    const combinedStyle = {
        ...userStyle,
        '--capture-viewer-width': imgWidth,
        '--capture-viewer-height': imgHeight,
        'overflow': currentScroll,
    };

    return (
        <div
            className={`capture-viewer ${className}`}
            style={combinedStyle}
            {...restProps}>

            {data.map((capture, idx) => (
                <div className='capture-item' key={capture.id}>
                    <img src={capture.url} alt={capture.filename}></img>
                    <button onClick={(e) => { deleteImg(e, capture.id) }}>🗑️</button>
                </div>
            ))}

        </div>
    );
}

export default CaptureViewer;