import React, { useState, useRef, useImperativeHandle } from 'react';


export function capitalizeFirstLetter(str) {
    if (!str) return ''; // 避免空字串錯誤
    return str.charAt(0).toUpperCase() + str.slice(1);
}

export function MoveCursor(elm) {
    const selection = window.getSelection();
    const range = document.createRange();

    range.setStartAfter(elm);
    range.collapse(true); // 將範圍摺疊成一個單純的游標點

    selection.removeAllRanges();
    selection.addRange(range);

    return range
}



const detectCurrentSection = (editorElement) => {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    const preCaretRange = document.createRange();
    preCaretRange.selectNodeContents(editorElement);
    preCaretRange.setEnd(range.endContainer, range.endOffset);

    const tempDiv = document.createElement('div');
    tempDiv.appendChild(preCaretRange.cloneContents());

    const childNodes = tempDiv.lastChild.childNodes;

    let line = '';



    for (let i = childNodes.length - 1; i >= 0; i--) {
        const node = childNodes[i];

        if (node.tagName === 'BR') {
            break;
        }
        if (node.nodeType === Node.ELEMENT_NODE) {
            const computedStyle = window.getComputedStyle(node);
            const display = computedStyle.display;

            if (['block', 'flex', 'grid', 'list-item'].includes(display)) {
                break
            } else if (node.classList.contains('tag_section') || ['DIV', 'P', 'H1', 'H2', 'LI'].includes(node.tagName)) {
                break
            }
        }
        if (line) {
            line = node.textContent + ' ' + line;
        } else {
            line = node.textContent;
        }
    }



    const allElements = tempDiv.querySelectorAll('*');
    const sectionTags = tempDiv.querySelectorAll('[data-type="section"]');

    let lastFoundSection = '';
    if (sectionTags.length > 0) {
        const lastTag = sectionTags[sectionTags.length - 1];
        lastFoundSection = lastTag.getAttribute('data-id') || '';
    }
    return { line, lastFoundSection };
}


function PromptAutocomplete({
    PatternSettings = {},
    onInsertItem,
    children,
    style = {},
    ref,
    className = ''
}) {
    const [isOpen, setIsOpen] = useState(false);
    const [suggestions, setSuggestions] = useState([]);
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [dropdownPos, setDropdownPos] = useState({ top: 0, left: 0 });
    const [currentSection, setCurrentSection] = useState('');

    const activeRangeRef = useRef(null);
    const activeElmRef = useRef(null);
    const editorRef = useRef(null);


    useImperativeHandle(ref, () => ({
        changeItem: (e, tagSpan, data) => {

            let matchedItems = [];
            const tagList = PatternSettings[data.type] || [];
            tagList.forEach(t => {
                const name = t.name || t.id
                matchedItems.push({
                    id: t.id,
                    type: data.type,
                    name: name,
                    label: `${capitalizeFirstLetter(data.type)}`
                });
            });

            const range = MoveCursor(tagSpan);
            showMenu(matchedItems, range, tagSpan);

        },

    }));


    const checkAutocomplete = (editorElement) => {


        const selection = window.getSelection();
        if (!selection.rangeCount) return;

        const range = selection.getRangeAt(0);
        if (!range.collapsed) return;

        if (!editorElement.contains(range.startContainer)) {
            closeDropdown();
            return;
        }
        const { line, lastFoundSection } = detectCurrentSection(editorElement);
        setCurrentSection(lastFoundSection);

        const keyword = line;

        const node = range.startContainer;
        if (node.nodeType === Node.TEXT_NODE) {
            const cursorOffset = range.startOffset;
            let matchedItems = [];

            const SECTION_PATTERNS = PatternSettings['sections'];

            if (currentSection) {
                const templateList = SECTION_PATTERNS[currentSection] || [];
                templateList.forEach(patternTemplate => {
                    if (patternTemplate.toLowerCase().includes(keyword.toLowerCase())) {
                        matchedItems.push({
                            type: 'pattern',
                            name: patternTemplate,
                            label: `[Pattern] ${currentSection}`
                        });
                    }
                });
            }


            Object.keys(SECTION_PATTERNS).forEach(sectionKey => {
                if (sectionKey.toLowerCase().includes(keyword.toLowerCase())) {
                    matchedItems.push({
                        type: 'section',
                        id: `${sectionKey}`,
                        name: `${sectionKey}`,
                        label: '[Section]'
                    });
                }
            });


            const lastSpaceIndex = keyword.lastIndexOf(' ');

            const lastKeyword = lastSpaceIndex !== -1
                ? keyword.substring(lastSpaceIndex + 1).toLocaleLowerCase().trim()
                : keyword.toLocaleLowerCase().trim()

            const types = PatternSettings.types || [];



            const maxLen = Math.min(lastKeyword.length, 4);
            types.forEach(tp => {
                const tagList = PatternSettings[tp] || [];
                let ct = 0;
                for (let i = maxLen; i > 0; i--) {
                    const keyword = lastKeyword.slice(-i);
                    tagList.forEach(t => {
                        const name = String(t.name || t.id)
                        if (name.toLocaleLowerCase().startsWith(keyword)) {
                            matchedItems.push({
                                id: t.id,
                                type: tp,
                                name: name,
                                label: `${capitalizeFirstLetter(tp)}`,
                                slice:i,
                            })
                            ct += 1;
                        }
                    });
                    if (ct > 0) break;
                }
            });

            if (matchedItems.length > 0 && lastKeyword.length > 0) {
                const keywordRange = document.createRange();
                const startOffset = Math.max(0, cursorOffset - lastKeyword.length);
                keywordRange.setStart(node, startOffset);
                keywordRange.setEnd(node, cursorOffset);
                showMenu(matchedItems, keywordRange);
                return;
            }

        }
        closeDropdown();
    };



    const showMenu = (matchedItems, range, elm = null) => {
        let rect;
        if (elm) {
            rect = elm.getBoundingClientRect();
            activeElmRef.current = elm
        } else {
            activeRangeRef.current = range
            rect = range.getBoundingClientRect();
        }


        if (matchedItems.length > 0) {
            setSuggestions(matchedItems);
            setSelectedIndex(0);
            setIsOpen(true);

            setDropdownPos({
                left: rect.left,
                top: rect.bottom,
            });

        } else {
            closeDropdown()
        }

    }

    const closeDropdown = () => {
        setIsOpen(false);
        setSuggestions([]);
        activeRangeRef.current = null;
        activeElmRef.current = null
    };

    const selectItem = (e, item) => {
        const range = activeRangeRef.current;
        const elm = activeElmRef.current

        if (!range && !elm) return;
        if (onInsertItem) {
            onInsertItem(e, range, item, elm)
            closeDropdown();
            if (editorRef.current) editorRef.current.focus();
        }
        return

    };

    const handleKeyDown = (e) => {
        if (isOpen) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setSelectedIndex(prev => (prev + 1) % suggestions.length);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setSelectedIndex(prev => (prev - 1 + suggestions.length) % suggestions.length);
            } else if (e.key === 'Enter' || e.key === 'Tab') {
                e.preventDefault();
                if (suggestions[selectedIndex]) {
                    selectItem(e, suggestions[selectedIndex]);
                }
            } else if (e.key === 'Escape') {
                e.preventDefault();
                closeDropdown();
            }
        }
    };

    return (
        <div
            ref={editorRef}
            style={{ position: 'relative', display: 'inline-block', width: '100%', ...style }}
            className={`prompt_auto ${className}`}
            onKeyDown={handleKeyDown}
            onInput={(e) => checkAutocomplete(e.currentTarget)}
            onClick={closeDropdown}
        >
            {children}

            {isOpen && suggestions.length > 0 && (
                <ul style={{
                    top: dropdownPos.top,
                    left: dropdownPos.left,
                }}>
                    {suggestions.map((item, index) => (
                        <li
                            key={index}
                            className={index === selectedIndex ? 'hover' : ''}
                            onMouseDown={(e) => {
                                e.preventDefault();
                                selectItem(e, item);
                            }}
                            onMouseOver={(e) => { setSelectedIndex(index) }}
                        >
                            <span>{item.label}</span>
                            {item.name}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}

export default PromptAutocomplete;