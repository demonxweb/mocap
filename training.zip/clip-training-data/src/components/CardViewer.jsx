import React from 'react';
import { useState, useRef, useEffect } from 'react';
import './component.css';

/**
 * 圖片檢視器元件 (CardViewer)
 * 
 * @component
 * @param {Object} props - 元件屬性
 * @param {string} [props.cardWidth="200px"] - 圖片卡片寬度（例如："200px"）
 * @param {string} [props.cardHeight="200px"] - 圖片卡片高度（例如："200px"）
 * @param {'vertical'|'horizontal'|'v'|'h'} [props.direction='vertical'] - 排列方向
 * @param {'xy'|'x'|'xy'|'none'} [props.scroll='none'] - 捲軸方向
 * @param {'cover'|'contain'|'corop'} [props.fit='cover'] - 圖片填滿模式
 * @param {boolean} [props.wrap=false] - 是否允許自動換行
 * @param {Array<{url: string, filename?: string, content?: string}>} [props.data=[]] - 圖片資料陣列
 * @param {(card: Object, index: number) => void} [props.onCardClick] - 點擊卡片時觸發的回呼函式
 * @param {import('react').CSSProperties} [props.style] - 自定義樣式物件
 * @returns {JSX.Element}
 */
function CardViewer({
    cardWidth = "200px",
    cardHeight = "200px",
    direction = 'vertical',
    scroll = 'none',
    fit = 'cover',
    wrap = false,
    data = [],
    children,
    className = '',
    onCardClick,
    onCardDelete,
    onDropFile,
    style: userStyle = {},
    ...restProps
}) {

    const containerRef = useRef(null);
    // 用來儲存每個卡片 DOM 元素的 ref
    const cardRefs = useRef([]);
    const [selectedIndex, setSelectedIndex] = useState(null);
    const [isDragging, setIsDragging] = useState(false);

    const videoExtensions = ['.mp4', '.webm', '.ogg', '.mov', '.avi', '.mkv', '.m4v'];
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp', '.avif'];

    const directionMap = {
        vertical: 'vertical',
        horizontal: 'horizontal',
        v: 'vertical',
        h: 'horizontal',
    };

    const fitMap = {
        cover: 'cover',
        contain: 'contain',
        corop: 'cover',
    };

    const scrollMap = {
        xy: 'auto',
        x: 'auto hidden',
        y: 'hidden auto',
        none: 'hidden',
    };

    const currentDirection = directionMap[direction] || 'vertical';
    const currentFit = fitMap[fit] || 'cover';
    const currentWrap = wrap ? "wrap" : "";
    const currentScroll = scrollMap[scroll] || 'hidden';


    const combinedStyle = {
        ...userStyle,
        '--card-viewer-width': cardWidth,
        '--card-viewer-height': cardHeight,
        '--card-viewer-fit': currentFit,
        'overflow': currentScroll,
    };

    const scrollToCenter = (cardElement) => {
        const container = containerRef.current;
        if (!container || !cardElement) return;

        const containerRect = container.getBoundingClientRect();
        const cardRect = cardElement.getBoundingClientRect();

        const isHorizontal = currentDirection === 'horizontal';

        if (isHorizontal) {
            // 計算卡片相對於 container 內容的目前位置與中心點差值
            const currentScrollLeft = container.scrollLeft;
            // 卡片中心點相對於視窗的座標 - 容器中心點相對於視窗的座標 + 當前已捲動的距離
            const cardCenter = cardRect.left + (cardRect.width / 2);
            const containerCenter = containerRect.left + (containerRect.width / 2);
            const offset = cardCenter - containerCenter;

            container.scrollTo({
                left: currentScrollLeft + offset,
                behavior: 'smooth'
            });
        } else {
            const currentScrollTop = container.scrollTop;
            const cardCenter = cardRect.top + (cardRect.height / 2);
            const containerCenter = containerRect.top + (containerRect.height / 2);
            const offset = cardCenter - containerCenter;

            container.scrollTo({
                top: currentScrollTop + offset,
                behavior: 'smooth'
            });
        }
    };

    useEffect(() => {
        const container = containerRef.current;
        if (!container) return;

        const handleWheel = (e) => {
            if (scroll === "x" && e.deltaY !== 0) {
                e.preventDefault();
                container.scrollLeft += e.deltaY;
            }
        };

        container.addEventListener('wheel', handleWheel, { passive: false });

        return () => {
            container.removeEventListener('wheel', handleWheel);
        };
    }, [scroll]);

    const deleteImg = (e, captureId) => {

        if (onCardDelete) onCardDelete(captureId);

    }


    const handleDragEnter = (e) => {
        if (!onDropFile) return;
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
    };

    // 🔥 處理拖曳離開
    const handleDragLeave = (e) => {
        if (!onDropFile) return;
        e.preventDefault();
        e.stopPropagation();
        // 確保離開的是 container 本身，而不是子元素
        if (e.target === containerRef.current) {
            setIsDragging(false);
        }
    };

    // 🔥 處理拖曳懸停 (必須 preventDefault 才能觸發 drop)
    const handleDragOver = (e) => {
        if (!onDropFile) return;
        e.preventDefault();
        e.stopPropagation();
    };

    // 🔥 處理放開檔案
    const handleDrop = (e) => {
        if (!onDropFile) return;
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);

        const files = e.dataTransfer.files;
        if (files && files.length > 0) {
            if (onDropFile) {
                onDropFile(files); // 傳遞取得的檔案清單給父元件
            }
        }
    };
    let o=0.8
    if(isDragging){
        o=1
    }

    return (
        <div ref={containerRef}
            className={`card-viewer ${currentDirection} ${currentWrap} ${className}`}
            style={combinedStyle}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            {...restProps}>

            {((onDropFile&& data.length==0) ||isDragging) && (<div className={`dropmessage ${isDragging?'dragging':''}` }>📂 請放開滑鼠以上傳檔案...</div>)}

            {data.map((card, idx) => {
                const cleanUrl = card.url.split('?')[0].toLowerCase();
                const is_video = videoExtensions.some(ext => cleanUrl.endsWith(ext))
                const is_image = imageExtensions.some(ext => cleanUrl.endsWith(ext))
                const isSelected = selectedIndex === idx
                return <div
                    key={idx}
                    ref={(el) => (cardRefs.current[idx] = el)} // 收集每個 card 的 DOM 參考
                    className={`card ${currentDirection} ${isSelected ? 'selected' : ''}`}
                    onClick={(e) => {
                        setSelectedIndex(idx);
                        scrollToCenter(cardRefs.current[idx]);
                        if (onCardClick) onCardClick(card, idx);
                    }}
                >
                    {is_video && <video><source src={card.url} type="video/mp4" /></video>}
                    {is_image && <img src={card.url} alt="" />}
                    {onCardDelete && <button onClick={(e) => { deleteImg(e, card.id) }}>🗑️</button>}
                    {(card.filename || card.content) &&
                        <div className="comment">
                            {card.filename && <h3>{card.filename}</h3>}
                            {card.content && <p>{card.content}</p>}
                        </div>
                    }
                </div>
            })}
        </div>
    );
}

export default CardViewer;