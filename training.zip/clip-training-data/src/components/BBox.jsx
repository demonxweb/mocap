import { useState, useRef, useEffect } from 'react'

import { Rnd } from 'react-rnd';



function BBox({
    url,
    boxes,
    onAddBox,
    onUpdateBox,
    onDeleteBox,
    style = {},
}
) {
    const containerRef = useRef(null);
    const imgRef = useRef(null);


    const [imgDimensions, setImgDimensions] = useState({ width: 0, height: 0 });
    const [isDrawing, setIsDrawing] = useState(false);
    const [startPos, setStartPos] = useState({ x: 0, y: 0 });

    const [tempRect, setTempRect] = useState(null);
    const [selectedBoxId, setSelectedBoxId] = useState(null);

    useEffect(() => {
        const updateDimensions = () => {
            if (imgRef.current) {
                setImgDimensions({
                    width: imgRef.current.clientWidth,
                    height: imgRef.current.clientHeight
                });
            }
        };

        updateDimensions();

        // 1. 使用 ResizeObserver 監聽容器大小變化（例如 Spliter 被拖曳縮放時）
        const containerElement = containerRef.current;
        const resizeObserver = new ResizeObserver(() => {
            updateDimensions();
        });

        if (containerElement) {
            resizeObserver.observe(containerElement);
        }

        // 2. 監聽圖片本身的 load 事件（確保圖片剛載入好時尺寸正確）
        const imgElement = imgRef.current;
        if (imgElement) {
            imgElement.addEventListener('load', updateDimensions);
        }

        return () => {
            if (containerElement) {
                resizeObserver.unobserve(containerElement);
            }
            resizeObserver.disconnect();

            if (imgElement) {
                imgElement.removeEventListener('load', updateDimensions);
            }
        };
    }, [url]);


    const handleMouseDown = (e) => {
        if (e.target.closest('.rnd-box')) return;
        if (!imgRef.current) return;

        const imgRect = imgRef.current.getBoundingClientRect();
        setIsDrawing(true);
        const startX = e.clientX - imgRect.left;
        const startY = e.clientY - imgRect.top;
        setStartPos({ x: startX, y: startY });
        setTempRect({ x: startX, y: startY, width: 0, height: 0 });
    };

    const handleMouseMove = (e) => {
        if (!isDrawing || !imgRef.current) return;
        const imgRect = imgRef.current.getBoundingClientRect();
        const currentX = e.clientX - imgRect.left;
        const currentY = e.clientY - imgRect.top;

        setTempRect({
            x: Math.min(startPos.x, currentX),
            y: Math.min(startPos.y, currentY),
            width: Math.abs(currentX - startPos.x),
            height: Math.abs(currentY - startPos.y),
        });
    };

    const handleMouseUp = () => {
        if (isDrawing && tempRect && tempRect.width > 5 && tempRect.height > 5 && imgRef.current) {
            if (onAddBox) {
                const imgWidth = imgRef.current.clientWidth;
                const imgHeight = imgRef.current.clientHeight;


                const newBox = {
                    x: tempRect.x / imgWidth,
                    y: tempRect.y / imgHeight,
                    width: tempRect.width / imgWidth,
                    height: tempRect.height / imgHeight,
                };


                const newid = onAddBox(newBox)
                setSelectedBoxId(newid);
            }

        }
        setIsDrawing(false);
        setTempRect(null);
    };

    // --- 新增：全域點擊事件，點擊非 Box 區域時取消選取 ---
    useEffect(() => {
        const handleGlobalClick = (e) => {
            // 如果點擊的目標不是 rnd-box 內部，且不是正在畫框
            if (containerRef.current && !containerRef.current.contains(e.target)) {
                setSelectedBoxId(null);
            }
        };

        window.addEventListener('mousedown', handleGlobalClick);
        return () => {
            window.removeEventListener('mousedown', handleGlobalClick);
        };
    }, []);
    // 鍵盤刪除事件 (Delete / Backspace)
    useEffect(() => {
        const handleKeyDown = (e) => {

            if ((e.key === 'Delete' || e.key === 'Backspace') && selectedBoxId) {
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

                if (onDeleteBox) {
                    if (onDeleteBox(selectedBoxId)) {
                        setSelectedBoxId(null);
                    }
                }
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [selectedBoxId]);

    const handleDragOrResizeStop = (box, ref, position) => {
        if (!imgRef.current) return;
        const imgWidth = imgRef.current.clientWidth;
        const imgHeight = imgRef.current.clientHeight;

        if (onUpdateBox) {
            onUpdateBox(
                {
                    id: box.id,
                    x: position.x / imgWidth,
                    y: position.y / imgHeight,
                    width: parseInt(ref.style.width) / imgWidth,
                    height: parseInt(ref.style.height) / imgHeight,
                }
            )
        }
    };

    const { width: imgWidth, height: imgHeight } = imgDimensions;

    return (
        <div className='bbox' style={{ ...style, }}>
            <div
                ref={containerRef}
                className='bbox-container'
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
            >
                {url ? (<img
                    ref={imgRef}
                    src={url}
                    alt="target"
                />) : (
                    <span>Select Image</span>
                )}

                {isDrawing && tempRect && (
                    <div style={{
                        position: 'absolute', left: tempRect.x, top: tempRect.y,
                        width: tempRect.width, height: tempRect.height,
                        border: '2px dashed blue', backgroundColor: 'rgba(0, 0, 255, 0.1)', pointerEvents: 'none'
                    }} />
                )}

                {boxes.map((box, index) => {
                    const pixelX = box.x * imgWidth;
                    const pixelY = box.y * imgHeight;
                    const pixelWidth = box.width * imgWidth;
                    const pixelHeight = box.height * imgHeight;

                    return (
                        <Rnd
                            key={`${box.id}-${imgWidth}`}
                            className="rnd-box"
                            size={{ width: pixelWidth, height: pixelHeight }}
                            position={{ x: pixelX, y: pixelY }}
                            bounds="parent"
                            style={{
                                border: selectedBoxId === box.id ? '2px solid rgba(255, 255, 0, 0.8)' : '2px solid rgba(200, 0, 0, 0.8)',
                                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                                cursor: 'move'
                            }}

                            onDragStop={(e, d) => handleDragOrResizeStop(box, { style: { width: `${pixelWidth}px`, height: `${pixelHeight}px` } }, d)}
                            onResizeStop={(e, dir, ref, delta, position) => handleDragOrResizeStop(box, ref, position)}
                            onDragOver={(e) => e.preventDefault()}
                            onMouseDown={() => setSelectedBoxId(box.id)}

                        >
                            <div style={{ color: '#FFFFFF', backgroundColor: 'rgba(200, 0, 0, 0.3)', fontSize: '10px', textAlign: 'center' }}>
                                S{index + 1}
                            </div>
                        </Rnd>
                    );
                })}

            </div>
        </div>
    )
}

export default BBox