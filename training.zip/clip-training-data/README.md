
npm install @mui/material @emotion/react @emotion/styled
npm install @mui/icons-material


# icon
npm install react-icons

# Spliter
npm install react-split

# 方框編輯
npm install react-rnd 
npm install process