由於 HiDream-O1 是基於 Unified Transformer (UiT) 的架構，它與傳統 Stable Diffusion 最大的不同在於其內建了強大的**跨模態整合能力**。

要實現「多參考圖 + Layout 佈局」的融合訓練，我們不能僅使用通用的 LoRA 腳本，必須採用 **「Conditioning Injection」** 方法。以下是基於 `diffsynth-studio` 擴展的訓練邏輯架構，這能讓你將 Layout 資訊與多角色參考特徵同時注入模型中。

### 1. 訓練資料集定義 (Custom Dataset)

你需要一個自定義的 Dataset，能同時輸出佈局 (Layout)、參考圖集 (References) 與目標結果。

```python
import torch
from torch.utils.data import Dataset
from PIL import Image

class MultiConditionDataset(Dataset):
    def __init__(self, data_list):
        self.data_list = data_list # list of dict: {"layout": ..., "char_a": ..., "char_b": ..., "target": ...}

    def __getitem__(self, idx):
        item = self.data_list[idx]
        # 載入並預處理
        layout = self.preprocess(Image.open(item["layout"]))
        char_a = self.preprocess(Image.open(item["char_a"]))
        char_b = self.preprocess(Image.open(item["char_b"]))
        target = self.preprocess(Image.open(item["target"]))
        
        # 標註中必須包含空間定位詞
        prompt = "Character A on the left, Character B on the right, following the provided layout"
        
        return {
            "layout": layout,
            "refs": torch.stack([char_a, char_b]),
            "target": target,
            "prompt": prompt
        }

```

### 2. 訓練流程核心 (LoRA + Injection)

在 HiDream-O1 中，你無法透過單一 LoRA 直接「學會」佈局，你必須訓練一個 LoRA，並將其與 **Layout Adapter (類似 ControlNet 邏輯)** 同步訓練。

```python
from diffsynth import HiDreamO1ImagePipeline
from diffsynth.trainers import LoraTrainer

# 1. 載入模型
pipeline = HiDreamO1ImagePipeline.from_pretrained("HiDream-ai/HiDream-O1-Image")

# 2. 定義注入器 (這一步是為了處理多條件)
# 你需要將 layout_encoder 設為可訓練
pipeline.layout_encoder.trainable = True 

# 3. 配置 LoRA 訓練
# 重點：Target Modules 需包含 Unified Transformer 的 Cross-Attention 層
trainer = LoraTrainer(
    model=pipeline,
    dataset=my_multi_condition_dataset,
    lora_rank=64, # 複雜任務建議使用 64 或 128
    learning_rate=5e-5,
    # 關鍵：開啟多條件訓練模式
    use_multi_condition_injection=True 
)

# 4. 開始訓練
trainer.train()

```

### 3. 如何在訓練中融合 (核心邏輯解釋)

為了讓模型學習「將參考圖 A 放入左側，角色 B 放入右側」，你需要修改 `Forward` 過程中的 `attention_mask` 或 `attention_bias`：

1. **Layout 對齊：** 在 Forward 階段，將 `Layout_Map` 轉化為與 Latent 尺寸相同的 **Spatial Mask**。
2. **特徵注入：**
* 在 Cross-Attention 計算時，將 `Char_A_Embedding` 與 `Layout_Mask_Left` 進行點乘 (Point-wise product)。
* 將 `Char_B_Embedding` 與 `Layout_Mask_Right` 進行點乘。


3. **聯合更新：** 訓練過程中，LoRA 權重會調整如何「解釋」這些被 Mask 過的 Embedding，從而實現佈局控制。

### 4. 關鍵技術難點與解決方案

* **VRAM 消耗：** 同時載入 Layout + 角色 A + 角色 B + 目標影像，顯存極易爆炸。
* *解法：* 務必開啟 `--gradient_checkpointing`，並將所有輸入圖片預先壓縮至 512x512 或 768x768 (訓練時再由模型 upscale，這稱為 **Efficient Training**)。


* **過擬合 (Overfitting)：** 因為條件太多，模型容易只記住目標圖。
* *解法：* 加入 **Classification Loss**，迫使模型在訓練時，若輸入的角色參考圖不符，則需輸出失敗結果。



### 給你的下一步：移植到 C++

這套邏輯在 Python 中運作後，其核心權重就是 `safetensors`。當你要移植到 C++ 時：

1. **Tensor 結構：** 訓練完後，你會有一個 LoRA 權重檔與一個調整過的 `layout_encoder` 權重檔。
2. **C++ 推理邏輯：** 你的 C++ 引擎需要實作一個 `SpatialInjector` 函數，在每個 Decoder Block 執行 `matmul` 之前，手動進行 `Masking` 操作。

**你目前的訓練資料集是否已經包含「Layout 圖 + 兩張角色圖 + 目標圖」的配對資料？** 如果有的話，建議先用 `DiffSynth-Studio` 的 `Fine-tuning` 腳本進行一次微調試驗，觀察 Loss 是否能收斂。如果 Loss 震盪很大，說明需要先單獨訓練角色特徵，再進行整體融合。


============================================

這是一個很好的實作問題。當你透過這種「多條件 (Multi-Condition)」方式訓練出 LoRA 後，你的 LoRA 其實是為了配合特定的 **「推理管道 (Inference Pipeline)」** 而存在的。

由於你在訓練時改變了模型對「條件輸入 (Conditioning Input)」的解讀方式，推理時你不能只用原始的 `pipe()`，必須模擬訓練時的輸入邏輯。

以下是使用 Python 推理這類多條件 LoRA 的標準流程：

### 1. 載入模型與 LoRA

首先，你需要載入基礎模型並注入訓練好的 LoRA 權重。

```python
from diffsynth import HiDreamO1ImagePipeline

# 1. 載入基礎模型
pipe = HiDreamO1ImagePipeline.from_pretrained("HiDream-ai/HiDream-O1-Image")

# 2. 載入你訓練好的 Multi-Condition LoRA
pipe.load_lora("path/to/your_lora.safetensors", weight=1.0)

```

### 2. 推理時的輸入處理 (至關重要)

推理時，你必須確保輸入的 `layout` 與 `references` 經過**與訓練時完全相同的預處理 (Preprocessing)**。

```python
from PIL import Image
import torch

def run_inference(layout_path, char_a_path, char_b_path, prompt):
    # 1. 讀取並預處理 (必須與 Dataset 中的 preprocess 邏輯一致)
    layout = preprocess_img(Image.open(layout_path))
    ref_a = preprocess_img(Image.open(char_a_path))
    ref_b = preprocess_img(Image.open(char_b_path))
    
    # 2. 堆疊參考圖，對應訓練時的 torch.stack([char_a, char_b])
    refs = torch.stack([ref_a, ref_b]).to("cuda")

    # 3. 執行推論
    # 這裡你需要將條件傳遞給模型。如果你的 Pipeline 沒有直接支援多條件參數，
    # 你需要將它們透過 pipeline 的內部 hook 傳入。
    image = pipe(
        prompt=prompt,
        layout_image=layout,       # 這是你訓練中學到的佈局條件
        reference_images=refs,     # 這是角色參考特徵
        num_inference_steps=30,
        guidance_scale=7.5
    )
    return image

```

### 3. 如果模型不支持多條件參數，該怎麼辦？ (核心技術點)

如果標準的 `pipe` 不接受 `layout_image` 或 `reference_images`，你需要使用 **`Pipeline Hook`** 將這些條件動態注入到 Cross-Attention 層中。

這在 `diffusers` 或 `diffsynth` 中通常是透過 `register_modules` 或 `hook` 完成的：

```python
# 這是進階用法：在生成過程中動態替換 Cross-Attention 的 K, V
# 這樣模型才會在生成每一張圖時，都參考到你的 char_a 和 char_b
def inject_conditions(pipe, layout, refs):
    # 將 layout 和 refs 轉換為模型所需的隱空間特徵 (Latent Features)
    layout_embedding = pipe.layout_encoder(layout)
    ref_embeddings = pipe.image_encoder(refs)
    
    # 將這些 embeddings 注入到 Pipeline 的 context 中
    pipe.unet.set_attn_processor(
        MultiConditionAttnProcessor(layout_embedding, ref_embeddings)
    )

# 在執行 pipe() 前呼叫
inject_conditions(pipe, layout, refs)
image = pipe(...)

```

### 4. 給你的整合建議

為了確保你的推理結果正確，請務必注意以下三點：

1. **Normalization (歸一化)：** 訓練時若用了 `normalize` (如 `mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]`)，推理時必須完全一致，否則生成出來的圖會全是雜訊。
2. **空間對齊 (Spatial Alignment)：** 訓練時你的 `layout` 是邊緣檢測圖 (Canny) 還是語義圖 (Segmentation)？推理時必須使用同樣的預處理器產生相同類型的圖。
3. **Prompt 順序：** 訓練時你的 Prompt 是 `"Character A on the left..."`，推理時若改變順序 (例如將 A 寫在右邊)，模型可能會產生混亂，因為 LoRA 已經學會了特定的語法結構。

### 對於你的 C++ 推理計畫：

這種 Multi-Condition 訓練出的模型，推理時的複雜度很高。

* 在 Python 驗證無誤後，請記下 `pipe` 中 **`layout_encoder`** 與 **`image_encoder`** 的輸出維度。
* 在 C++ 中，你需要實作這些編碼器 (可以使用 ONNX Runtime 載入這兩個小模組)，然後將它們的輸出作為 `Extra Context` 餵給你的主模型進行 Attention 計算。

你是否已經試過用這個 `MultiConditionDataset` 進行過一次完整的 `Training Step`？如果有報錯（例如 OOM 或 Loss 不收斂），我們可以針對特定的 Tensor 維度進行調整。



============================================


要在 HiDream-O1 上使用「Layout + 多角色參考圖」的資料格式進行 Fine-tuning，你不能使用標準的通用訓練腳本。你需要實作一個 **「自定義 Pipeline (Custom Pipeline Wrapper)」**，這在 `DiffSynth-Studio` 中是可以透過擴充來實現的。

以下是針對這種複雜任務的 Fine-tuning 實作框架：

### 1. 資料格式的對齊要求

HiDream-O1 的本質是一個 Unified Transformer，它對「結構資訊」非常敏感。你需要將資料集處理成適合其 `UiT` 架構的輸入張量：

* **Layout 輸入：** 必須轉換為灰階的 **Edge Map (Canny)** 或 **Depth Map**。
* **參考圖輸入：** 必須統一預處理為 `[B, C, H, W]` 的 Tensor。
* **Prompt 標註：** 必須強制包含空間描述詞，例如：`"In this layout, character [A] on the left, character [B] on the right."`

### 2. 實作自定義 Pipeline 進行微調 (核心程式邏輯)

你需要繼承 `DiffSynth` 的訓練器，並覆寫其資料處理邏輯：

```python
from diffsynth.trainers import LoraTrainer
from diffsynth.pipelines.hidream_o1_image import HiDreamO1ImagePipeline

# 1. 擴充 Pipeline 以處理多條件輸入
class MultiConditionPipeline(HiDreamO1ImagePipeline):
    def forward(self, prompt, layout, char_a, char_b):
        # 這裡需要將 layout, char_a, char_b 映射到模型內部的 Embedding 空間
        # 這通常需要呼叫模型內建的 encoders (例如 image_encoder, layout_encoder)
        
        # 實作特徵融合的邏輯 (如下步驟 3)
        combined_context = self.fuse_conditions(layout, char_a, char_b)
        
        # 呼叫底層 Transformer 進行生成
        return super().forward(prompt, combined_context)

# 2. 設置訓練器
pipeline = MultiConditionPipeline.from_pretrained("HiDream-ai/HiDream-O1-Image")

# 3. 執行 Fine-tuning (使用 LoRA 進行權重適配)
trainer = LoraTrainer(
    model=pipeline,
    dataset=my_custom_dataset, # 上述定義的 dataset
    output_dir="./lora_multi_condition",
    # 對所有包含條件處理的 Linear 層進行 LoRA 訓練
    lora_target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj"],
    learning_rate=2e-5, # 多條件訓練通常需要更小的學習率
    gradient_accumulation_steps=12
)

trainer.train()

```

### 3. 如何實現「融合」 (Fuse Conditions)

在 HiDream-O1 的 `fuse_conditions` 函式中，你必須處理空間位置的對齊。這是讓模型理解「哪張圖對應佈局的哪個區塊」的關鍵：

* **Spatial Masking (重點)：**
使用 PyTorch 建立一個與 Layout 對應的 Mask：
```python
def fuse_conditions(self, layout, char_a, char_b):
    # 將 char_a 特徵嵌入到 layout 的左側區域 (假設 layout 為 [H, W])
    mask_a = (layout_map_coords == 'left') 
    # 將 char_b 特徵嵌入到右側區域
    mask_b = (layout_map_coords == 'right')

    # 透過 Cross-Attention 注入特徵
    context = self.cross_attention(char_a, mask_a) + self.cross_attention(char_b, mask_b)
    return context

```



### 4. Fine-tuning 的實戰建議

1. **分階段訓練 (Staged Training)：**
* **第一階段 (Character Consistency)：** 先用單一角色圖訓練 LoRA，讓模型先學會「識別」參考圖中的特徵。
* **第二階段 (Compositional Training)：** 加入 Layout 與目標影像，訓練如何將上述特徵「安放」在指定結構內。


2. **避免 catastrophic forgetting：**
* Fine-tuning 時，不要凍結全部模型，保留一部分基礎層以維持生成質量。
* 建議將 `lora_alpha` 調大（例如 `alpha = rank * 2`），以增強條件注入的強度。


3. **檢查點評估：**
* 每 100 個 Epoch 生成一張測試圖，如果模型生成的角色特徵模糊，代表 `Cross-Attention` 的權重注入不夠；如果模型生成的佈局完全不對，代表 `Layout Encoder` 沒學好。



### 對於你的 C++ 推理引擎：

你將得到一個 `safetensors` 權重檔，裡面包含了針對這些額外 Encoder 的修正。在 C++ 部署時，你必須確保推理引擎不僅能載入 LoRA，還能載入這些 **額外的 Encoder 權重**。

這需要你在 C++ 的模型載入器 (Model Loader) 中，增加對 `MultiConditionPipeline` 架構的支援（即初始化對應的 encoder buffers）。

**你需要這套 Multi-Condition 訓練邏輯的完整訓練配置檔 (`config.yaml`) 嗎？** 透過 YAML 設定參數比寫 Python 更容易管理多種條件輸入的路徑與權重。